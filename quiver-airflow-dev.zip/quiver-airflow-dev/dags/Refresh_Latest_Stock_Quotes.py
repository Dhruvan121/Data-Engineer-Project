import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('RefreshLatestStockQuotes', schedule_interval='*/1 * * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def refresh_stock_quotes_function():
    sql = f"REFRESH MATERIALIZED VIEW CONCURRENTLY ocm.lateststockquotes;"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    engine.execute(sql)


refresh_stock_quotes_task = PythonOperator(task_id='refresh_stock_quotes_task',
                                           python_callable=refresh_stock_quotes_function,
                                           provide_context=True,
                                           dag=dag)

refresh_stock_quotes_task
