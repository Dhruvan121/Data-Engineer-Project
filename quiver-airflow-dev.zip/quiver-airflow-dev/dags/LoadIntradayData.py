from datetime import datetime,timedelta
from airflow import DAG
from airflow.operators.postgres_operator import PostgresOperator
from airflow.hooks.postgres_hook import PostgresHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.hooks.mssql_hook import MsSqlHook
import pandas as pd
import numpy as np
import psycopg2


#Define dag funtion
# def process_truncate_instrumentdata(**kwargs):
#     conn_id = kwargs.get('conn_id')
#     pg_hook = PostgresHook(conn_id)
#     sql = '''truncate table won.instrumentdata_dev'''
#     pg_hook.run(sql)

# def process_truncate_portfsecurity(**kwargs):
#     conn_id = kwargs.get('conn_id')
#     pg_hook = PostgresHook(conn_id)
#     sql = '''truncate table public.portfsecurity_dev'''
#     pg_hook.run(sql)

# def process_truncate_secmaster(**kwargs):
#     conn_id = kwargs.get('conn_id')
#     pg_hook = PostgresHook(conn_id)
#     sql = '''truncate table won.secmaster_dev'''
#     pg_hook.run(sql)

def fn_initialize_tables(**kwargs):
    conn_id = kwargs.get('conn_id')
    pg_hook = PostgresHook(conn_id)
    sql = '''select * from ocm.create_intraday_loading_tables(true)'''
    pg_hook.run(sql)

def fn_load_data_from_landing_to_final_tables(**kwargs):
    conn_id = kwargs.get('conn_id')
    pg_hook = PostgresHook(conn_id)
    sql = '''select * from ocm.create_intraday_loading_tables(false)'''
    pg_hook.run(sql)


def extract_and_Load__instrument_data():
    hook = MsSqlHook(mssql_conn_id='wondb_conn')
    sql = """ SELECT 
                        univ.InstrumentID
                        ,univ.Symbol
                        ,univ.InstrumentTypeID
                        ,inst.InstrumentType AS AppxInstrumentType
                        ,ig.OneilIndustryGroupName AS INDNAM
                        ,sc.OneilSectorName AS SECN11
                        ,CASE
                            WHEN univ.InstrumentTypeID = 100 THEN nav.MfhNAV
                            WHEN univ.[Status] = 'A' THEN act.PRICE0
                            ELSE inact.Price0
                        END AS Price0
                        ,CASE
                            WHEN univ.[Status] = 'A' THEN act.Epsrnk
                            ELSE inact.Epsrnk
                        END AS Epsrnk
                        ,CASE
                            WHEN univ.[Status] = 'A' THEN act.Rlst
                            ELSE inact.Rlst
                        END AS Rlst
                        ,CASE
                            WHEN act.Indcd = 0 OR inact.Indcd = 0 THEN NULL
                            WHEN univ.[Status] = 'A' THEN act.PRICE0 * act.Captl2 * 1000
                            ELSE inact.Price0 * inact.Captl2 * 1000
                        END AS FRNMKTVAL
                        ,univ.MSID
                        ,univ.[Status]
                        ,univ.IndustryGroupCode
                        ,sc.OneilSectorCode AS SECT11
                        ,CASE
                            WHEN univ.InstrumentTypeID = 100 THEN navdate.maxdate
                            WHEN univ.[Status] = 'A' THEN act.PriceDate
                            ELSE inact.PriceDate
                        END AS PriceDate
                        ,CASE
                            WHEN univ.[Status] = 'A' THEN act.Currency
                            ELSE inact.Currency
                        END AS Currency
                        ,CASE
                            WHEN act.Indcd = 0 OR inact.Indcd = 0 THEN NULL
                            WHEN univ.[Status] = 'A' THEN (act.PRICE0/ISNULL(cu.Price0,1)) * act.Captl2 * 1000
                            ELSE (inact.PRICE0/ISNULL(hcu1.Price,ISNULL(hcu2.Price,1))) * inact.Captl2 * 1000
                        END AS MKTVAL 
                        ,cn.RegionCode
                        ,rg.RegionName
                        ,univ.CountryCode
                        ,cn.CountryName
                        ,tmap.BrowserInstrTypeID
                        ,btype.BrowserInstrTypeName 
                    FROM Panaray.ref.Instrument  AS univ  with (NOLOCK)
                    INNER JOIN Panaray.ref.InstrumentTypeMapping AS tmap   with (NOLOCK)
                        ON tmap.InstrumentTypeID = univ.InstrumentTypeID
                    INNER JOIN Panaray.ref.BrowserInstrumentType AS btype   with (NOLOCK)
                        ON btype.BrowserInstrTypeID = tmap.BrowserInstrTypeID
                    INNER JOIN Panaray.ref.Country AS cn   with (NOLOCK)
                        ON cn.CountryCode = univ.CountryCode
                    INNER JOIN Panaray.ref.Region AS rg   with (NOLOCK)
                        ON rg.RegionCode = cn.RegionCode

                    INNER JOIN (
                        SELECT Symbol, MIN(Status) AS MinStatus
                        FROM Panaray.ref.Instrument   with (NOLOCK)
                        GROUP BY Symbol
                        ) AS univstatus
                        ON univstatus.Symbol = univ.Symbol
                        AND univstatus.MinStatus = univ.Status

                    INNER JOIN (
                        SELECT Symbol, Status, MIN(InstrumentID) AS MinID
                        FROM Panaray.ref.Instrument   with (NOLOCK)
                        GROUP BY Symbol, Status
                        ) AS univid
                        ON univid.Symbol = univ.Symbol
                        AND univid.Status = univstatus.MinStatus
                        AND univid.MinID = univ.InstrumentID

                    INNER JOIN wondb.dbo.APPX_InstrumentMaster AS inst  with (NOLOCK)
                        ON inst.DailyPvEnd IS NOT NULL
                        AND inst.WeeklyPvEnd IS NOT NULL
                        AND inst.MonthlyPvEnd IS NOT NULL
                        AND inst.Symbol = univ.Symbol
                        AND inst.InstrumentID = (CASE WHEN inst.InstrumentTypeID = 8 THEN 40000000 + univ.InstrumentID ELSE univ.InstrumentID END)

                    LEFT JOIN wondb.dbo.Secmaster AS act  with (NOLOCK)
                        ON act.OSID = univ.InstrumentID
                    LEFT JOIN wondb.dbo.InactiveRsm AS inact  with (NOLOCK)
                        ON univ.InstrumentTypeID = 1
                        AND univ.[Status] = 'I'
                        AND inact.OSID = univ.InstrumentID
                    LEFT JOIN wondb.dbo.secmaster AS cu  with (NOLOCK)
                        ON cu.OSID = act.Currency
                    LEFT JOIN wondb.dbo.hsf AS hcu1   with (NOLOCK)
                        ON hcu1.OSID = inact.Currency
                        AND hcu1.[Date] = inact.PriceDate
                    LEFT JOIN wondb.dbo.ahsf AS hcu2  with (NOLOCK)
                        ON hcu2.OSID = inact.Currency
                        AND hcu2.[Date] = inact.PriceDate
                    LEFT JOIN Panaray.ref.OneilIndustryGroup AS ig   with (NOLOCK)
                        ON ig.OneilIndustryGroupCode = univ.IndustryGroupCode
                    LEFT JOIN Panaray.ref.OneilMajorIndustry AS mj   with (NOLOCK)
                        ON mj.OneilMajorIndustryCode = ig.OneilMajorIndustryCode
                    LEFT JOIN  Panaray.ref.OneilSector AS sc   with (NOLOCK)
                        ON sc.OneilSectorCode = mj.OneilSectorCode
                    LEFT JOIN MFDB.dbo.Funds AS mf   with (NOLOCK)
                        ON mf.FndOFID = univ.InstrumentID
                        AND univ.InstrumentTypeID = 100
                    LEFT JOIN (
                        SELECT MfhOFID, MAX(MfhDate) AS maxdate
                        FROM MFDB.dbo.MfHistory   with (NOLOCK)
                        GROUP BY MfhOFID
                        ) AS navdate
                        ON navdate.MfhOFID = mf.FndOFID
                    LEFT JOIN MFDB.dbo.MfHistory AS nav  with (NOLOCK)
                        ON nav.MfhOFID = mf.FndOFID
                        AND nav.MfhDate = navdate.maxdate

                    WHERE
                        univ.InstrumentTypeID IN (1, 14, 17, 19, 104, 105, 119, 100);
            """

    df_inst_data = hook.get_pandas_df(sql)
    #print(df_inst_data)
    pg_hook = PostgresHook(postgres_conn_id='AIRFLOW_CONN_QUIVER_CLOUD')
    pg_conn = pg_hook.get_conn()
    # pg_hook.insert_rows('won.instrumentdata_loading', df_inst_data)

    # df_inst_data.to_sql(name='instrumentdata_loading', con=pg_conn, schema='won', if_exists='append',
    #                     index=False, chunksize=10000)
    # context['ti'].xcom_push(key='ext_ins_data', value =df_inst_data)
    # #return df_inst_data
    # print(df_inst_data)

    df_inst_data.fillna(value=np.nan, inplace=True)
    df_inst_data = df_inst_data.replace({np.nan: None})
    
    pg_cur = pg_conn.cursor()
    sql = """insert into won.instrumentdata_loading 
	(instrumentid, symbol, instrumenttypeid, appxinstrumenttype, oneilindustrygroupname, oneilsectorname, 
	 price0, epsrnk, rlst, frnmktval, msid, status, industrygroupcode, sect11, pricedate, currency, mktval, regioncode,
	regionname, countrycode, countryname, browserinsttypeid, browserinsttypename)
        values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    
    for _,row in df_inst_data.iterrows():
        pg_cur.execute(sql, (row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], 
                            row[10], row[11], row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], 
                            row[20], row[21], row[22]))

        
    pg_conn.commit()
    pg_cur.close()
    pg_conn.close()


def extract_and_Load__portfsecurity():
    hook = MsSqlHook(mssql_conn_id='advent_conn')
    sql = """SELECT SecurityID as securityid,NULLIF(UPPER(Ticker),'''') as ticker,NULLIF(FullName,'''') as fullname,NULLIF(UPPER(CUSIP),'''') as cusip
                    ,NULLIF(SEDOL,'''') as sedol,NULLIF(ISIN,'''') as isin,NULLIF(SecTypeBaseCode,'''') as sectypebasecode ,
                        NULLIF(ProprietarySymbol,'''') as proprietarysymbol ,NULLIF(PrincipalCurrencyCode,'''')		 as principalcurrencycode		
                FROM APXFirm.AdvApp.vSecurity;
            """

    df_portfsecurity = hook.get_pandas_df(sql)

    pg_hook = PostgresHook(postgres_conn_id='AIRFLOW_CONN_QUIVER_CLOUD')
    pg_conn = pg_hook.get_conn()

    # df_portfsecurity.to_sql(name='portfsecurity_loading', con=pg_conn, schema='public', if_exists='append',
    #                     index=False, chunksize=10000)
    
    df_portfsecurity.fillna(value=np.nan, inplace=True)
    df_portfsecurity = df_portfsecurity.replace({np.nan: None})
    pg_cur = pg_conn.cursor()
    sql = """INSERT INTO public.portfsecurity_loading(
            securityid, ticker, fullname, cusip, sedol, isin, sectypebasecode, proprietarysymbol, principalcurrencycode)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);"""
    
    for _,row in df_portfsecurity.iterrows():
        pg_cur.execute(sql, (row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]))

        
    pg_conn.commit()
    pg_cur.close()
    pg_conn.close()


def extract_and_Load__secmaster():
    hook = MsSqlHook(mssql_conn_id='wondb_conn')
    sql = """SELECT [OSID],[Symbol],[Indcd],LTRIM(RTRIM(CoName))  AS CoName ,[Price0],[Volum0],[High0],[Low0],[Price],[Volum],[High],[Low],[Captl],[Epsrnk]
            ,[Rlst],[Dgrt],[Grprnk],[PrErn],[Avol],[Shrt],ACCDIS,[FiftyD],[TwoHun],[YrHi],[YrLo],[DJI],[DJT],[DJU],[SP500F],[SP100F]
            ,[SP600F],[MIDCAP],[RU1THF],[RU2THF],[RU25TF],[RUMCTF],[RUVATF],[RUGRTF],[RUMCVF],[RUMCGF],[EXCHCD],[BIGCBY],[BIGCSL],[BIGCFB],[BIGCUF]
            ,[NSMIBY],[NSMISL],[PSEF],[SplitFactor],[SplitFactor1],[PriceDate],[FiscalMonthEnd],[Captl2],[Float1],[PctOfIndex],[Smrl],[Smrn],[EstEps],[PrevVolum0]
            ,[Nasdaq100F],[PctOfSP500],[PctOfNsd100],[CIK],[Cusip],[NewIssueDate],[EffectiveDate],[NewIssuePrice],[IPOFlag],[ArticleFlag],[CEOFlag],[ResearchFlag]
            ,[CountryCode],[Currency]  FROM wondb.[dbo].[SECMaster];
            """

    df_secmaster = hook.get_pandas_df(sql)

    pg_hook = PostgresHook(postgres_conn_id='AIRFLOW_CONN_QUIVER_CLOUD')
    pg_conn = pg_hook.get_conn()

    # df_secmaster.to_sql(name='secmaster_loading', con=pg_conn, schema='won', if_exists='append',
    #                     index=False, chunksize=10000)
        
    df_secmaster.fillna(value=np.nan, inplace=True)
    df_secmaster = df_secmaster.replace({np.nan: None})
    pg_cur = pg_conn.cursor()
    sql = """INSERT INTO won.secmaster_loading
                (
                    osid, symbol, indcd, coname, price0, volum0, high0, low0, price, volum, high, low, captl, 
                    epsrnk, rlst, dgrt, grprnk, prern, avol, shrt, accdis, fiftyd, twohun, yrhi, yrlo, dji, 
                    djt, dju, sp500f, sp100f, sp600f, midcap, ru1thf, ru2thf, ru25tf, rumctf, ruvatf, rugrtf, 
                    rumcvf, rumcgf, exchcd, bigcby, bigcsl, bigcfb, bigcuf, nsmiby, nsmisl, psef, splitfactor, 
                    splitfactor1, pricedate, fiscalmonthend, captl2, numeric1, pctofindex, smrl, smrn, esteps, 
                    prevvolum0, nasdaq100f, pctofsp500, pctofnsd100, cik, cusip, newissuedate, effectivedate, 
                    newissueprice, ipoflag, articleflag, ceoflag, researchflag, countrycode, currency)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                        %s, %s, %s, %s, %s, %s, %s);"""
    
    for _,row in df_secmaster.iterrows():
        pg_cur.execute(sql, (row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], 
                            row[10], row[11], row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], 
                            row[20], row[21], row[22], row[23], row[24], row[25], row[26], row[27], row[28], row[29],
                            row[30], row[31], row[32], row[33], row[34], row[35], row[36], row[37], row[38], row[39],
                            row[40], row[41], row[42], row[43], row[44], row[45], row[46], row[47], row[48], row[49],
                            row[50], row[51], row[52], row[53], row[54], row[55], row[56], row[57], row[58], row[59],
                            row[60], row[61], row[62], row[63], row[64], row[65], row[66], row[67], row[68], row[69],
                            row[70], row[71], row[72]
                            ))

        
    pg_conn.commit()
    pg_cur.close()
    pg_conn.close()


# def load_instrument_data(**kwargs):
#     conn_id = kwargs.get('conn_id')
#     instrument_data = context['ti'].xcom_pull(key='ext_ins_data')
#     #instrument_data = ti.xcom_pull(task_ids=['extract_instrument_data'])
#     #pg_hook = PostgresHook(postgres_conn_id=conn_id, schema="ocmportfoliodb")
#     pg_hook = PostgresHook(postgres_conn_id=conn_id)
#     pg_conn = pg_hook.get_conn()
#     print(type(instrument_data))
#     instrument_data.to_sql('instrumentdata_dev', con=pg_conn, schema='won', if_exists='append',
#                         index=False, chunksize=10000)


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    # 'start_date': airflow.utils.dates.
    'start_date': datetime(2022, 12, 8),
    # 'email': ['email@mail.com'],
    # 'email_on_failure': False,
    # 'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
        'Load_Intraday_Data',
        schedule_interval=None,
        tags=['Quiver_Mig'],
        default_args=default_args,
        max_active_runs=1,
        catchup=False
    )

start = DummyOperator(
    task_id='start',
    dag=dag
)

# truncate destination table

# task_truncate_instrumentdata = PythonOperator(
#     task_id='truncate_instrumentdata',
#     op_kwargs={'conn_id': 'AIRFLOW_CONN_QUIVER_CLOUD'},
#     python_callable=process_truncate_instrumentdata,
#     dag=dag)

# task_truncate_portfsecurity = PythonOperator(
#     task_id='truncate_portfsecurity',
#     op_kwargs={'conn_id': 'AIRFLOW_CONN_QUIVER_CLOUD'},
#     python_callable=process_truncate_portfsecurity,
#     dag=dag)

# task_truncate_secmaster = PythonOperator(
#     task_id='truncate_secmaster',
#     op_kwargs={'conn_id': 'AIRFLOW_CONN_QUIVER_CLOUD'},
#     python_callable=process_truncate_secmaster,
#     dag=dag)

#initialize table and final data load
initialize_landing_tables = PythonOperator(
    task_id='initialize_tables',
    op_kwargs={'conn_id': 'AIRFLOW_CONN_QUIVER_CLOUD'},
    python_callable=fn_initialize_tables,
    dag=dag)

load_data_from_landing_to_final_tables = PythonOperator(
    task_id='final_load',
    op_kwargs={'conn_id': 'AIRFLOW_CONN_QUIVER_CLOUD'},
    python_callable=fn_load_data_from_landing_to_final_tables,
    dag=dag)

# extract data from source table
task_extract_load_instrument = PythonOperator(
    task_id='task_extract_load_instrument',
    python_callable=extract_and_Load__instrument_data,
    #do_xcom_push=True,
    #provide_context =True,
    dag=dag)

task_extract_load_portfsecurity = PythonOperator(
    task_id='task_extract_load__portfsecurity',
    python_callable=extract_and_Load__portfsecurity,
    dag=dag)

task_extract_load_secmaster = PythonOperator(
    task_id='task_extract_load_secmaster',
    python_callable=extract_and_Load__secmaster,
    dag=dag)

# Load data from source table to Destination
# task_load_data = PythonOperator(
#     task_id='load_instrumentdata',
#     op_kwargs={'conn_id': 'AIRFLOW_CONN_QUIVER_CLOUD'},
#     python_callable=load_instrument_data,
#     dag=dag)


#start >> task_truncate_instrumentdata >> task_extract_load_instrument >> task_truncate_portfsecurity >> task_extract_load_portfsecurity >> task_truncate_secmaster >> task_extract_load_secmaster

# start >> initialize_landing_tables >> task_extract_load_instrument >> task_extract_load_portfsecurity >> task_extract_load_secmaster >> load_data_from_landing_to_final_tables

start >> task_extract_load_portfsecurity




