import numpy as np
from itertools import combinations
import matplotlib.pyplot as plt
import pandas as pd
import cvxpy as cp


def log_to_lin(mu, var):
    mu = pd.Series(mu)
    var = pd.Series(var, index=mu.index)
    logmu = mu.copy()
    logvar = var.copy()
    mu = np.exp(logmu.values + .5 * logvar.values) - 1.0
    var = (np.exp(logvar.values) - 1) * np.exp(2 * logmu.values + logvar.values)
    return pd.DataFrame({'mu_lin': mu, 'var_lin': var}, index=mu.index)


def lin_to_log(mu, var):
    mu = pd.Series(mu)
    var = pd.Series(var)
    linmu = mu.values.copy() + 1
    linvar = var.values.copy()
    var = pd.Series(
        np.log(1 + linvar / linmu ** 2)
        , index=var.index)
    mu = np.log(linmu / np.sqrt(1 + linvar / (linmu ** 2)))
    return pd.DataFrame({'mu_log': mu, 'var_log': var}, index=var.index)


def estimate_combined_var(w, cov_matrix=None, var=None, corrs=None, avg_corr=None):  # linear inputs
    w = pd.Series(w)
    w[np.isnan(w)] = 0
    # w_idx = w!=0
    # w = w[w_idx]

    if cov_matrix is not None:
        var_comb = np.dot(np.dot(w, cov_matrix), w)

    else:
        var = pd.Series(var)
        var[np.isnan(var)] = np.nanmean(var)
        var_comb = np.sum(w * w * var)

        ns = set(w.index)
        pairs = list(combinations(ns, 2))  # len = len(osids)*(len(osids)-1)/2

        var = np.sqrt(var)

        if corrs is None:
            corrs = pd.Series(np.repeat(avg_corr, len(w)), index=w.index)

        crosses = 0.
        for p in pairs:
            wa = w.loc[p[0]]
            wb = w.loc[p[1]]
            sa = var[p[0]]
            sb = var[p[1]]
            ca = corrs[p[0]]
            cb = corrs[p[1]]
            crosses += (wa * wb * sa * sb * ca * cb)

        var_comb = var_comb + 2 * crosses

    return var_comb  # linear


def kelly_single_asset(mu, var, rf=0):
    mu = pd.Series(mu)
    var = pd.Series(var)
    k = (mu.values - rf) / var.values
    k[np.isnan(k)] = 0
    k[np.isinf(k)] = 0
    k = pd.Series(k, index=var.index)
    return k


def kelly_multi_asset(mu, S, rf=0, kfrac=1, allow_short=True,
                      max_net=None, max_gross=None, min_position=None, max_positions=None,
                      max_iter=10):
    def k_calc(mu, Sinv, rf, kfrac):
        k = kfrac * np.array((1 + rf) * Sinv.dot(mu - rf))
        k[np.isnan(k)] = 0
        k[np.isinf(k)] = 0

        return k

    mu = pd.Series(mu).copy(deep=True)

    if max_positions is not None:
        max_positions = pd.Series(max_positions).copy(deep=True)
        if len(max_positions) == 1:
            max_positions = max_positions.repeat(len(mu))
    else:
        max_positions = pd.Series(np.Inf).repeat(len(mu))

    S = np.matrix(S, dtype='float')
    Sinv = np.linalg.solve(S, np.eye(S.shape[0]))

    k = k_calc(mu, Sinv, rf, kfrac)

    calc = True
    i = 0
    overage_last = np.array([np.Inf])
    while (calc == True) and (i < max_iter):

        while (allow_short is False) and (k.shape[0] > 0) and (np.min(k) < 0):
            keep_idx = k > 0
            mu = mu[keep_idx].copy(deep=True)
            if len(mu) > 0:
                max_positions = max_positions[keep_idx].copy(deep=True)
                S = S[keep_idx][:, keep_idx]
                Sinv = np.linalg.solve(S, np.eye(S.shape[0]))
                k = k_calc(mu, Sinv, rf, kfrac)
            else:
                k = pd.Series([], index=mu.index)

        if (max_net is not None) and (k.shape[0] > 0) and (np.sum(k) > max_net):
            mu = rf + (mu - rf) * max_net / np.sum(k)
            k = k_calc(mu, Sinv, rf, kfrac)

        if (max_gross is not None) and (k.shape[0] > 0) and (np.sum(np.abs(k)) > max_gross):
            mu = rf + (mu - rf) * max_gross / np.sum(np.abs(k))
            k = k_calc(mu, Sinv, rf, kfrac)

        while (min_position is not None) and (k.shape[0] > 0) and (np.min(np.abs(k)) < min_position):
            keep_idx = np.ones(k.shape[0], dtype=bool)
            keep_idx[np.argmin(np.abs(k))] = False
            mu = mu[keep_idx].copy(deep=True)
            if len(mu) > 0:
                max_positions = max_positions[keep_idx].copy(deep=True)
                S = S[keep_idx][:, keep_idx]
                Sinv = np.linalg.solve(S, np.eye(S.shape[0]))
                k = k_calc(mu, Sinv, rf, kfrac)
                while (allow_short is False) and (k.shape[0] > 0) and (np.min(k) < 0):
                    keep_idx = k > 0
                    mu = mu[keep_idx].copy(deep=True)
                    if len(mu) > 0:
                        max_positions = max_positions[keep_idx].copy(deep=True)
                        S = S[keep_idx][:, keep_idx]
                        Sinv = np.linalg.solve(S, np.eye(S.shape[0]))
                        k = k_calc(mu, Sinv, rf, kfrac)
                    else:
                        k = pd.Series([], index=mu.index)
            else:
                k = pd.Series([], index=mu.index)

        if (max_positions is not None) and (k.shape[0] > 0):
            overage = np.abs(k) / max_positions.values
            overage_max = np.nanmax(overage)
        else:
            overage = None
            overage_max = 1

        if (max_positions is not None) and (overage_max > 1.01) and (np.nanmax(overage_last - overage_max) > .25):
            overage_last = np.append(overage_last[-2:], overage_max)
            over_idx = overage > 1.0
            tgt_pos = k
            tgt_pos[over_idx] = np.sign(k[over_idx]) * max_positions.values[over_idx]
            mu_tgt = rf + np.linalg.lstsq(Sinv, tgt_pos / kfrac / (1 + rf))[0]
            mu_tgt[((mu_tgt - rf) * (mu.values - rf)) < 0] = rf
            mu[over_idx] = np.min([
                mu[over_idx].values,
                (mu[over_idx].values + mu_tgt[over_idx]) / 2
            ], axis=0)
            k = k_calc(mu, Sinv, rf, kfrac)
        else:
            calc = False

        i += 1

    if len(k) > 0:
        k = np.min(np.array([k, max_positions.values]), axis=0)

    k = pd.Series(k, index=mu.index)

    return k


class optimize_port():

    def __init__(self, tc_on_buy=True,
                 tc_participation=0, tc_participation_power=1,
                 simple_min_abs_pos=True, risk_imp=0,
                 max_gross=None, max_net=None, min_net=None,
                 max_gross_beta=None, max_net_beta=None, min_net_beta=None,
                 risk_limit=None, max_k_frac=None,
                 robust=False, fast_kelly=False, verbose=2):

        self.tc_on_buy = tc_on_buy
        self.tc_participation = tc_participation
        self.tc_participation_power = tc_participation_power
        self.simple_min_abs_pos = simple_min_abs_pos
        self.risk_imp = risk_imp
        self.max_gross = max_gross
        self.max_net = max_net
        self.min_net = min_net
        self.max_gross_beta = max_gross_beta
        self.max_net_beta = max_net_beta
        self.min_net_beta = min_net_beta
        self.risk_limit = risk_limit
        self.max_k_frac = max_k_frac
        self.robust = robust
        self.fast_kelly = fast_kelly
        self.verbose = verbose

    def update_risk_limit(self, risk_limit=None):
        self.risk_limit = risk_limit

    def update_max_k_frac(self, max_k_frac=None):
        self.max_k_frac = max_k_frac

    def setup_data(self, mu, S, current_wgts=0.0, margin_cost=0.0,
                   tc_proportional=0.0, tc_volume_ratio=0.0,
                   tc_scale=1.0, exp_hold=1.0, beta=1.0,
                   max_pos=None, min_pos=None, min_abs_pos=0.0001
                   ):

        if isinstance(current_wgts, float) or isinstance(current_wgts, int):
            current_wgts = np.array([current_wgts] * len(mu))

        if isinstance(tc_proportional, float) or isinstance(tc_proportional, int):
            tc_proportional = np.array([tc_proportional] * len(mu))

        if isinstance(tc_volume_ratio, float) or isinstance(tc_volume_ratio, int):
            tc_volume_ratio = np.array([tc_volume_ratio] * len(mu))

        if isinstance(tc_scale, float) or isinstance(tc_scale, int):
            tc_scale = np.array([tc_scale] * len(mu))

        if isinstance(exp_hold, float) or isinstance(exp_hold, int):
            exp_hold = np.array([exp_hold] * len(mu))

        if isinstance(beta, float) or isinstance(beta, int):
            beta = np.array([beta] * len(mu))

        if max_pos is not None:
            if isinstance(max_pos, float) or isinstance(max_pos, int):
                max_pos = np.array([max_pos] * len(mu))

        if min_pos is not None:
            if isinstance(min_pos, float) or isinstance(min_pos, int):
                min_pos = np.array([min_pos] * len(mu))

        if min_abs_pos is not None:
            if isinstance(min_abs_pos, float) or isinstance(min_abs_pos, int):
                min_abs_pos = np.array([min_abs_pos] * len(mu))

        if isinstance(mu, pd.core.series.Series):
            self.idx = mu.index
            mu = mu.values
            match_idx = True
        else:
            self.idx = range(len(mu))
            match_idx = False

        if isinstance(S, pd.core.frame.DataFrame):
            if match_idx == True:
                S = S.reindex(index=self.idx, columns=self.idx)
            S = S.values

        e_val, e_vect = np.linalg.eig(np.array(S, dtype=np.float64))
        if np.min(e_val) < 0:
            if self.verbose >= 1:
                print('Covariance matrix has negative eigen values.  Fixing.')
            e_val = (e_val + np.abs(e_val)) / 2
            S = np.real(e_vect.dot(np.diag(e_val)).dot(e_vect.T))

        if isinstance(current_wgts, pd.core.series.Series):
            if match_idx == True:
                current_wgts = current_wgts.reindex(self.idx).fillna(0)
            current_wgts = current_wgts.values

        current_wgts = np.nan_to_num(current_wgts)

        if isinstance(tc_proportional, pd.core.series.Series):
            if match_idx == True:
                tc_proportional = tc_proportional.loc[self.idx]
            tc_proportional = tc_proportional.values

        if isinstance(tc_volume_ratio, pd.core.series.Series):
            if match_idx == True:
                tc_volume_ratio = tc_volume_ratio.loc[self.idx]
            tc_volume_ratio = tc_volume_ratio.values

        if isinstance(tc_scale, pd.core.series.Series):
            if match_idx == True:
                tc_scale = tc_scale.loc[self.idx]
            tc_scale = tc_scale.values

        if isinstance(exp_hold, pd.core.series.Series):
            if match_idx == True:
                exp_hold = exp_hold.loc[self.idx]
            exp_hold = exp_hold.values

        if isinstance(beta, pd.core.series.Series):
            if match_idx == True:
                beta = beta.loc[self.idx]
            beta = beta.values

        if isinstance(max_pos, pd.core.series.Series):
            if match_idx == True:
                max_pos = max_pos.loc[self.idx]
            max_pos = max_pos.values

        if isinstance(min_pos, pd.core.series.Series):
            if match_idx == True:
                min_pos = min_pos.loc[self.idx]
            min_pos = min_pos.values

        if isinstance(min_abs_pos, pd.core.series.Series):
            if match_idx == True:
                min_abs_pos = min_abs_pos.loc[self.idx]
            min_abs_pos = min_abs_pos.values

        self.mu = mu
        self.S = S
        self.current_wgts = current_wgts
        self.margin_cost = margin_cost
        self.tc_proportional = tc_proportional
        self.tc_volume_ratio = tc_volume_ratio
        self.tc_scale = tc_scale
        self.exp_hold = exp_hold
        self.beta = beta
        self.max_pos = max_pos
        self.min_pos = min_pos
        self.min_abs_pos = min_abs_pos

    def setup_prob(self, gamma, mu=None, S=None,
                   current_wgts=None, margin_cost=None,
                   tc_proportional=None, tc_volume_ratio=None,
                   tc_scale=None, exp_hold=None, beta=None,
                   max_pos=None, min_pos=None
                   ):

        if mu is None: mu = self.mu
        if S is None: S = self.S
        if current_wgts is None: current_wgts = self.current_wgts
        if margin_cost is None: margin_cost = self.margin_cost
        if tc_proportional is None: tc_proportional = self.tc_proportional
        if tc_volume_ratio is None: tc_volume_ratio = self.tc_volume_ratio
        if tc_scale is None: tc_scale = self.tc_scale
        if exp_hold is None: exp_hold = self.exp_hold
        if beta is None: beta = self.beta
        if max_pos is None: max_pos = self.max_pos
        if min_pos is None: min_pos = self.min_pos

        self.w = None
        self.ret = None
        self.risk = None
        self.mc = None
        self.tc = None
        self.beta_port = None
        self.beta_abs_port = None
        self.constr = None
        self.prob = None

        self.w = cp.Variable(len(mu))
        self.ret = mu.T @ self.w
        self.risk = cp.sum_squares(self.w @ S)
        self.mc = margin_cost * (cp.abs(cp.sum(self.w) - 1) + (cp.sum(self.w) - 1)) / 2
        self.beta_port = beta @ self.w
        self.beta_abs_port = np.abs(beta) @ cp.abs(self.w)

        if self.tc_on_buy is True:
            self.chg_up = (
                    cp.pos(self.w - np.array([x if x > 0 else 0 for x in current_wgts]))
                    + cp.abs(cp.neg(self.w - np.array([x if x < 0 else 0 for x in current_wgts])))
            )
            self.chg_down = 0 * cp.abs(self.w - current_wgts)
            tc_mult = 2.0
        else:
            self.chg_up = cp.pos(self.w - current_wgts)
            self.chg_down = cp.abs(cp.neg(self.w - current_wgts))
            tc_mult = 1.0

        tc_prop_coefs_up = tc_scale * tc_proportional / exp_hold
        tc_prop_coefs_down = tc_scale * tc_proportional / np.mean(exp_hold)

        if ((max_pos is not None) and (min_pos is not None)):
            dummy_chg = (np.mean(np.abs(max_pos - min_pos)) + np.abs(max_pos - min_pos)) / 5.0
        else:
            dummy_chg = 0.0

        tc_part_coefs_up = (
                self.tc_participation * tc_scale
                * np.power(tc_volume_ratio * dummy_chg, self.tc_participation_power)
                / exp_hold
        )

        tc_part_coefs_down = (
                self.tc_participation * tc_scale
                * np.power(tc_volume_ratio * dummy_chg, self.tc_participation_power)
                / np.mean(exp_hold)
        )

        self.tc = tc_mult * (
                tc_prop_coefs_up.T @ self.chg_up
                + tc_prop_coefs_down.T @ self.chg_down
                + tc_part_coefs_up.T @ self.chg_up
                + tc_part_coefs_down.T @ self.chg_down
        )

        self.constr = []

        if max_pos is not None:
            self.constr.append(self.w <= max_pos)

        if min_pos is not None:
            self.constr.append(self.w >= min_pos)

        if self.max_gross is not None:
            self.constr.append(cp.sum(cp.abs(self.w)) <= self.max_gross)

        if self.max_net is not None:
            self.constr.append(cp.sum(self.w) <= self.max_net)

        if self.min_net is not None:
            self.constr.append(cp.sum(self.w) >= self.min_net)

        if self.max_gross_beta is not None:
            self.constr.append(self.beta_abs_port <= self.max_gross_beta)

        if self.max_net_beta is not None:
            self.constr.append(self.beta_port <= self.max_net_beta)

        if self.min_net_beta is not None:
            self.constr.append(self.beta_port >= self.min_net_beta)

        if self.risk_limit is not None:
            self.constr.append(self.risk <= self.risk_limit)

        if len(self.constr) == 0:
            self.prob = cp.Problem(cp.Maximize(self.ret - self.mc - self.tc - gamma * self.risk))
        else:
            self.prob = cp.Problem(cp.Maximize(self.ret - self.mc - self.tc - gamma * self.risk), self.constr)

    def solve_try(self):
        starting_weights = [self.current_wgts, 'k', np.repeat(0, len(self.mu))]
        solvers = [cp.ECOS, cp.SCS, cp.OSQP]

        calc = True
        i = 0
        while ((calc == True) and (i < len(starting_weights))):

            j = 0
            while ((calc == True) and (j < len(solvers))):
                try:
                    sw = starting_weights[i]

                    if type('sw') == str:
                        Sinv = np.linalg.solve(np.matrix(self.S, dtype='float'), np.eye(self.S.shape[0]))
                        sw = np.array((1 + self.hurdle) * Sinv.dot(self.mu - self.hurdle))
                        sw[np.isnan(sw)] = 0
                        sw[np.isinf(sw)] = 0
                    self.w.value = sw

                    self.prob.solve(warm_start=True, solver=solvers[j])

                    self.wgts = pd.Series(self.w.value, index=self.use_idx).reindex(self.idx).fillna(0)

                    calc = False

                except Exception as err:
                    if self.verbose >= 2:
                        print('Solver: {}, Error: {}'.format(solvers[j], err))
                    if err.args[0] == 'Problem does not follow DCP rules.':
                        j = len(solvers)
                    else:
                        j += 1

            i += 1

        if calc == True:
            raise Exception('All solvers and starting weights failed.')

    def apply_min_pos(self):
        if self.simple_min_abs_pos == True:
            self.wgts[np.abs(self.wgts) < self.min_abs_pos] = 0

        else:
            nonzero_wgt = np.abs(self.wgts) > 0
            wgt_vs_min = np.abs(self.wgts) / self.min_abs_pos

            while np.min(wgt_vs_min[nonzero_wgt]) < 1:
                keep = np.repeat(True, len(self.wgts))
                keep[wgt_vs_min <= np.min(wgt_vs_min[nonzero_wgt])] = False

                self.setup_prob(gamma, mu=self.mu[keep], S=self.S[keep][:, keep],
                                current_wgts=self.current_wgts[keep],
                                tc_proportional=self.tc_proportional[keep],
                                tc_volume_ratio=self.tc_volume_ratio[keep],
                                tc_scale=self.tc_scale[keep],
                                exp_hold=self.exp_hold[keep],
                                beta=self.beta[keep],
                                max_pos=self.max_pos[keep], min_pos=self.min_pos[keep])

                self.use_idx = self.idx[keep]
                self.solve_try()

                nonzero_wgt = np.abs(self.wgts) > 0
                wgt_vs_min = np.abs(self.wgts) / self.min_abs_pos

    def solve_prob(self, gamma):

        self.setup_prob(gamma)

        self.use_idx = self.idx
        self.solve_try()

        if self.min_abs_pos is not None:
            self.apply_min_pos()

        return self.wgts

    def solve_range(self, gamma_range=None):

        if gamma_range is None:

            if ((self.risk_imp == 0) and (self.fast_kelly == True)):
                gamma_range = [.5]

            else:
                gamma_range = np.logspace(
                    -3 + self.risk_imp * 2,
                    0 + self.risk_imp * 2,
                    int(10 + self.risk_imp * 5)
                ) / 2

        self.wgts_range = []
        self.ret_range = []
        self.mc_range = []
        self.tc_range = []
        self.risk_range = []

        for gamma in gamma_range:

            try:
                self.solve_prob(gamma)

                self.wgts_range.append(self.wgts)
                self.ret_range.append(self.ret.value)
                self.mc_range.append(self.mc.value)
                self.tc_range.append(self.tc.value)
                self.risk_range.append(self.risk.value)

            except Exception as err:
                self.wgts_range.append(np.nan)
                self.ret_range.append(np.nan)
                self.mc_range.append(np.nan)
                self.tc_range.append(np.nan)
                self.risk_range.append(np.nan)
                if self.verbose >= 2:
                    print('error at gamma = {:.1f}:, {}'.format(gamma, err.args))

        self.wgts_range = pd.Series(self.wgts_range, index=gamma_range)

        self.ret_range = pd.Series(self.ret_range, index=gamma_range)
        self.mc_range = pd.Series(self.mc_range, index=gamma_range)
        self.tc_range = pd.Series(self.tc_range, index=gamma_range)
        self.risk_range = pd.Series(self.risk_range, index=gamma_range)

        compound_ret_range = (
                                     (self.ret_range + 1.0)
                                     / np.sqrt(
                                 (1.0 + np.power(self.risk_range / (self.ret_range + 1.0), 2)).astype('float'))
                             ) - 1.0

        eval_num = compound_ret_range - self.mc_range - self.tc_range - self.hurdle
        eval_den = np.power(self.risk_range, self.risk_imp)
        eval = eval_num / eval_den

        if np.max(eval_num) > 0:
            rank_val = eval

        elif np.max(eval_num + self.hurdle) > 0:
            rank_val = (eval_num + self.hurdle) / eval_den

        else:
            rank_val = eval_num + self.hurdle - eval_den

        self.optim_result = pd.DataFrame({
            'eval': eval,
            'rank_val': rank_val,
            'ret': self.ret_range,
            'mc': self.mc_range,
            'tc': self.tc_range,
            'risk': np.power(self.risk_range, .5),
            'wgt_net': [np.sum(x) for x in self.wgts_range],
            'wgt_gross': [np.sum(np.abs(x)) for x in self.wgts_range],
            'pos_cnt': [np.sum(np.abs(x) > 0) for x in self.wgts_range]
        }, index=gamma_range)

        if self.max_k_frac is not None:
            idx = (
                    self.optim_result['wgt_gross'] <=
                    self.max_k_frac *
                    (self.optim_result['ret'] - self.optim_result['mc'] - self.optim_result['tc'])
                    / np.power(self.optim_result['risk'], 2)
            )
        else:
            idx = np.repeat(True, self.optim_result.shape[0])

        if np.sum(idx) > 0:
            self.best_idx = self.optim_result.loc[idx, 'rank_val'].index.values[
                np.argmax(self.optim_result.loc[idx, 'rank_val'].values)]
            self.best_wgts = self.wgts_range.loc[self.best_idx]
        else:
            self.best_idx = None
            self.best_wgts = pd.Series(np.repeat(0, self.current_wgts.shape[0]), index=self.idx)

        return self.optim_result

    def report(self):

        fig = plt.figure(figsize=(10, 10));

        ax1 = plt.subplot(2, 2, 1)
        ax1.plot(self.optim_result['risk'], self.optim_result['eval']);
        ax1.axhline(0, linestyle=':', color='grey');
        ax1.set_xlabel('risk')
        ax1.set_ylabel('evaluation score')

        ax2 = plt.subplot(2, 2, 2)
        ax2.plot(self.optim_result['risk'], self.optim_result['ret']);
        ax2.axhline(self.hurdle, linestyle=':', color='grey');
        ax2.set_xlabel('risk')
        ax2.set_ylabel('return')

        ax3 = plt.subplot(2, 2, 3, sharex=ax1)
        ax3.plot(self.optim_result['risk'], self.optim_result['wgt_net'])
        ax3.axhline(0, linestyle=':', color='grey');
        ax3.axhline(1, linestyle=':', color='grey');
        ax3.set_xlabel('risk')
        ax3.set_ylabel('net pct invested')
        ax4 = plt.subplot(2, 2, 4, sharex=ax2)
        ax4.plot(self.optim_result['risk'], self.optim_result['pos_cnt'])
        ax4.axhline(0, linestyle=':', color='grey');
        ax4.axhline(len(self.mu), linestyle=':', color='grey');
        ax4.set_xlabel('risk')
        ax4.set_ylabel('number of positions')

        plt.tight_layout()

    def optimize(self, mu, S, current_wgts=0, margin_cost=0,
                 tc_proportional=0, tc_volume_ratio=0,
                 tc_scale=1, exp_hold=1, beta=1,
                 max_pos=None, min_pos=None, min_abs_pos=None,
                 hurdle=0, report=False, robust=None):

        if robust is None: robust = self.robust

        self.hurdle = hurdle

        self.setup_data(mu=mu, S=S,
                        current_wgts=current_wgts,
                        margin_cost=margin_cost,
                        tc_proportional=tc_proportional,
                        tc_volume_ratio=tc_volume_ratio,
                        tc_scale=tc_scale, exp_hold=exp_hold, beta=beta,
                        max_pos=max_pos, min_pos=min_pos,
                        min_abs_pos=min_abs_pos
                        )

        self.solve_range()

        i_try = 0

        while (i_try < 10) and (np.sum([np.sum(~np.isnan(x)) > 0 for x in self.wgts_range])) == 0:

            i_try += 1

            if self.verbose >= 1:
                print('Solvers failed.  Trying random permutation #{}'.format(i_try))

            mu_rand = mu  # + .0025*np.diag(S)*np.random.normal(size=mu.shape[0])

            e_val, e_vect = np.linalg.eig(np.array(S, dtype=np.float64))
            e_val = (e_val + np.abs(e_val)) / 2
            e_val *= np.exp(np.random.normal(scale=.01, size=e_val.shape[0]))
            S_rand = np.real(e_vect.dot(np.diag(e_val)).dot(e_vect.T))

            self.setup_data(mu=mu_rand, S=S_rand,
                            current_wgts=current_wgts,
                            margin_cost=margin_cost,
                            tc_proportional=tc_proportional,
                            tc_volume_ratio=tc_volume_ratio,
                            tc_scale=tc_scale, exp_hold=exp_hold,
                            beta=beta,
                            max_pos=max_pos, min_pos=min_pos,
                            min_abs_pos=min_abs_pos
                            )

            self.solve_range()

        if np.sum([np.sum(~np.isnan(x)) > 0 for x in self.wgts_range]) > 0:
            if robust != False:
                if robust == True:
                    n_rounds = 100
                else:
                    n_rounds = robust

                max_gross_save = self.max_gross
                max_net_save = self.max_net
                min_net_save = self.min_net
                max_gross_beta_save = self.max_gross_beta
                max_net_beta_save = self.max_net_beta
                min_net_beta_save = self.min_net_beta
                risk_limit_save = self.risk_limit
                verbose_save = self.verbose

                self.max_gross = None
                self.max_net = None
                self.min_net = None
                self.max_gross_beta = None
                self.max_net_beta = None
                self.min_net_beta = None
                self.risk_limit = None
                self.verbose = self.verbose - 1

                wgts_robust = []
                for n in range(n_rounds):
                    mu_rand = mu  # + .05*np.diag(S)*np.random.normal(size=mu.shape[0])

                    e_val, e_vect = np.linalg.eig(np.array(S, dtype=np.float64))
                    e_val = (e_val + np.abs(e_val)) / 2
                    e_val *= np.exp(np.random.normal(scale=.20, size=e_val.shape[0]))
                    S_rand = np.real(e_vect.dot(np.diag(e_val)).dot(e_vect.T))

                    self.setup_data(mu=mu_rand, S=S_rand,
                                    max_pos=4.0, min_pos=-4.0,
                                    min_abs_pos=None
                                    )

                    try:
                        self.solve_prob(self.best_idx)
                        wgts_robust.append(self.wgts)
                    except:
                        continue

                if len(wgts_robust) > 0:
                    self.wgts_robust = pd.concat(wgts_robust, axis=1).mean(axis=1)
                else:
                    self.wgts_robust = pd.Series(0, index=self.use_idx).reindex(self.idx).fillna(0)

                p_mu = np.dot(mu, self.wgts_robust)
                p_s = np.dot(np.dot(self.wgts_robust, S), self.wgts_robust)
                p_lambda = (p_mu - self.hurdle) / p_s

                p_pi = np.dot(np.dot(p_lambda, S), self.wgts_robust)

                if np.sum(np.isnan(p_pi)) < p_pi.shape[0]:

                    if isinstance(mu, pd.core.series.Series):
                        p_pi = pd.Series(p_pi, index=mu.index)

                    p_pi.fillna(self.hurdle)

                    self.max_gross = max_gross_save
                    self.max_net = max_net_save
                    self.min_net = min_net_save
                    self.max_gross_beta = max_gross_beta_save
                    self.max_net_beta = max_net_beta_save
                    self.min_net_beta = min_net_beta_save
                    self.risk_limit = risk_limit_save
                    self.verbose = verbose_save

                    self.setup_data(mu=p_pi, S=S,
                                    current_wgts=current_wgts,
                                    margin_cost=margin_cost,
                                    tc_proportional=tc_proportional,
                                    tc_volume_ratio=tc_volume_ratio,
                                    tc_scale=tc_scale, exp_hold=exp_hold, beta=beta,
                                    max_pos=max_pos, min_pos=min_pos,
                                    min_abs_pos=min_abs_pos
                                    )

                    self.solve_range()

                else:
                    self.best_idx = None
                    self.best_wgts = pd.Series(np.repeat(0, self.current_wgts.shape[0]), index=self.idx)

        else:
            if self.verbose >= 1:
                print('Something went wrong.  Persisting current weights.')
            self.best_wgts = pd.Series(self.current_wgts, index=self.idx)

        if report == True:
            self.report()

        return self.optim_result, self.best_idx, self.best_wgts


def expected_drawdown(mu, var, t):
    # this is the analytical prediction for the drawdown of a Brownian motion
    # mu and var inputs should be in log form
    # output is in linear % form
    mu = pd.Series(mu)
    var = pd.Series(var)
    g = np.sqrt(np.pi / 8.0)

    dd = pd.Series(index=var.index)

    def EMDD(m, s, T):  # m: log_return
        bar = 1e-3
        if m > 0.:
            if abs(s) < bar:
                return 0.
            else:
                co = 2. * s ** 2 / m
                x = 0.5 * T * m ** 2 / s ** 2
                return Qp(x) * co

        if m == 0.:
            return g * 2.0 * s * np.power(T, .5)

        if m < 0.:
            if abs(s) < bar:
                return 0.
            else:
                co = 2. * s ** 2 / m
                x = 0.5 * T * m ** 2 / s ** 2
                return -Qn(x) * co

    xps = np.array([0.0005, 0.0010, 0.0015, 0.0020, 0.0025, 0.0050, 0.0075, 0.0100,
                    0.0125, 0.0150, 0.0175, 0.0200, 0.0225, 0.0250, 0.0275, 0.0300,
                    0.0325, 0.0350, 0.0375, 0.0400, 0.0425, 0.0450, 0.0500, 0.0600,
                    0.0700, 0.0800, 0.0900, 0.1000, 0.2000, 0.3000, 0.4000, 0.5000,
                    1.5000, 2.5000, 3.5000, 4.5000, 10.0000, 20.0000, 30.0000, 40.0000,
                    50.0000, 150.0000, 250.0000, 350.0000, 450.0000, 1000.0000,
                    2000.0000, 3000.0000, 4000.0000, 5000.0000
                    ])
    Qps = Qps = np.array([
        0.019690, 0.027694, 0.033789, 0.038896, 0.043372, 0.060721, 0.073808, 0.084693,
        0.094171, 0.102651, 0.110375, 0.117503, 0.124142, 0.130374, 0.136259, 0.141842,
        0.147162, 0.152249, 0.157127, 0.161817, 0.166337, 0.170702, 0.179015, 0.194248,
        0.207999, 0.220581, 0.232212, 0.243050, 0.325071, 0.382016, 0.426452, 0.463159,
        0.668992, 0.775976, 0.849298, 0.905305, 1.088998, 1.253794, 1.351794, 1.421860,
        1.476457, 1.747485, 1.874323, 1.958037, 2.020630, 2.219765,
        2.392826, 2.494109, 2.565985, 2.621743
    ])

    xns = np.array([
        0.0005, 0.0010, 0.0015, 0.0020, 0.0025, 0.0050, 0.0075, 0.0100,
        0.0125, 0.0150, 0.0175, 0.0200, 0.0225, 0.0250, 0.0275, 0.0300,
        0.0325, 0.0350, 0.0375, 0.0400, 0.0425, 0.0450, 0.0475, 0.0500,
        0.0550, 0.0600, 0.0650, 0.0700, 0.0750, 0.0800, 0.0850, 0.0900,
        0.0950, 0.1000, 0.1500, 0.2000, 0.2500, 0.3000, 0.3500, 0.4000,
        0.5000, 1.0000, 1.5000, 2.0000, 2.5000, 3.0000, 3.5000, 4.0000,
        4.5000, 5.0000
    ])
    Qns = Qns = np.array([
        0.019965, 0.028394, 0.034874, 0.040369, 0.045256, 0.064633, 0.079746, 0.092708,
        0.104259, 0.114814, 0.124608, 0.133772, 0.142429, 0.150739, 0.158565, 0.166229,
        0.173756, 0.180793, 0.187739, 0.194489, 0.201094, 0.207572, 0.213877, 0.220056,
        0.231797, 0.243374, 0.254585, 0.265472, 0.276070, 0.286406, 0.296507, 0.306393,
        0.316066, 0.325586, 0.413136, 0.491599, 0.564333, 0.633007, 0.698849, 0.762455,
        0.884593, 1.445520, 1.970740, 2.483960, 2.990940, 3.492520,
        3.995190, 4.492380, 4.990430, 5.498820
    ])

    def linear(x, x1, y1, x2, y2):
        return y1 + ((y2 - y1) / (x2 - x1)) * (x - x1)

    def nearest_index(array, value):  # array doesn't have to be sorted
        return (np.abs(array - value)).argmin()  # the index, array[returned]=the closest value

    def interp(x, sign):  # x must be in [0.0005,5000]
        if sign == 'positive':
            xs = xps.copy()
            Qs = Qps.copy()
        if sign == 'negative':
            xs = xns.copy()
            Qs = Qns.copy()

        ind = nearest_index(xs, x)  # xs must be sorted
        if ind == 0:
            return linear(x, xs[0], Qs[0], xs[1], Qs[1])
        elif ind == len(xs) - 1:
            return linear(x, xs[-1], Qs[-1], xs[-2], Qs[-2])
        else:
            if x > xs[ind]:
                return linear(x, xs[ind], Qs[ind], xs[ind + 1], Qs[ind + 1])
            elif x < xs[ind]:
                return linear(x, xs[ind], Qs[ind], xs[ind - 1], Qs[ind - 1])
            else:
                return Qs[ind]

    def Qp(x):
        if x < 0.0005:
            return np.sqrt(np.pi / 8.) * np.sqrt(2. * x)
        elif x > 5000.:
            return 0.25 * np.log(x) + 0.49088
        else:
            return interp(x, 'positive')

    def Qn(x):
        if x < 0.0005:
            return np.sqrt(np.pi / 8.) * np.sqrt(2. * x)
        elif x > 5.:
            return x + 0.5
        else:
            return interp(x, 'negative')

    for n in range(len(dd)):
        dd.iloc[n] = EMDD(mu.iloc[n], np.power(var.iloc[n], .5), t)

    dd = np.exp(-dd) - 1

    return dd


