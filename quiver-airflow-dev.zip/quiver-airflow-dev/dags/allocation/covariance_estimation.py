import numpy as np
import pandas as pd

from sklearn.covariance import LedoitWolf
from scipy.optimize import minimize
from sklearn.neighbors import KernelDensity
import scipy.cluster.hierarchy as sch


def cov2corr(cov):
    std = np.sqrt(np.diag(cov))
    corr = cov / np.outer(std, std)
    corr[corr < -1], corr[corr > 1] = -1, 1

    return corr


def corr2cov(corr, std):
    cov = corr * np.outer(std, std)

    return cov


def mpPDF(var, q, pts):
    eMin, eMax, = var * (1 - (1. / q) ** .5) ** 2, var * (1 + (1. / q) ** .5) ** 2
    eVal = np.linspace(eMin, eMax, pts)
    pdf = q / (2 * np.pi * var * eVal) * ((eMax - eVal) * (eVal - eMin)) ** .5
    pdf = pd.Series(pdf, index=eVal)

    return pdf


def getPCA(matrix):
    eVal, eVec = np.linalg.eigh(matrix)
    indices = eVal.argsort()[::-1]
    eVal, eVec = eVal[indices], eVec[indices]
    eVal = np.diagflat(eVal)

    return eVal, eVec


def fitKDE(obs, bWidth=.25, kernel='gaussian', x=None):
    if len(obs.shape) == 1: obs = obs.reshape(-1, 1)
    kde = KernelDensity(kernel=kernel, bandwidth=bWidth).fit(obs)
    if x is None: x = np.unique(obs).reshape(-1, 1)
    if len(x.shape) == 1: x = x.reshape(-1, 1)
    logProb = kde.score_samples(x)
    pdf = pd.Series(np.exp(logProb), index=x.flatten())

    return pdf


def errPDFs(var, eVal, q, bWidth, pts=1000):
    pdf0 = mpPDF(var[0], q, pts)
    pdf1 = fitKDE(eVal, bWidth, x=pdf0.index.values)
    sse = np.sum((pdf1 - pdf0) ** 2)

    return sse


def findMaxEval(eVal, q, bWidth):
    out = minimize(lambda *x: errPDFs(*x), .5, args=(eVal, q, bWidth), bounds=((1E-5, 1 - 1E-5),))
    if out['success']:
        var = out['x'][0]
    else:
        var = 1
    eMax = var * (1 + (1. / q) ** .5) ** 2

    return eMax, var


def denoisedCorr(eVal, eVec, nFacts):
    eVal_ = np.diag(eVal).copy()
    eVal_[nFacts:] = eVal_[nFacts:].sum() / float(eVal_.shape[0] - nFacts)
    eVal_ = np.diag(eVal_)
    corr1 = np.dot(eVec, eVal_).dot(eVec.T)
    corr1 = cov2corr(corr1)

    return corr1


def denoisedCorr2(eVal, eVec, nFacts, alpha=0):
    eValL, eVecL = eVal[:nFacts, :nFacts], eVec[:, :nFacts]
    eValR, eVecR = eVal[nFacts:, nFacts:], eVec[:, nFacts:]
    corr0 = np.dot(eVecL, eValL).dot(eVecL.T)
    corr1 = np.dot(eVecR, eValR).dot(eVecR.T)
    corr2 = corr0 + alpha * corr1 + (1 - alpha) * np.diag(np.diag(corr1))

    return corr2


def denoisedCov(cov0, q, bWidth):
    corr0 = cov2corr(cov0)
    eVal0, eVec0 = getPCA(corr0)
    eMax0, var0 = findMaxEval(np.diag(eVal0), q, bWidth)
    nFacts0 = eVal0.shape[0] - np.diag(eVal0)[::-1].searchsorted(eMax0)
    corr1 = denoisedCorr(eVal0, eVec0, nFacts0)
    cov1 = corr2cov(corr1, np.diag(cov0) ** .5)

    return cov1


def denoisedCov2(cov0, q, bWidth):
    corr0 = cov2corr(cov0)
    eVal0, eVec0 = getPCA(corr0)
    eMax0, var0 = findMaxEval(np.diag(eVal0), q, bWidth)
    nFacts0 = eVal0.shape[0] - np.diag(eVal0)[::-1].searchsorted(eMax0)
    corr1 = denoisedCorr2(eVal0, eVec0, nFacts0)
    cov1 = corr2cov(corr1, np.diag(cov0) ** .5)

    return cov1


def getQuasiDiag(link0):
    link = link0.astype(int)
    sortIx = pd.Series([link[-1, 0], link[-1, 1]])
    numItems = link[-1, 3]

    while sortIx.max() >= numItems:
        sortIx.index = range(0, len(sortIx) * 2, 2)  # make space
        df0 = sortIx[sortIx >= numItems]  # find clusters
        i = df0.index;
        j = df0.values - numItems
        sortIx[i] = link[j, 0]
        df0 = pd.Series(link[j, 1], index=i + 1)
        sortIx = sortIx.append(df0)
        sortIx = sortIx.sort_index()
        sortIx.index = range(len(sortIx))
    return sortIx.tolist()


def getClusterVar(cov, mu, cItems):
    V = cov[np.ix_(cItems, cItems)]
    m = mu[cItems]
    d = m / np.diag(V)
    w = d / d.sum()
    return w @ V @ w


def getVarBipart(cov, mu, sortIx):
    w = pd.Series(1, index=sortIx, name='wt')
    cItem = [sortIx]
    while len(cItem) > 0:
        cItem = [i[j:k] for i in cItem for j, k in ((0, int(len(i) * 0.5)), (int(len(i) * 0.5), len(i))) if len(i) > 1]
        for i in range(0, len(cItem), 2):
            cItem0, cItem1 = cItem[i], cItem[i + 1]
            cVar0 = getClusterVar(cov, mu, cItem0)
            cVar1 = getClusterVar(cov, mu, cItem1)
            a = cVar1 / (cVar0 + cVar1)
            w[cItem0] *= a
            w[cItem1] *= 1 - a

    v = 1.0 / w

    return v


def calc_hrt(cov):
    dist = np.sqrt((1 - cov2corr(cov)) * 0.5)
    link0 = sch.linkage(dist, 'single')
    sortIx = getQuasiDiag(link0)
    v = getVarBipart(cov.values, np.repeat(1.0, cov.shape[0]), sortIx)

    cov = pd.DataFrame(0, index=cov.index, columns=cov.columns)
    np.fill_diagonal(cov.values, v)

    return cov


def estimate_covariance(r, ledoitwolf=True, denoise=False, denoise2=False, hrt=False, pessimist=0.0):
    cov = r.unstack().cov().dropna(how='all')
    cov = cov.loc[:, cov.index.values]
    corr = cov2corr(cov)
    corr_values = corr[corr.abs() < 1].values.flatten()
    corr_values = corr_values[np.isfinite(corr_values)]
    corr_mean = np.mean(corr_values)
    corr.fillna(corr_mean, inplace=True)
    cov = corr2cov(corr, np.diag(cov) ** .5)
    cov0 = cov.copy()

    if ledoitwolf is True:
        cov0 = pd.DataFrame(LedoitWolf().fit(r.unstack().fillna(r.unstack().mean())[cov0.columns]).covariance_,
                            index=cov0.columns, columns=cov.columns)

    if denoise is True:
        cov0 = pd.DataFrame(denoisedCov(cov0, r.unstack().shape[0] / cov0.shape[1], .01), index=cov0.index,
                            columns=cov0.columns)

    if denoise2 is True:
        cov0 = pd.DataFrame(denoisedCov2(cov0, r.unstack().shape[0] / cov0.shape[1], .01), index=cov0.index,
                            columns=cov0.columns)

    cov0_diag = np.diag(cov0.values)

    cov0_non_diag = cov0.copy()
    np.fill_diagonal(cov0_non_diag.values, np.nan)

    cov_non_diag = cov.copy()
    np.fill_diagonal(cov_non_diag.values, np.nan)

    cov_diff = cov_non_diag.mean().mean() - cov0_non_diag.mean().mean()

    if cov_diff > 0:
        cov_diff *= 0.5 * cov0_diag / np.sum(cov0_diag)
        cov0 += cov_diff
        cov0 = (cov0.T + cov_diff).T
        np.fill_diagonal(cov0.values, cov0_diag)

    cov_diff = cov.mean() - cov0.mean()
    np.fill_diagonal(cov0.values,
                     [x[0] + x[1] if x[1] > 0 else x[0]
                      for x in zip(cov0_diag, cov_diff.values)])
    '''
    cov_ratio = cov.mean() / cov0.mean()
    cov_ratio.fillna(cov_ratio.mean(), inplace=True)
    cov_ratio[cov_ratio<1] = 1.0
    cov_ratio = cov_ratio.pow(.5)
    cov0 *= cov_ratio
    cov0 = (cov0.T * cov_ratio).T
    '''
    if hrt is True:
        cov0 = calc_hrt(cov0)

        cov0 *= cov.mean().mean() / cov0.mean().mean()

    if pessimist > 0:
        cov0_diag = np.diag(cov0.values)
        cov0_non_diag = cov0.copy()
        np.fill_diagonal(cov0_non_diag.values, np.nan)
        cov0_non_diag += pessimist * cov0_diag / (cov0_diag.shape[0] - 1) / 2.0
        cov0_non_diag = (cov0_non_diag.T + pessimist * cov0_diag / (cov0_diag.shape[0] - 1) / 2.0).T
        np.fill_diagonal(cov0_non_diag.values, (1 - pessimist) * cov0_diag)
        cov0 = cov0_non_diag

    return cov0