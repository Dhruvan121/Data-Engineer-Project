import numpy as np
import pandas as pd
import itertools as it
import sqlalchemy as sa
import pickle
import gzip
import boto3
import base64
import os
import pandas
import warnings

from collections.abc import Iterable
from scipy.stats import norm, nct, gumbel_l
from io import StringIO, BytesIO
from urllib import parse

from helpers.utils import get_s3_client
from allocation.covariance_estimation import estimate_covariance
from allocation.ptools import optimize_port
from allocation.expectations import Benchmark_ARX, Strategy_CAPM

warnings.filterwarnings("always", category=FutureWarning, module="arch.__future__._utility", message="The default for reindex is True.*")
pandas.options.mode.chained_assignment = None  # To silence the warning

def upload_df_to_s3(df, bucket_name, file_name):
    s3 = get_s3_client()
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)
    s3.upload_fileobj(BytesIO(csv_buffer.getvalue().encode()), bucket_name, file_name)
  

def read_s3_as_df( bucket_name, file_name):
    s3 = get_s3_client()
    obj = s3.get_object(Bucket=bucket_name, Key=file_name)
    df = pd.read_csv(obj['Body'], encoding='utf-8')
    return df



def get_quiver_db_engine():
    # quiverdb_URL =  os.environ['AIRFLOW_CONN_QUIVER_LOCAL']
    # quiverdb_username = os.environ['AIRFLOW_CONN_QUIVER_LOCAL_USER']
    # quiverdb_pwd = os.environ['AIRFLOW_CONN_QUIVER_LOCAL_PWD']
    # quiverdb_config = 'postgresql://{}:{}@{}'.format(
    #     quiverdb_username,
    #     quiverdb_pwd, 
    #     quiverdb_URL
    # )
    quiverdb_config = os.environ['AIRFLOW_CONN_QUIVER_LOCAL']
    quiverdb_engine = sa.create_engine(quiverdb_config)
    return quiverdb_engine


def import_kelly_allocation_results(testId, json_data):
    quiverdb_engine = get_quiver_db_engine() 
    query=f"select ocm.import_kelly_allocation_results({testId}, '{str(json_data)}')"    
    quiverdb_engine.execute(query)

def calc_eqfixedmodelweightages(testId):
    quiverdb_engine = get_quiver_db_engine() 
    query=f"select * from ocm.calc_eqfixedmodelweightages({testId})"    
    quiverdb_engine.execute(query)

def calc_allocationmetricdata(testId,testmodelid):
    quiverdb_engine = get_quiver_db_engine() 
    query=f"select * from ocm.calc_allocationmetricdata({testId},{testmodelid})"    
    quiverdb_engine.execute(query)

def finish_allocationtest(testId):
    quiverdb_engine = get_quiver_db_engine() 
    query=f"select * from ocm.finish_allocationtest({testId});"
    quiverdb_engine.execute(query)

def cancel_allocationtest(testId):
    quiverdb_engine = get_quiver_db_engine() 
    query=f"select * from ocm.cancel_allocationtest({testId});"
    quiverdb_engine.execute(query)


def get_calc_weight_test_id():
    quiverdb_engine = get_quiver_db_engine() 
    conn = quiverdb_engine.connect()
    query="select ocm.get_allocationteststorun()"    
    res = pd.read_sql_query(query, conn)
    return res['get_allocationteststorun']


def get_remaining_minutes(perc):
    rt = 20
    if 0 < perc <= 10:
        rt = 20
    elif 10 < perc <= 20:
        rt = 18
    elif 20 < perc <= 30:
        rt = 16
    elif 30 < perc <= 40:
        rt = 14
    elif 40 < perc <= 50:
        rt = 12
    elif 50 < perc <= 60:
        rt = 10
    elif 60 < perc <= 70:
        rt = 8
    elif 70 < perc <= 80:
        rt = 6
    elif 80 < perc <= 90:
        rt = 4
    elif 90 < perc < 100:
        rt = 2
    elif perc == 100:
        rt = 0
    
    return rt

def update_allocationtestprogress(testid, perc):
    quiverdb_engine = get_quiver_db_engine() 
    conn = quiverdb_engine.connect()
    rt = get_remaining_minutes(perc)
    query=f"select ocm.update_allocationtestprogress({testid},{perc}, {rt});"    
    res = pd.read_sql_query(query, conn)
    print("*"*100)
    print("value of update_allocationtestprogress->", res['update_allocationtestprogress'])
    print("*"*100)
    return res['update_allocationtestprogress'][0]


def get_strategy_data(filter_port=None, loc='data/cache_strategy_data.pkl'):

    quiverdb_engine = get_quiver_db_engine() 

    redshift_config =  os.environ['AIRFLOW_CONN_FACTOR_SERVER']
    redshift_engine = sa.create_engine(redshift_config)

    if filter_port is None:
        filter_port = ''
    else:
        filter_port = ' and p.portfolioid in (' + ('{},' * len(filter_port)).format(*filter_port)[:-1] + ')'

    query_port = '''
    select p.portfolioid, p.shortname, b.portfoliosubtype, i.marketindexosid
    from portfolio p
    inner join portfoliobasecustom b on b.portfoliobaseid = p.portfolioid
    inner join portfinitialvalues i on i.portfolioid = p.portfolioid
    where b.portfoliosubtype in (
        'Discretionary',
        'Algorithmic'
        ) {}
    ;
    '''.format(filter_port)

    query_items = '''
    select r.itemid, r.displayname, r.definition
    from ref.dataitem r
    where r.itemid in ({})
    ;
    '''

    query = '''
    select * from ocm.get_analyticschartdata
    (
        '{}',              
        now()::date,     
        {},            
        1,             
        22,          
        'FALSE',     
        0,           
        null       
    );

    '''

    query_bench = ''' 
    select p.osid, to_date(p.tradedate,'YYYYMMDD') as Date,
    p.pricepctchgd, p.unadjustedpriceclose
    from ts_techanalysis p
    where p.osid in ({});
    '''

    query_rf = '''
    select to_date(tradedate,'YYYYMMDD') as Date, 
        ln(cast(1+priceclose/100.0 as double precision))/252 as rf
    from ts_techanalysis
    where osid = (select osid from ts_instrument where symbol = '0B3MO')
    '''

    itemids = [22, 46, 47, 226
        , 85, 86, 103, 14, 23
               ]
    # itemids = [22, 46]

    '''
    97 years of trading
    6 assigned manager

    66 account type
    199 management style
    100 style
    101 methodology
    8 investment method

    254 turnover
    54 avg days held

    95  # positions
    103 top 3 weight

    75  winlossratio
    85  winlossratio100trades
    76  winpct
    86  winpct100trades

    23 lmv limit
    14 AUM

    '''

    conn = quiverdb_engine.connect()

    print("*"*100)
    print("fetching d_port")
    print("*"*100)

    d_port = pd.read_sql_query(query_port, conn).set_index('portfolioid')
    conn.close()
    

    conn = quiverdb_engine.connect()

    d = []

    for x in it.product(d_port.index.values, itemids):
 
        try:
            res = pd.read_sql_query(query.format(*x), conn)
            res['itemid'] = x[1]
            d.append(res)
        except Exception as err:
            print(err)
            pass

    conn.close()

    df = pd.concat(d)
    df.drop('year', axis=1, inplace=True)
    dcol = list(df.columns)
    dcol[0] = 'portfolioid'
    df.columns = dcol
    df['date'] = pd.DatetimeIndex(df['date'])

    df = df.set_index(['portfolioid', 'date', 'itemid']).unstack()['value']

    d_items = pd.Series(
        ['AUM', 'net_inv', 'lmv_limit', 'long_inv', 'short_inv', 'eq', 'pl_ratio', 'hit_rate', 'top_3_wgt']
        , index=[14, 22, 23, 46, 47, 226, 85, 86, 103]
        )
    
    df.columns = [d_items.loc[x] if x in d_items.index else x for x in df.columns]
    df['short_inv'] = pd.to_numeric(df['short_inv'], errors='coerce')
    df['long_inv'] = pd.to_numeric(df['long_inv'], errors='coerce')

    # df.loc[np.isnan(df['short_inv']), 'short_inv'] = (
    #         df.loc[np.isnan(df['short_inv']), 'net_inv']
    #         - df.loc[np.isnan(df['short_inv']), 'long_inv']
    # )
    # df.loc[np.isnan(df['short_inv']), 'short_inv'] = 0

    # df.loc[np.isnan(df['long_inv']), 'long_inv'] = (
    #         df.loc[np.isnan(df['long_inv']), 'net_inv']
    #         - df.loc[np.isnan(df['long_inv']), 'short_inv']
    # )
    # df.loc[np.isnan(df['long_inv']), 'long_inv'] = df.loc[np.isnan(df['long_inv']), 'net_inv']
    # df.loc[np.isnan(df['long_inv']), 'long_inv'] = 0

    # Replace NaN values in 'short_inv'
    short_inv_is_nan = np.isnan(df['short_inv'])
    df.loc[short_inv_is_nan, 'short_inv'] = df.loc[short_inv_is_nan, 'net_inv'] - df.loc[short_inv_is_nan, 'long_inv']
    df['short_inv'].fillna(0, inplace=True)
   
    # Replace NaN values in 'long_inv'
    long_inv_is_nan = np.isnan(df['long_inv'])
    df.loc[long_inv_is_nan, 'long_inv'] = df.loc[long_inv_is_nan, 'net_inv'] - df.loc[long_inv_is_nan, 'short_inv']
    df['long_inv'].fillna(0, inplace=True)
    df['lmv_limit'] = df['lmv_limit'].div(100)
    df['long_inv'] = df['long_inv'].div(100)
    df['short_inv'] = df['short_inv'].div(100)
    df['top_3_wgt'] = df['top_3_wgt'].div(100).groupby('portfolioid').fillna(method='ffill').fillna(0)
    df['pl_ratio'] = df['pl_ratio'].groupby('portfolioid').fillna(method='ffill').fillna(1)
    df['log_pl_ratio'] = np.log(df['pl_ratio']).fillna(0)
    df['hit_rate'] = df['hit_rate'].div(100).replace(0, np.nan).groupby('portfolioid').fillna(method='ffill').fillna(
        0.5)

    df.sort_index(inplace=True)
    df['eq'] = pd.to_numeric(df['eq'], errors='coerce')

    # df['r'] = df.groupby('portfolioid').apply(lambda x: np.log(((x['eq'] + 100) / (x['eq'] + 100).shift(1)))).droplevel(
    #     0)
    # df = df[~np.isnan(df['r'])]

    # Calculate 'r' column
    def calculate_log_returns(group):
        return np.log((group['eq'] + 100) / (group['eq'] + 100).shift(1))

    df['r'] = df.groupby(level=0).apply(calculate_log_returns).droplevel(0)

    # If you want to handle NaN values in 'r' (optional)
    df['r'].fillna(0, inplace=True)
    
    # Get all the benchmark data, plus 17304 as a backup
    benchids = np.unique(np.concatenate([d_port['marketindexosid'].values, [17304]]))

    print("*"*100)
    print(f"feched  benchids-> {str(benchids)}")
    print("*"*100)

    conn = redshift_engine.connect()

    df_bench = pd.read_sql_query(query_bench.format(('{},' * len(benchids)).format(*benchids)[:-1]), conn)

    conn.close()

    print("*"*100)
    print("df_bench")
    print("*"*100)
    print(df_bench)
    print("*"*100)

    dcol = list(df_bench.columns)
    dcol[0] = 'marketindexosid'
    df_bench.columns = dcol

    df_bench['date'] = pd.DatetimeIndex(df_bench['date'])

    df_bench = df_bench.set_index(['marketindexosid', 'date']).sort_index()
    df_bench['r'] = df_bench.groupby(level=0).apply(
        lambda x: np.log(((x['unadjustedpriceclose']) / (x['unadjustedpriceclose']).shift(1)))).droplevel(0)

    conn = redshift_engine.connect()

    df_rf = pd.read_sql_query(query_rf, conn)

    conn.close()

    df_rf['date'] = pd.DatetimeIndex(df_rf['date'])
    df_rf = df_rf.set_index('date').sort_index()

    df = df.join(d_port, on='portfolioid').join(
        df_bench, on=['marketindexosid', 'date'], rsuffix='_bench'
    ).join(
        df_bench.loc[17304], on='date', rsuffix='_bench_backup'
    )[[
        'shortname', 'portfoliosubtype', 'marketindexosid',
        'AUM', 'lmv_limit',
        'long_inv', 'short_inv', 'r',
        'r_bench', 'r_bench_backup',
        'log_pl_ratio', 'hit_rate', 'top_3_wgt'
    ]]

    df.loc[np.isnan(df['r_bench']), 'r_bench'] = df.loc[np.isnan(df['r_bench']), 'r_bench_backup']

    df.dropna(inplace=True)

    df = df.join(df_rf, on='date')

    df = df.swaplevel().sort_index()

    df_bench = df_bench.join(df_rf, on='date').fillna(method='ffill').fillna(0)

    result = {'df': df, 'df_bench': df_bench}

    return result


# def get_agg_data(df, date_agg=None):
#     df['AUM_last'] = df['AUM'].values
#     df['long_inv_last'] = df['long_inv'].values
#     df['short_inv_last'] = df['short_inv'].values
#     df['top_3_wgt_last'] = df['top_3_wgt'].values
#     df['log_pl_ratio_last'] = df['log_pl_ratio'].values
#     df['hit_rate_last'] = df['hit_rate'].values

#     if date_agg is None:
#         result = df
#     else:
#         result = df.groupby([pd.Grouper(level='date', freq=date_agg), pd.Grouper(level='portfolioid')]
#                             ).agg({'shortname': 'last', 'portfoliosubtype': 'last', 'marketindexosid': 'last',
#                                    'lmv_limit': 'last',
#                                    'AUM': 'mean', 'AUM_last': 'last',
#                                    'r': 'sum', 'r_bench': 'sum', 'rf': 'sum',
#                                    'long_inv': 'mean', 'long_inv_last': 'last',
#                                    'short_inv': 'mean', 'short_inv_last': 'last',
#                                    'top_3_wgt': 'mean', 'top_3_wgt_last': 'last',
#                                    'log_pl_ratio': 'mean', 'log_pl_ratio_last': 'last',
#                                    'hit_rate': 'mean', 'hit_rate_last': 'last'
#                                    })

#     return result


def get_agg_data(df, date_agg=None):
    # Ensure that numeric columns are of the correct data type
    numeric_columns = ['AUM', 'r', 'r_bench', 'rf', 'long_inv', 'short_inv', 'top_3_wgt', 'log_pl_ratio', 'hit_rate']
    for col in numeric_columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')  # Convert non-numeric values to NaN

    # Create new columns for the last values
    df['AUM_last'] = df.groupby('portfolioid')['AUM'].transform('last')
    df['long_inv_last'] = df.groupby('portfolioid')['long_inv'].transform('last')
    df['short_inv_last'] = df.groupby('portfolioid')['short_inv'].transform('last')
    df['top_3_wgt_last'] = df.groupby('portfolioid')['top_3_wgt'].transform('last')
    df['log_pl_ratio_last'] = df.groupby('portfolioid')['log_pl_ratio'].transform('last')
    df['hit_rate_last'] = df.groupby('portfolioid')['hit_rate'].transform('last')

    if date_agg is None:
        result = df
    else:
        result = df.groupby([pd.Grouper(level='date', freq=date_agg), 'portfolioid']).agg({
            'shortname': 'last',
            'portfoliosubtype': 'last',
            'marketindexosid': 'last',
            'lmv_limit': 'last',
            'AUM': 'mean',
            'AUM_last': 'last',
            'r': 'sum',
            'r_bench': 'sum',
            'rf': 'sum',
            'long_inv': 'mean',
            'long_inv_last': 'last',
            'short_inv': 'mean',
            'short_inv_last': 'last',
            'top_3_wgt': 'mean',
            'top_3_wgt_last': 'last',
            'log_pl_ratio': 'mean',
            'log_pl_ratio_last': 'last',
            'hit_rate': 'mean',
            'hit_rate_last': 'last'
        })
    return result



def get_agg_data_bench(df, date_agg=None):
    if date_agg is None:
        result = df
    else:
        result = df.groupby([pd.Grouper(level='date', freq=date_agg), pd.Grouper(level='marketindexosid')]
                            ).agg({'r': 'sum', 'rf': sum})

    return result


def get_benchmark_expectations(df, dt_range=None, n=1,
                               model=Benchmark_ARX(),
                               loc='data\cache_benchmark_expectations.pkl'):
    if dt_range is None:
        dt_range = np.unique(df.index.get_level_values(0))

    dt_mu = []
    dt_var = []

    # Start the loop
    for dt in dt_range:

        # Find which benchmarks were active as of the date
        dt_port_1 = df.loc[dt].index.values

        # Include only data we would have known at the time
        df_dt = df[df.index.get_level_values(0) < dt].swaplevel().copy()

        # Find benchmarks that had some known data
        dt_port_2 = np.unique(df_dt.index.get_level_values(0))

        dt_port = dt_port_2[[True if x in dt_port_1 else False for x in dt_port_2]]

        # Make predictions about mu and var for each benchmarks
        preds = []
        for port in dt_port:
            port = int(port)
            df_port = df_dt.loc[port]

            if df_port.shape[0] >= 3:
                try:
                    model.fit(df_port['r'] - df_port['rf'])
                    pred = model.predict(n)
                    pred = list(pred)
                    pred[0] = pred[0] + df_port['rf'].iloc[-1]
                    pred = tuple(pred)
                except Exception as err:
                    print('Expectation Error:', dt, port, err)                    
                    pred = (np.nan, np.nan)
            else:
                pred = (np.nan, np.nan)

            preds.append(pred)

        mu = pd.Series([np.array(x[0]).flatten()
                        if isinstance(x[0], Iterable)
                        else x[0]
                        for x in preds]
                       , index=dt_port, name=dt)
        mu.index.name = 'marketindexosid'
        var = pd.Series([np.array(x[1]).flatten()
                         if isinstance(x[1], Iterable)
                         else x[1]
                         for x in preds]
                        , index=dt_port, name=dt)
        var.index.name = 'marketindexosid'

        dt_mu.append(mu)
        dt_var.append(var)

    mu = pd.concat(dt_mu, axis=1).stack().dropna().swaplevel().sort_index()
    mu.index.rename(['date', 'marketindexosid'], inplace=True)
    var = pd.concat(dt_var, axis=1).stack().dropna().swaplevel().sort_index()
    var.index.rename(['date', 'marketindexosid'], inplace=True)

    result = {'mu': mu, 'var': var}


    return result


def get_strategy_expectations(df, dt_range=None, filter_query=None, n=1, be=None,
                              model=Strategy_CAPM(),
                              loc='data\cache_strategy_expectations.pkl',
                              verbose=False):
    if filter_query is not None:
        df = df.query(filter_query).copy()

    if dt_range is None:
        dt_range = pd.DatetimeIndex(np.unique(df.index.get_level_values(0)))

    dt_mu = []
    dt_var = []
    dt_long_inv = []
    dt_short_inv = []

    # dt_range = dt_range[:2]
    for dt in dt_range:

        # Find which portfolios were active as of the date
        dt_port_1 = df.loc[dt].index.values

        # Include only data we would have known at the time
        df_dt = df[df.index.get_level_values(0) < dt].swaplevel().copy()

        if verbose is True: print('Expecations:', dt, df_dt.shape[0])

        # Find portfolios that had some known data
        dt_port_2 = np.unique(df_dt.index.get_level_values(0))

        dt_port = dt_port_2[[True if x in dt_port_1 else False for x in dt_port_2]]

        if be is not None:
            if np.min(be['mu'].index.get_level_values(0)) <= dt:
                dt_mu_bench = be['mu'].loc[dt]
                dt_var_bench = be['var'].loc[dt]
            else:
                dt_mu_bench = None
                dt_var_bench = None
        else:
            dt_mu_bench = None
            dt_var_bench = None

        # Make predictions about mu and var for each portfolio
        preds = []
        report = []
        print("get_strategy_expectations", "$"*200, "dt_port in loop " + str(dt))
        print(dt_port)
        print("$"*200)
        for port in dt_port:
            port = int(port)
            df_port = df_dt.loc[port]
            marketindexosid = df_port['marketindexosid'][-1]            
            if dt_mu_bench is not None:
                if marketindexosid in dt_mu_bench.index.values:
                    marketindexosid = int(marketindexosid)
                    dt_mu_bench_port = dt_mu_bench.loc[marketindexosid]
                    dt_var_bench_port = dt_var_bench.loc[marketindexosid]
                else:
                    dt_mu_bench_port = None
                    dt_var_bench_port = None
            else:
                dt_mu_bench_port = None
                dt_var_bench_port = None

            if df_port.shape[0] >= 3:
                try:
                    model.fit(df_port)
                    pred = model.predict(n, dt_mu_bench_port, dt_var_bench_port)
                    pred = list(pred)
                    pred[0] = pred[0] + df_port['rf'].iloc[-1]
                    pred = tuple(pred)
                except Exception as err:
                    print('Expectation Error:', dt, port, err)
                    pred = (np.nan, np.nan, np.nan, np.nan)
            else:
                pred = (np.nan, np.nan, np.nan, np.nan)
                # summary = np.nan
            preds.append(pred)
            # report.append(summary)
        mu = pd.Series([np.mean(x[0]) for x in preds], index=dt_port, name=dt)
        mu.index.name = 'portfolioid'
        var = pd.Series([np.mean(x[1]) for x in preds], index=dt_port, name=dt)
        var.index.name = 'portfolioid'
        long_inv = pd.Series([np.mean(x[2]) for x in preds], index=dt_port, name=dt)
        long_inv.index.name = 'portfolioid'
        short_inv = pd.Series([np.mean(x[3]) for x in preds], index=dt_port, name=dt)
        short_inv.index.name = 'portfolioid'
        # var = var[~np.isnan(mu)]
        # mu = mu[~np.isnan(mu)]
        # mu = mu[~np.isnan(var)]
        # var = var[~np.isnan(var)]

        dt_mu.append(mu)
        dt_var.append(var)
        dt_long_inv.append(long_inv)
        dt_short_inv.append(short_inv)

    mu = pd.concat(dt_mu, axis=1).stack().swaplevel().sort_index()
    mu.index.rename(['date', 'portfolioid'], inplace=True)
    var = pd.concat(dt_var, axis=1).stack().swaplevel().sort_index()
    var.index.rename(['date', 'portfolioid'], inplace=True)
    long_inv = pd.concat(dt_long_inv, axis=1).stack().swaplevel().sort_index()
    long_inv.index.rename(['date', 'portfolioid'], inplace=True)
    short_inv = pd.concat(dt_short_inv, axis=1).stack().swaplevel().sort_index()
    short_inv.index.rename(['date', 'portfolioid'], inplace=True)

    #filling not available values with 0
    mu = mu.fillna(0)
    var = var.fillna(0)

    mu_lin = np.exp(mu + .5 * var) - 1.0      
    var_lin = (np.exp(var) - 1.0) * np.exp(2.0 * mu + var)

    result = {'mu': mu, 'var': var,
              'mu_lin': mu_lin, 'var_lin': var_lin,
              'long_inv': long_inv, 'short_inv': short_inv
              }
    return result


def get_strategy_covariance(dt_r, dt_var, dt_range=None, loc='data\cache_strategy_covariance.pkl'):
    if dt_range is None: dt_range = np.unique(dt_r.index.get_level_values('date'))
    dt_range = pd.DatetimeIndex(dt_range)

    dt_r = dt_r.groupby(level=1).shift().dropna()

    dt_match = [True if x in np.unique(dt_var.dropna().index.get_level_values(0)) else False for x in dt_range]
    dt_range = dt_range[dt_match]
    dt_match = [True if x in np.unique(dt_r.dropna().index.get_level_values(0)) else False for x in dt_range]
    dt_range = dt_range[dt_match]

    dt_var = dt_var.swaplevel().groupby('portfolioid').fillna(method='ffill').swaplevel()

    dt_S = []
    for dt in dt_range:
        var_pred = dt_var.loc[dt].copy()
        r_latest = dt_r.loc[dt].copy()

        var_pred = var_pred[[True if x in r_latest.index.values else False for x in var_pred.index.values]]
        r_latest = r_latest[[True if x in var_pred.index.values else False for x in r_latest.index.values]]

        r = dt_r.loc[:dt].swaplevel().loc[r_latest.index.values].swaplevel()
        r = r.loc[r.abs() > 0].unstack()
        mu = r.mean()
        var = r.var()
        var_lin = (np.exp(var) - 1.0) * np.exp(2.0 * mu + var)

        r_adj = (var_pred / var_lin).dropna().pow(.5)
        r_adj = (r * r_adj).stack()
        r_adj = r_adj[r_adj.abs() > 0]

        if len(np.unique(r_adj.index.get_level_values(1))) == 0:
            cov1 = np.nan
        elif len(np.unique(r_adj.index.get_level_values(1))) < 2:
            idx = [r_adj.index.get_level_values(1)[0]]
            cov1 = pd.DataFrame([var_pred.loc[idx]], index=idx, columns=idx)
        else:
            cov1 = estimate_covariance(r_adj)

        dt_S.append(cov1)

    result = pd.Series(dt_S, index=dt_range).dropna()

    return result


def get_risk_limit(drawdown_limit, year_mult=12):
    risk_limit = ((-np.log(1.0 - abs(drawdown_limit)) / gumbel_l().ppf(.01)) ** 2) / year_mult / 100
    risk_limit = (
            (np.exp(risk_limit) - 1.0) *
            np.exp(2.0 * nct(df=4, nc=0).ppf(1. / year_mult / 10000.) * np.sqrt(risk_limit) + risk_limit)
    )

    return risk_limit


def shrink_mu_estimates(pred0, r0, corr_n=None, err_n=None):
    if corr_n is None: corr_n = 60
    if err_n is None: err_n = 120

    pred = pred0.copy()
    r = r0.copy()

    match_idx = ~np.isnan(r * pred)
    t1= (r * pred)([match_idx].groupby(level=1)).ewm(span=corr_n)
    t2= (r[match_idx].pow(2).groupby(level=1)).ewm(span=corr_n).mean()
    t3=(pred[match_idx].pow(2).groupby(level=1)).ewm(span=corr_n).mean()
    corr = ((r * pred)[match_idx].groupby(level=1).ewm(span=corr_n).mean() / np.sqrt(
        r[match_idx].pow(2).groupby(level=1).ewm(span=corr_n).mean() *
        pred[match_idx].pow(2).groupby(level=1).ewm(span=corr_n).mean()
    )).droplevel(0)
    corr = corr.groupby(level=1).shift()

    corr[corr.abs() > 1.0] = np.sign(corr[corr.abs() > 1.0])

    corr_fact = np.exp(corr - 1.0)

    err = (r - pred)[match_idx].groupby(level=1).apply(lambda x:
                                                       np.sqrt([min(1, f / err_n) for f in range(len(x))])
                                                       * x.ewm(span=err_n).mean()
                                                       / x.ewm(span=err_n).std())
    err *= pred[match_idx].groupby(level=1).ewm(span=err_n).std().droplevel(0)
    err = err.groupby(level=1).shift()

    pred = ((pred - err.reindex(pred.index).fillna(0)) * corr_fact.reindex(pred.index).fillna(1)).drop
    return pred


def get_strategy_weights(mu, S, dt_range=None, op=None,
                         max_pos=.2, min_pos=0.0, min_abs_pos=.001,
                         hurdle=0.0, tc_proportional=.004, exp_hold=12,
                         loc='data\cache_strategy_weights.pkl',
                         verbose=False):
    
    print("*"*100)
    print("S -> inside get_strategy_weights")
    print(S)
    print("*"*100)

    #commented the filter to make sure it works for other test_ids as well
    # S = S[[x.shape[0] > 1 for x in S]]

    if dt_range is None: dt_range = S.index.values

    print("*"*100)
    print("dt_range")
    print(dt_range)
    print("*"*100)
    

    dt_match = [True if x in np.unique(mu.index.get_level_values(0)) else False for x in dt_range]
    dt_range = dt_range[dt_match]
    dt_match = [True if x in S.index.values else False for x in dt_range]
    dt_range = dt_range[dt_match]

    if not isinstance(hurdle, pd.Series):
        hurdle = pd.Series(hurdle, index=dt_range)

    drawdown_limit = -.15
    risk_limit = get_risk_limit(drawdown_limit)

    if op is None:
        op = optimize_port(
            max_gross=1.0,
            max_net=1.0,
            min_net=0.0,
            max_k_frac=.5,
            risk_limit=risk_limit,
            robust=False,
            verbose=0,
            risk_imp=0.5
        )

    mu = mu.swaplevel().groupby('portfolioid').fillna(method='ffill').swaplevel().fillna(0)

    dt_wgts = []
    for dt in dt_range:

        if len(dt_wgts) > 0:
            current_wgts = dt_wgts[-1]
        else:
            current_wgts = 0.0

        mu_pred = mu.loc[dt]
        S_pred = S.loc[dt]
        idx = mu_pred.index.values
        idx = idx[[True if x in S_pred.index.values else False for x in idx]]
        mu_pred = mu_pred.loc[idx]
        S_pred = S_pred.loc[idx]

        if verbose is True: print('Weights:', dt, mu_pred.shape[0])

        try:
            optim_result, best_idx, wgts = op.optimize(
                mu=mu_pred,
                S=S_pred,
                current_wgts=current_wgts,
                max_pos=max_pos,
                min_pos=min_pos,
                min_abs_pos=min_abs_pos,
                hurdle=hurdle.loc[dt],
                tc_proportional=tc_proportional,
                exp_hold=exp_hold
            )
            print(dt_wgts)
            print("*" * 100)
            dt_wgts.append(pd.Series(wgts, name=dt))

        except Exception as err:
            print('Weighting Error:', dt, err)
            continue
    # There will be no data i.e. df_wgts will be empty if for given test_id there is no 
    # matching batchids
    result = pd.concat(dt_wgts, axis=1).stack().swaplevel().sort_index()

    return result


def get_allocation(filter_port=None, date_agg='BM', filter_dates=None, filter_query=None, n=None,
                   max_gross=1.0, max_net=1.0, min_net=0.0,
                   risk_imp=.5, max_k_frac=.5, drawdown_limit=-.15,
                   max_pos=.2, min_pos=0.0, min_abs_pos=.001,
                   hurdle=None, tc_proportional=.004, exp_hold=12,
                   robust=False,
                   cache_dir='data', cache_ext='', use_cache=None):
    if date_agg in ['A', 'Y', 'BA', 'BY', 'AS', 'YS', 'BAS', 'BYS']: year_mult = 1
    if date_agg in ['Q', 'BQ', 'QS', 'BQS']: year_mult = 4
    if date_agg in ['M', 'BM', 'CBM', 'MS', 'BMS', 'CBMS']: year_mult = 12
    if date_agg in ['SM', 'SMS']: year_mult = 24
    if date_agg in ['W']: year_mult = 52
    if date_agg in ['D', 'B', 'C']: year_mult = 252

    risk_limit = get_risk_limit(drawdown_limit, year_mult)

    cache_loc = ['cache_strategy_data',
                 'cache_benchmark_expectations',
                 'cache_strategy_expectations',
                 'cache_strategy_correlations',
                 'cache_strategy_covariance',
                 'cache_strategy_weights'
                 ]
    cache_type = ['pkl', 'pkl', 'pkl', 'pkl', 'pkl', 'pkl']

    if cache_dir is not None:
        cache_loc = [cache_dir + '\\' + x for x in cache_loc]

    if len(cache_ext) > 0:
        if not isinstance(cache_ext, Iterable):
            cache_ext = np.repeat(cache_ext, 6)

        cache_loc = [x[0] + x[1] for x in zip(cache_loc, cache_ext)]

    cache_loc = [x[0] + '.' + x[1] for x in zip(cache_loc, cache_type)]

    if use_cache is None:
        sd = get_strategy_data(filter_port, loc=cache_loc[0])
        df = get_agg_data(sd['df'], date_agg)
        df_bench = get_agg_data_bench(sd['df_bench'], date_agg)
        be = get_benchmark_expectations(df_bench, filter_dates, n, loc=cache_loc[1])
        se = get_strategy_expectations(df, filter_dates, filter_query, n, be, loc=cache_loc[2])
        mu_adj = shrink_mu_estimates(se['mu'], df['r'])
        mu_lin_adj = np.exp(mu_adj + .5 * se['var']) - 1.0
        S = get_strategy_covariance(df['r'] - se['mu'].reindex(df['r'].index).fillna(0), se['var_lin'],
                                    loc=cache_loc[4])
        print("*"*100) 
        print("S -> get_strategy_covariance before hurdle and W ")
        print(S)
        print("*"*100)
        if hurdle is None: hurdle = df['rf'].droplevel(1).groupby(level=0).max()
        w = get_strategy_weights(mu_lin_adj, S, loc=cache_loc[5]
                                 , op=optimize_port(
                max_gross=max_gross,
                max_net=max_net,
                min_net=min_net,
                risk_imp=risk_imp,
                max_k_frac=max_k_frac,
                risk_limit=risk_limit,
                robust=robust,
                verbose=0
            )
                                 , max_pos=max_pos, min_pos=min_pos, min_abs_pos=min_abs_pos
                                 , hurdle=hurdle, tc_proportional=tc_proportional, exp_hold=exp_hold
                                 )
    else:
        if not isinstance(use_cache, Iterable):
            use_cache = np.repeat(use_cache, 6)

        if use_cache[0] == True:
            with gzip.open(cache_loc[0], 'rb') as f:
                sd = pickle.load(f)
        else:
            sd = get_strategy_data(filter_port, loc=cache_loc[0])

        df = get_agg_data(sd['df'], date_agg)
        df_bench = get_agg_data_bench(sd['df_bench'], date_agg)

        if use_cache[1] == True:
            with gzip.open(cache_loc[1], 'rb') as f:
                be = pickle.load(f)
        else:
            be = get_benchmark_expectations(df_bench, filter_dates, n, loc=cache_loc[1])

        if use_cache[2] == True:
            with gzip.open(cache_loc[2], 'rb') as f:
                se = pickle.load(f)
        else:
            se = get_strategy_expectations(df, filter_dates, filter_query, n, be, loc=cache_loc[2])

        mu_adj = shrink_mu_estimates(se['mu'], df['r'])
        mu_lin_adj = np.exp(mu_adj + .5 * se['var']) - 1.0

        '''
        if use_cache[3] == True:
            with gzip.open(cache_loc[3], 'rb') as f:
                corr = pickle.load(f)
        else:
            corr = get_strategy_correlations(df, df_bench, filter_dates, filter_query, loc=cache_loc[3])
        '''
        if use_cache[4] == True:
            with gzip.open(cache_loc[4], 'rb') as f:
                S = pickle.load(f)
        else:
            S = get_strategy_covariance(df['r'] - se['mu'].reindex(df['r'].index).fillna(0), se['var_lin'],
                                        loc=cache_loc[4])

        print("*"*100) 
        print(use_cache[4])
        print("S -> get_strategy_covariance")
        print(S)
        print("*"*100)

        if use_cache[5] == True:
            with gzip.open(cache_loc[5], 'rb') as f:
                w = pickle.load(f)
        else:
            if hurdle is None: hurdle = df['rf'].droplevel(1).groupby(level=0).max()
            w = get_strategy_weights(mu_lin_adj, S, loc=cache_loc[5]
                                     , op=optimize_port(
                    max_gross=max_gross,
                    max_net=max_net,
                    min_net=min_net,
                    risk_imp=risk_imp,
                    max_k_frac=max_k_frac,
                    risk_limit=risk_limit,
                    robust=robust,
                    verbose=0
                )
                                     , max_pos=max_pos, min_pos=min_pos, min_abs_pos=min_abs_pos
                                     , hurdle=hurdle, tc_proportional=tc_proportional, exp_hold=exp_hold
                                     )

    return w, se, S, be, df, df_bench