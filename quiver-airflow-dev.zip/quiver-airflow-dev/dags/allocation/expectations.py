import numpy as np
import pandas as pd
import abc
from collections.abc import Iterable

import statsmodels.api as sm
import statsmodels.tsa.api as tsa
import statsmodels.formula.api as smf

from arch.univariate import ARX, ZeroMean, ConstantMean
from arch.univariate import Normal, StudentsT, SkewStudent
from arch.univariate import ARCH, GARCH, EGARCH

from statsmodels.tsa.holtwinters import Holt

import datetime
# import pandas_datareader.data as web

from statsmodels.tsa.api import ExponentialSmoothing, SimpleExpSmoothing, Holt

 
def clean_dataset_inf(df):
    assert isinstance(df, pd.DataFrame), "df needs to be a pd.DataFrame"
    df.dropna(inplace=True)
    indices_to_keep = ~df.isin([np.nan, np.inf, -np.inf]).any(1)
    return df[indices_to_keep].astype(np.float64)


class Return_Model(abc.ABC):
    '''
    Abstract base class for strategy return predictions
    All children must define at least a fit method and a predict method
    '''

    def __init__(self):
        '''
        Use this section to set options, if desired
        '''

        pass

    @abc.abstractmethod
    def fit(self, y, X=None):
        '''
        Fit a model to trailing return data
        :param y: time series of log returns
        :param X: time series of exogenous variables
        :return: a fit model that can be used to make predictions
        '''

        self.model = None

        return self.model

    @abc.abstractmethod
    def predict(self, n=1, freq='monthly'):
        '''
        Use a previously fit model to predict forward returns
        :param n: the number of periods to predict
        :param freq: the frequency of predictions
        :return: return predictions for the next n freq (un-labeled)
        '''

        predictions = None

        return predictions

    def fit_predict(self, y, X=None, n=None, freq=None):
        '''
        Runs both fit and predict at the same time
        '''

        self.fit(y, X)

        return self.predict(n, freq)


class dummy_predictor():
    def __init__(self, dummy_val):
        self.params = pd.Series([dummy_val], index=['const'])

    def predict(self, n=1, steps=1, horizon=1, exog=None):
        n = max(n, steps, horizon)
        return pd.Series(np.repeat(self.params[0], n))

    def forecast(self, n=1, steps=1, horizon=1, exog=None):
        n = max(n, steps, horizon)
        return pd.Series(np.repeat(self.params[0], n))

    def get_forecast(self, n=1, steps=1, horizon=1, exog=None):
        n = max(n, steps, horizon)
        return pd.Series({'predicted_mean':
                              pd.Series(np.repeat(self.params[0], steps))
                          })

    def summary(self):
        return self.params


class Strategy_Return_Model(Return_Model):

    def setup_fit_data(self, y, long_inv, short_inv, bench_returns):
        y = y.mul(100).replace([np.inf, -np.inf], np.nan).dropna()
        bench_returns = bench_returns.mul(100).replace([np.inf, -np.inf], np.nan).dropna()
        long_inv = long_inv.replace([np.inf, -np.inf], np.nan).fillna(method='ffill')
        short_inv = short_inv.replace([np.inf, -np.inf], np.nan).fillna(method='ffill')
        long_inv_log = np.log(long_inv + 0.001)
        short_inv_log = np.log(-short_inv + 0.001)
        longdata = pd.concat([long_inv_log, bench_returns.shift(1)], axis=1).dropna()
        shortdata = pd.concat([short_inv_log, bench_returns.shift(1)], axis=1).dropna()
        long_inv_x = np.sqrt(long_inv)
        short_inv_x = np.sqrt(-short_inv)
        long_inv_x = np.nanmean(long_inv) * long_inv_x / np.nanmean(long_inv_x)
        short_inv_x = np.nanmean(short_inv) * short_inv_x / np.nanmean(short_inv_x)
        long_bench = bench_returns * long_inv_x
        short_bench = bench_returns * short_inv_x

        model_data = []
        self.include_X = [False, False, False, False, False]

        model_data.append(y)

        if np.var(long_bench) > 0:
            self.include_X[0] = True
            model_data.append(long_bench)
        if np.var(short_bench) > 0:
            self.include_X[1] = True
            model_data.append(short_bench)

        if ((self.include_X[0] + self.include_X[1] == 0) and (bench_returns is not None)):
            self.include_X[2] = True
            model_data.append(bench_returns)
        '''
        if np.var(long_inv_x) > 0:
             self.include_X[3] = True
             model_data.append(long_inv_x)

        if np.var(short_inv_x) > 0:
             self.include_X[4] = True
             model_data.append(short_inv_x)
        '''
        model_data = pd.concat(model_data, axis=1)

        model_data = pd.DataFrame(
            data=model_data.values,
            columns=np.array(['returns', 'long_bench', 'short_bench', 'bench_returns', 'long_inv', 'short_inv']
                             )[[True, *self.include_X]],
            index=bench_returns.index
        )
        # print('setup - model_data.tail prior to x_data:',model_data.tail(3))
        if model_data.shape[1] > 1:
            x_data = model_data.iloc[:, 1:]
            x_data = sm.add_constant(x_data)
        else:
            x_data = pd.Series(1, index=model_data.index)
        # print('setup - y.shape',y.shape)
        # print('setup - bench returns:',bench_returns.shape)
        # print('setup - long_inv.shape:',long_inv.shape)
        # print('setup - short_inv.shape:',short_inv.shape)
        # print('setup - longdata.tail:',longdata.tail(2))
        # print('setup - shortdata.tail:',shortdata.tail(2))
        # print('setup - long_bench.:',long_bench.shape)
        # print('setup - short_bench.:',short_bench.shape)
        # print('setup - model_data tail:',model_data.tail(2))
        # print('setup - x_data tail:',x_data.tail(2))
        return y, bench_returns, long_inv, short_inv, longdata, shortdata, long_bench, short_bench, x_data


def setup_data(df, depth=2):
    if not isinstance(depth, Iterable):
        depth = np.repeat(depth, 4)

    y = (df['r'] - df['rf'].values).mul(100).replace([np.inf, -np.inf], np.nan).dropna()
    bench_returns = (df['r_bench'] - df['rf'].values).mul(100).replace([np.inf, -np.inf], np.nan).dropna()
    top_3_wgt = df['top_3_wgt'].replace([np.inf, -np.inf], np.nan).fillna(method='ffill').fillna(0)
    log_pl_ratio = df['log_pl_ratio'].replace([np.inf, -np.inf], np.nan).fillna(method='ffill').fillna(0)
    hit_rate = df['hit_rate'].replace([np.inf, -np.inf], np.nan).fillna(method='ffill').fillna(.5)
    long_inv = df['long_inv'].replace([np.inf, -np.inf], np.nan).fillna(method='ffill').fillna(0)
    short_inv = df['short_inv'].replace([np.inf, -np.inf], np.nan).fillna(method='ffill').fillna(0)
    net_inv = long_inv + short_inv
    gross_inv = long_inv - short_inv
    long_inv_log = np.log(long_inv + 0.001)
    short_inv_log = np.log(-short_inv + 0.001)
    bench_returns_up = bench_returns.apply(lambda x: x if x > 0 else 0)
    bench_returns_down = bench_returns.apply(lambda x: x if x < 0 else 0)
    y_lag = y.shift()
    y_sqrt = np.sign(y_lag) * np.sqrt(np.abs(y_lag))
    bench_returns_norm = bench_returns - np.nanmean(bench_returns)
    bench_returns_sqrt = np.sign(bench_returns_norm) * np.sqrt(np.abs(bench_returns_norm))
    top_3_wgt_sqrt = np.sqrt(top_3_wgt)
    long_inv_sqrt = np.sqrt(long_inv)
    short_inv_sqrt = np.sqrt(-short_inv)
    net_inv_sqrt = np.sign(net_inv) * np.sqrt(np.abs(net_inv))
    gross_inv_sqrt = np.sqrt(gross_inv)
    bench_returns_sqrt = (
        (
                np.nanmean(np.abs(bench_returns_norm))
                * bench_returns_sqrt
                / np.nanmean(np.abs(bench_returns_sqrt))
        )
    )
    top_3_wgt_sqrt = np.nanmean(top_3_wgt) * top_3_wgt_sqrt / np.nanmean(top_3_wgt_sqrt)
    long_inv_sqrt = np.nanmean(long_inv) * long_inv_sqrt / np.nanmean(long_inv_sqrt)
    short_inv_sqrt = np.nanmean(short_inv) * short_inv_sqrt / np.nanmean(short_inv_sqrt)
    net_inv_sqrt = np.nanmean(net_inv) * net_inv_sqrt / np.nanmean(net_inv_sqrt)
    gross_inv_sqrt = np.nanmean(gross_inv) * gross_inv_sqrt / np.nanmean(gross_inv_sqrt)

    long_inv_log_lag = long_inv_log.shift()
    short_inv_log_lag = short_inv_log.shift()
    long_inv_log_lag = (long_inv_log_lag - np.nanmean(long_inv_log_lag)).fillna(0)
    short_inv_log_lag = (short_inv_log_lag - np.nanmean(short_inv_log_lag)).fillna(0)

    top_3_wgt = (top_3_wgt - np.nanmean(top_3_wgt)) / np.std(top_3_wgt)
    log_pl_ratio = (log_pl_ratio - np.nanmean(log_pl_ratio)) / np.std(log_pl_ratio)
    hit_rate = (hit_rate - np.nanmean(hit_rate)) / np.std(hit_rate)

    exposure_data = pd.DataFrame({'long_inv_log': long_inv_log,
                                  'short_inv_log': short_inv_log,
                                  'const': 1.0,
                                  'long_inv_log_lag': long_inv_log_lag,
                                  'short_inv_log_lag': short_inv_log_lag,
                                  'bench_returns': bench_returns_sqrt,
                                  'y_lag': y_sqrt
                                  })
    exposure_data['long_inv_log_lag'] = exposure_data['long_inv_log_lag'].fillna(0)
    exposure_data['short_inv_log_lag'] = exposure_data['short_inv_log_lag'].fillna(0)
    exposure_data['y_lag'] = exposure_data['y_lag'].fillna(0)
    exposure_data = exposure_data.dropna().iloc[:, 2:]

    exposure_var = exposure_data.var()

    exposure_data_include = pd.Series([False] * exposure_data.shape[1], index=exposure_data.columns)
    exposure_data_include['const'] = True

    if ((depth[0] >= 4) and (exposure_data.shape[0] > 5)):
        if exposure_var['y_lag'] > 0: exposure_data_include['y_lag'] = True

    if ((depth[0] >= 3) and (exposure_data.shape[0] > 4)):
        if exposure_var['bench_returns'] > 0: exposure_data_include['bench_returns'] = True

    if ((depth[0] >= 2) and (exposure_data.shape[0] > 3)):
        if exposure_var['long_inv_log_lag'] > 0: exposure_data_include['long_inv_log_lag'] = True
        if exposure_var['short_inv_log_lag'] > 0: exposure_data_include['short_inv_log_lag'] = True

    exposure_data = exposure_data[exposure_data_include.index[exposure_data_include]]

    risk_data = pd.DataFrame({'y': y,
                              'const': 1.0,
                              'long_bench_up': long_inv_sqrt * bench_returns_up,
                              'long_bench_down': long_inv_sqrt * bench_returns_down,
                              'short_bench_up': short_inv_sqrt * bench_returns_up,
                              'short_bench_down': short_inv_sqrt * bench_returns_down,
                              'long_bench': long_inv_sqrt * bench_returns,
                              'short_bench': short_inv_sqrt * bench_returns,
                              'net_bench': net_inv_sqrt * bench_returns})
    risk_data['long_bench'] = risk_data['long_bench'].fillna(0)
    risk_data['short_bench'] = risk_data['short_bench'].fillna(0)
    risk_data = risk_data.dropna().iloc[:, 1:]

    risk_var = risk_data.var()

    risk_include = pd.Series([False] * risk_data.shape[1], index=risk_data.columns)

    if (
            (depth[1] >= 3)
            and (risk_data.shape[0] > 11)
    ):
        if risk_var['long_bench_up'] > 0: risk_include['long_bench_up'] = True
        if risk_var['long_bench_down'] > 0: risk_include['long_bench_down'] = True
        if risk_var['short_bench_up'] > 0: risk_include['short_bench_up'] = True
        if risk_var['short_bench_down'] > 0: risk_include['short_bench_down'] = True

    if (
            (depth[1] >= 2)
            and (risk_data.shape[0] > 3)
            and (np.sum(risk_include[['long_bench_up', 'long_bench_down', 'short_bench_up', 'short_bench_down']]) == 0)
    ):
        if risk_var['long_bench'] > 0: risk_include['long_bench'] = True
        if risk_var['short_bench'] > 0: risk_include['short_bench'] = True

    if (
            (depth[1] >= 1)
            and (risk_data.shape[0] > 1)
            and (np.sum(risk_include[['long_bench', 'short_bench']]) == 0)
    ):
        if risk_var['net_bench'] > 0: risk_include['net_bench'] = True

    if np.sum(risk_include) == 0: risk_include['const'] = 1.0

    risk_data = risk_data[risk_include.index[risk_include]]

    alpha_data = pd.DataFrame({'y': y,
                               'const': 1.0,
                               'long_inv': long_inv_sqrt,
                               'short_inv': short_inv_sqrt,
                               'gross_inv': gross_inv_sqrt,
                               'top_3_wgt': top_3_wgt,
                               'log_pl_ratio': log_pl_ratio * gross_inv_sqrt,
                               'hit_rate': hit_rate * gross_inv_sqrt})
    alpha_data['long_inv'] = alpha_data['long_inv'].fillna(0)
    alpha_data['short_inv'] = alpha_data['short_inv'].fillna(0)
    alpha_data = alpha_data.dropna().iloc[:, 1:]

    alpha_var = alpha_data.var()
    alpha_include = pd.Series([False] * alpha_data.shape[1], index=alpha_data.columns)

    if (
            (depth[2] >= 5)
            and (alpha_data.shape[0] > 7)
    ):
        if alpha_var['hit_rate'] > 0: alpha_include['hit_rate'] = True

    if (
            (depth[2] >= 4)
            and (alpha_data.shape[0] > 6)
    ):
        if alpha_var['log_pl_ratio'] > 0: alpha_include['log_pl_ratio'] = True

    if (
            (depth[2] >= 3)
            and (alpha_data.shape[0] > 5)
    ):
        if alpha_var['top_3_wgt'] > 0: alpha_include['top_3_wgt'] = True

    if (
            (depth[2] >= 2)
            and (alpha_data.shape[0] > 4)
    ):
        if alpha_var['long_inv'] > 0: alpha_include['long_inv'] = True
        if alpha_var['short_inv'] > 0: alpha_include['short_inv'] = True

    if (
            (depth[2] >= 1)
            and (alpha_data.shape[0] > 2)
            and (np.sum(alpha_include[['long_inv', 'short_inv']]) == 0)
    ):
        if alpha_var['gross_inv'] > 0: alpha_include['gross_inv'] = True

    if np.sum(alpha_include) == 0: alpha_include['const'] = 1.0

    alpha_data = alpha_data[alpha_include.index[alpha_include]]

    ts_data = pd.DataFrame({'y': y,
                            'const': 1.0,
                            'top_3_wgt': (top_3_wgt / gross_inv).replace([np.inf, -np.inf], np.nan).fillna(0),
                            'log_pl_ratio': log_pl_ratio,
                            'hit_rate': hit_rate})
    ts_data = ts_data.dropna().iloc[:, 1:]

    ts_var = ts_data.var()
    ts_include = pd.Series([False] * ts_data.shape[1], index=ts_data.columns)
    ts_include['const'] = True

    if (
            (depth[3] >= 3)
            and (ts_data.shape[0] > 7)
    ):
        if ts_var['hit_rate'] > 0: ts_include['hit_rate'] = True

    if (
            (depth[3] >= 2)
            and (ts_data.shape[0] > 6)
    ):
        if ts_var['log_pl_ratio'] > 0: ts_include['log_pl_ratio'] = True

    ts_data = ts_data[ts_include.index[ts_include]]

    result = (
        bench_returns, long_inv_log, short_inv_log, y,
        exposure_data, risk_data, alpha_data, ts_data
    )

    return result


def mult_adj(x, m, mean_offset=True):
    if mean_offset is True:
        offset = np.nanmean(x)
    else:
        offset = 0

    return (offset + ((x - offset) * m)).replace([np.inf, -np.inf], np.nan).dropna()


class Strategy_CAPM(Return_Model):

    def fit(self, df, depth=(4, 2, 5, 0),
            exposure_model=[
                # (tsa.SARIMAX, 2
                # , {'order': (0, 0, 1), 'measurement_error': True, 'enforce_stationarity': False, 'trend': 'ct'}
                # , {'disp': False}),
                (sm.RLM, 1, {'M': sm.robust.norms.HuberT()}),
                (sm.OLS, 1)
            ],
            risk_model=[
                (sm.RLM, 1, {'M': sm.robust.norms.HuberT()}),
                (sm.OLS, 1)
            ],
            alpha_model=[
                (sm.RLM, 1, {'M': sm.robust.norms.HuberT()}),
                (sm.OLS, 1)
            ],
            ts_model=[
                (tsa.SARIMAX, 2
                 , {'order': (0, 0, 1), 'measurement_error': True, 'enforce_stationarity': True}
                 , {'disp': False, 'cov_type': 'robust'})  # ,
                # (sm.RLM, 1, {'M': sm.robust.norms.HuberT()}),
                # (sm.OLS, 1)
            ]
            ):

        if not isinstance(exposure_model, Iterable):
            exposure_model = [exposure_model]

        if not isinstance(risk_model, Iterable):
            risk_model = [risk_model]

        if not isinstance(alpha_model, Iterable):
            alpha_model = [alpha_model]

        (
            bench_returns, long_inv_log, short_inv_log, y,
            exposure_data, risk_data, alpha_data, ts_data
        ) = setup_data(df, depth=depth)

        self.bench_model = dummy_predictor(np.nanmean(bench_returns))

        self.last_data = pd.Series(
            df.iloc[-1][['lmv_limit', 'top_3_wgt_last', 'hit_rate_last', 'log_pl_ratio_last']].values
            , index=['lmv_limit', 'top_3_wgt', 'hit_rate', 'log_pl_ratio']
        )
        self.last_data['top_3_wgt'] = np.sign(self.last_data['top_3_wgt']) * min(
            np.abs(self.last_data['top_3_wgt']), 3.0)
        self.last_data['hit_rate'] = np.sign(self.last_data['hit_rate']) * min(
            np.abs(self.last_data['hit_rate']), 3.0)
        self.last_data['log_pl_ratio'] = np.sign(self.last_data['log_pl_ratio']) * min(
            np.abs(self.last_data['log_pl_ratio']), 3.0)

        self.last_data['y_lag'] = (df.iloc[-1]['r'] - df.iloc[-1]['rf']) * 100.0
        self.last_data['y_lag'] = np.sign(self.last_data['y_lag']) * np.sqrt(np.abs(self.last_data['y_lag']))

        self.last_data['long_inv_log_lag'] = np.log(df['long_inv'].iloc[-1] + 0.001) - np.nanmean(long_inv_log)
        self.last_data['short_inv_log_lag'] = np.log(-df['short_inv'].iloc[-1] + 0.001) - np.nanmean(short_inv_log)

        n = exposure_data.shape[0]
        degrees_freedom = exposure_data.shape[1]

        fit_done = False
        i = 0
        while ((fit_done is False) and (i < len(exposure_model))):
            try:
                model = exposure_model[i][0]
                adj = n - degrees_freedom * exposure_model[i][1]
                kwargs = exposure_model[i][2] if len(exposure_model[i]) >= 3 else {}
                fit_kwargs = exposure_model[i][3] if len(exposure_model[i]) >= 4 else {}

                if adj > 0:
                    self.long_model = model(
                        mult_adj(long_inv_log, np.square(adj / n)),
                        exposure_data.loc[:, [False if x == 'short_inv_log_lag' else True
                                              for x in exposure_data.columns]],
                        **kwargs).fit(**fit_kwargs)
                    fit_done = True

                    if 'long_inv_log_lag' in self.long_model.params.index:
                        if self.long_model.params['long_inv_log_lag'] > 1:
                            self.long_model.params['long_inv_log_lag'] = 1.0
                        if self.long_model.params['long_inv_log_lag'] < 0:
                            self.long_model.params['long_inv_log_lag'] = 0.0
                else:
                    i += 1
            except Exception  as err:
                print('long_model {} failed: {}'.format(i, err))
                i += 1

        if fit_done is False:
            self.adj_long = np.power((max(n, 1) - 1) / max(n, 1), 2)
            self.long_model = dummy_predictor(np.nanmean(long_inv_log))

        fit_done = False
        i = 0
        while ((fit_done is False) and (i < len(exposure_model))):
            try:
                model = exposure_model[i][0]
                adj = n - degrees_freedom * exposure_model[i][1]
                kwargs = exposure_model[i][2] if len(exposure_model[i]) >= 3 else {}
                fit_kwargs = exposure_model[i][3] if len(exposure_model[i]) >= 4 else {}

                if adj > 0:
                    self.short_model = model(
                        mult_adj(short_inv_log, np.square(adj / n)),
                        exposure_data.loc[:, [False if x == 'long_inv_log_lag' else True
                                              for x in exposure_data.columns]],
                        **kwargs).fit(**fit_kwargs)
                    fit_done = True

                    if 'short_inv_log_lag' in self.short_model.params.index:
                        if self.short_model.params['short_inv_log_lag'] > 1:
                            self.short_model.params['short_inv_log_lag'] = 1.0
                        if self.short_model.params['short_inv_log_lag'] < 0:
                            self.short_model.params['short_inv_log_lag'] = 0.0
                else:
                    i += 1
            except Exception  as err:
                print('short_model {} failed: {}'.format(i, err))
                i += 1

        if fit_done is False:
            self.adj_short = np.power((max(n, 1) - 1) / max(n, 1), 2)
            self.short_model = dummy_predictor(np.nanmean(short_inv_log))

        n = risk_data.shape[0]
        degrees_freedom = risk_data.shape[1]

        fit_done = False
        i = 0
        while ((fit_done is False) and (i < len(risk_model))):
            try:
                model = risk_model[i][0]
                degrees_freedom_risk = degrees_freedom * risk_model[i][1]
                adj = n - degrees_freedom_risk
                kwargs = risk_model[i][2] if len(risk_model[i]) >= 3 else {}
                fit_kwargs = risk_model[i][3] if len(risk_model[i]) >= 4 else {}

                if adj > 0:
                    self.risk_model = model(
                        mult_adj(y, np.square(adj / n), mean_offset=False),
                        risk_data,
                        **kwargs).fit(**fit_kwargs)
                    risk_resid = mult_adj(self.risk_model.resid, 1.0 / np.square(adj / n), mean_offset=False)
                    fit_done = True
                else:
                    i += 1
            except Exception  as err:
                print('risk_model {} failed: {}'.format(i, err))
                i += 1

        if fit_done is False:
            degrees_freedom_risk = 1
            self.risk_model = dummy_predictor(np.nanmean(y) * np.square((max(n, 1) - 1) / max(n, 1)))
            risk_resid = y - np.nanmean(y)

        self.n = alpha_data.shape[0]
        n = alpha_data.shape[0]
        degrees_freedom = alpha_data.shape[1]

        fit_done = False
        i = 0
        while ((fit_done is False) and (i < len(alpha_model))):
            try:
                model = alpha_model[i][0]
                degrees_freedom_alpha = degrees_freedom * alpha_model[i][1] + degrees_freedom_risk
                adj = n - degrees_freedom_alpha
                kwargs = alpha_model[i][2] if len(alpha_model[i]) >= 3 else {}
                fit_kwargs = alpha_model[i][3] if len(alpha_model[i]) >= 4 else {}

                if adj > 0:
                    self.alpha_model = model(
                        mult_adj(risk_resid, np.square(adj / n), mean_offset=False),
                        alpha_data,
                        **kwargs).fit(**fit_kwargs)
                    alpha_resid = mult_adj(self.alpha_model.resid, 1.0 / np.square(adj / n), mean_offset=False)
                    fit_done = True
                else:
                    i += 1
            except Exception  as err:
                print('alpha_model {} failed: {}'.format(i, err))
                i += 1

        if fit_done is False:
            degrees_freedom_alpha = 1 + degrees_freedom_risk
            self.alpha_model = dummy_predictor(np.nanmean(risk_resid) * np.square((max(n, 1) - 1) / max(n, 1)))
            alpha_resid = risk_resid - np.nanmean(risk_resid)

        gross_inv = (
                df['long_inv'].replace([np.inf, -np.inf], np.nan).fillna(method='ffill').fillna(0)
                - df['short_inv'].replace([np.inf, -np.inf], np.nan).fillna(method='ffill').fillna(0)
        )
        zero_g = (gross_inv == 0)
        gross_inv[zero_g] = np.nan

        gross_inv_sqrt = np.sqrt(gross_inv)
        gross_inv_sqrt = gross_inv_sqrt / np.nanmean(gross_inv_sqrt)

        alpha_resid = (gross_inv_sqrt * alpha_resid / gross_inv).replace([np.inf, -np.inf], np.nan).fillna(0)

        if depth[3] > 0:
            ts_data['alpha_resid_lag'] = alpha_resid.shift().fillna(0)
            ts_data['alpha_resid_lag'] = np.sign(ts_data['alpha_resid_lag']) * np.sqrt(
                np.abs(ts_data['alpha_resid_lag']))
        self.last_data['alpha_resid_lag'] = np.sign(alpha_resid.iloc[-1]) * np.sqrt(np.abs(alpha_resid.iloc[-1]))

        n = ts_data.shape[0]
        degrees_freedom = ts_data.shape[1]

        fit_done = False
        i = 0
        while ((fit_done is False) and (i < len(ts_model))):
            try:
                model = ts_model[i][0]
                adj = n - degrees_freedom * ts_model[i][1] - degrees_freedom_alpha
                kwargs = ts_model[i][2] if len(ts_model[i]) >= 3 else {}
                fit_kwargs = ts_model[i][3] if len(ts_model[i]) >= 4 else {}

                if adj > 0:
                    self.ts_model = model(
                        mult_adj(alpha_resid, np.square(adj / n), mean_offset=False),
                        ts_data,
                        **kwargs).fit(**fit_kwargs)
                    self.ts_model_std = dummy_predictor(np.nanstd(
                        mult_adj(self.ts_model.resid, 1.0 / np.square(adj / n), mean_offset=False)
                    ) / np.square((max(n, 1) - 1) / max(n, 1)))
                    fit_done = True

                    if 'alpha_resid_lag' in self.ts_model.params.index:
                        if np.abs(self.ts_model.params['alpha_resid_lag']) > 1:
                            self.ts_model.params['alpha_resid_lag'] = (
                                np.sign(self.ts_model.params['alpha_resid_lag'])
                            )
                else:
                    i += 1
            except Exception  as err:
                print('ts_model {} failed: {}'.format(i, err))
                i += 1

        if fit_done is False:
            n = len(alpha_resid)
            self.ts_model = dummy_predictor(np.nanmean(alpha_resid) * np.square((max(n, 1) - 1) / max(n, 1)))
            self.ts_model_std = dummy_predictor(np.nanstd(alpha_resid) / np.square((max(n, 1) - 1) / max(n, 1)))

        return self.bench_model, self.long_model, self.short_model, self.risk_model, self.alpha_model, self.ts_model

    def predict(self, n=None, bench_mu=None, bench_var=None):

        if n is None: n = 1

        if bench_mu is None: bench_mu = self.bench_model.forecast(steps=n) / 100.0
        bench_mu = pd.Series(bench_mu * 100.0)
        bench_mu_up = bench_mu.apply(lambda x: x if x > 0 else 0)
        bench_mu_down = bench_mu.apply(lambda x: x if x < 0 else 0)

        if bench_var is None: bench_var = np.square(bench_mu)

        exposure_data = pd.DataFrame({'const': 1.0,
                                      'long_inv_log_lag': self.last_data['long_inv_log_lag'],
                                      'short_inv_log_lag': self.last_data['short_inv_log_lag'],
                                      'bench_returns': bench_mu,
                                      'y_lag': self.last_data['y_lag']
                                      }, index=range(n))

        if len(self.long_model.params) > 0:
            long_data = exposure_data[exposure_data.columns[[
                x in self.long_model.params.index
                for x in exposure_data.columns
            ]]]

            if 'forecast' in dir(self.long_model):
                flong = self.long_model.forecast(steps=n, exog=long_data).values
            else:
                flong = self.long_model.predict(exog=long_data)

            flong_lin = (np.exp(flong) - 0.001)

            if self.last_data['lmv_limit'] > 0:
                for i in range(len(flong_lin)):
                    if flong_lin[i] > self.last_data['lmv_limit']:
                        flong_lin[i] = self.last_data['lmv_limit']

        else:
            long_data = np.nan
            flong_lin = np.nan

        if len(self.short_model.params) > 0:
            short_data = exposure_data[exposure_data.columns[[
                x in self.short_model.params.index
                for x in exposure_data.columns
            ]]]

            if 'forecast' in dir(self.short_model):
                fshort = self.short_model.forecast(steps=n, exog=short_data).values
            else:
                fshort = self.short_model.predict(exog=short_data)

            fshort_lin = -(np.exp(fshort) - 0.001)

            if self.last_data['lmv_limit'] > 0:
                for i in range(len(fshort_lin)):
                    if fshort_lin[i] < -1.0 * self.last_data['lmv_limit']:
                        fshort_lin[i] = -1.0 * self.last_data['lmv_limit']

        else:
            short_data = np.nan
            fshort_lin = np.nan

        mu = np.repeat(0.0, n)
        var = np.repeat(0.0, n)

        if len(self.risk_model.params) > 0:
            risk_data = pd.DataFrame({'const': 1.0,
                                      'long_bench_up': flong_lin * bench_mu_up,
                                      'long_bench_down': flong_lin * bench_mu_down,
                                      'short_bench_up': fshort_lin * bench_mu_up,
                                      'short_bench_down': fshort_lin * bench_mu_down,
                                      'long_bench': flong_lin * bench_mu,
                                      'short_bench': fshort_lin * bench_mu,
                                      'net_bench': (flong_lin + fshort_lin) * bench_mu
                                      })
            risk_data = risk_data[risk_data.columns[[
                x in self.risk_model.params.index
                for x in risk_data.columns
            ]]]

            if 'forecast' in dir(self.risk_model):
                risk_rt = self.risk_model.forecast(steps=n, exog=risk_data).values
            else:
                risk_rt = self.risk_model.predict(exog=risk_data)

            mu += risk_rt

            risk_var_data = pd.DataFrame({'const': 1.0,
                                          'long_bench_up': flong_lin,
                                          'long_bench_down': flong_lin,
                                          'short_bench_up': fshort_lin,
                                          'short_bench_down': fshort_lin,
                                          'long_bench': flong_lin,
                                          'short_bench': fshort_lin,
                                          'net_bench': (flong_lin + fshort_lin)
                                          })
            risk_var_data = risk_var_data[risk_var_data.columns[[
                x in self.risk_model.params.index
                for x in risk_var_data.columns
            ]]]

            risk_var = [x[0] if x[0] > x[1] else x[1] for x in zip(
                np.square(risk_rt),
                np.sum(np.square(risk_var_data * self.risk_model.params).values) * bench_var
            )]
            var += risk_var

        else:
            risk_data = np.nan

        if len(self.alpha_model.params) > 0:
            alpha_data = pd.DataFrame({'const': 1.0,
                                       'long_inv': flong_lin,
                                       'short_inv': fshort_lin,
                                       'gross_inv': flong_lin - fshort_lin,
                                       'top_3_wgt': self.last_data['top_3_wgt'],
                                       'log_pl_ratio': self.last_data['log_pl_ratio'] * (flong_lin - fshort_lin),
                                       'hit_rate': self.last_data['hit_rate'] * (flong_lin - fshort_lin)
                                       })

            alpha_data = alpha_data[alpha_data.columns[[
                x in self.alpha_model.params.index
                for x in alpha_data.columns
            ]]]

            if 'forecast' in dir(self.alpha_model):
                alpha_rt = self.alpha_model.forecast(steps=n, exog=alpha_data).values
            else:
                alpha_rt = self.alpha_model.predict(exog=alpha_data)

            # alpha_rt *= min(1.0,np.sqrt(self.n/12))

            mu += alpha_rt
            # var += np.square(alpha_rt)

        else:
            alpha_data = np.nan

        if len(self.ts_model.params) > 0:
            ts_data = pd.DataFrame({'const': 1.0,
                                    'alpha_resid_lag': self.last_data['alpha_resid_lag'],
                                    'log_pl_ratio': self.last_data['log_pl_ratio'],
                                    'hit_rate': self.last_data['hit_rate']
                                    }, index=range(n))

            ts_data = ts_data[ts_data.columns[[
                x in self.ts_model.params.index
                for x in ts_data.columns
            ]]]

            if 'forecast' in dir(self.ts_model):
                ts_rt = self.ts_model.forecast(steps=n, exog=ts_data).values * (flong_lin - fshort_lin)
            else:
                ts_rt = self.ts_model.predict(exog=ts_data) * (flong_lin - fshort_lin)

            ts_var = np.square(self.ts_model_std.forecast(steps=n).values * (flong_lin - fshort_lin))

            mu += ts_rt
            var += ts_var

        return mu / 100.0, var / 10000.0, flong_lin, fshort_lin


class Strategy_CAPM_ARX(Strategy_Return_Model):

    def fit(self, y, long_inv=None, short_inv=None, bench_returns=None):

        vol = GARCH(p=1, o=0, q=1)
        dist = Normal()

        y, bench_returns, long_inv, short_inv, longdata, shortdata, long_bench, short_bench, x_data = (
            self.setup_fit_data(y, long_inv, short_inv, bench_returns)
        )
        # print('x_data:',x_data.head(1))
        # print('head x_data:',x_data.head(3))
        self.adj = np.power((len(y) - 1) / len(y), 2)  # brilliant
        # print('adj factor:',self.adj)

        # self.bench_fit = ExponentialSmoothing(np.asarray(bench_returns), trend='add',damped=False).fit(use_boxcox=False)

        self.bench_fit = tsa.SARIMAX(endog=bench_returns, order=(0, 0, 1), enforce_stationarity=False).fit(disp=0)
        # print('CAPM_ARX() bench_fit MA', self.bench_fit.fittedvalues)
        if np.var(long_inv) > 0:
            self.long_fit = tsa.SARIMAX(
                endog=longdata.iloc[:, 0],
                exog=longdata.iloc[:, 1],
                order=(1, 0, 0),
                enforce_stationarity=False
            ).fit(disp=0)
        else:
            self.long_fit = dummy_predictor(long_inv[-1])
            # print('long dummy fit:',self.long_fit)

        if np.var(short_inv) > 0:
            self.short_fit = tsa.SARIMAX(
                endog=shortdata.iloc[:, 0],
                exog=shortdata.iloc[:, 1],
                order=(1, 0, 0),
                enforce_stationarity=False
            ).fit(disp=0)
        else:
            self.short_fit = dummy_predictor(short_inv[-1])
        #     print('fit() short dummy fit :',self.short_fit)
        # print(' prior to risk_model head of x_data',x_data.head(3))
        self.risk_model = sm.OLS(endog=y, exog=x_data).fit()  # model of returns as a function of benchmark
        # print('self.risk_model:',self.risk_model)
        self.Xvar = np.var(x_data.iloc[:, 1:])  # Var(X) without constant!!
        self.alpha = self.risk_model.params[0]  # the constant + noise
        # print('Alpha:',self.alpha)
        self.beta = self.risk_model.params[1:]  # extract market exposure
        # print('beta:',self.beta)
        self.Evar = ZeroMean(
            y=self.risk_model.resid,
            volatility=vol,
            distribution=dist
        ).fit(disp='off')  # Var(e) GARCH
        # self.summary = self.risk_model.summary()

        self.bench_returns_1 = bench_returns[-1]
        # print('bench_returns_1:',self.bench_returns_1)

        return self.Evar, self.bench_fit, self.long_fit, self.short_fit

    def predict(self, n=None, bench_mu=None, bench_var=None):

        if n is None: n = 1

        mu = self.alpha * self.adj

        if np.sum(self.include_X) > 0:

            if bench_mu is None: bench_mu = self.bench_fit.forecast(steps=n) * self.adj
            # print('bench_mu without adjustments self.bench_fit.forecast(steps=n) :',self.bench_fit.forecast(steps=n))
            # print('bench_mu is bench fit with adjustment self.bench_fit.forecast(steps=n)*self.adj :',bench_mu)
            bench_returns_1 = self.bench_returns_1

            if n > 1: bench_returns_1 = np.append(bench_returns_1, bench_mu[:(n - 1)] * 100.0)
            # print('1) bench_returns_1 n > 1:',bench_returns_1)

            flong = self.long_fit.get_forecast(exog=bench_returns_1, steps=n).predicted_mean.values
            # print('2) forecast long  self.long_fit.get_forecast(exog = bench_returns_1, steps=n).predicted_mean.values:', flong)
            fshort = self.short_fit.get_forecast(exog=bench_returns_1, steps=n).predicted_mean.values
            # print('3) Short forecast based on Market Index:',fshort)

            flong_bench = pd.Series((np.exp(flong) - 0.001) * bench_mu)
            # print('4) interaction long and bench pd.Series(-(np.exp(flong)-0.001)*bench_mu:',flong_bench.values)

            # flong_bench = pd.Series((np.exp(flong)-0.01)*np.sqrt(bench_var)) # TEST THIS ALTERNATIVE !!!!!!!

            fshort_bench = pd.Series(-(np.exp(fshort) - 0.001) * bench_mu)
            # print('fshort_bench pd.Series(-(np.exp(fshort)-0.001)*bench_mu:',fshort_bench)
            newX = []

            if self.include_X[0] == True:
                newX.append(flong_bench)

            # if self.include_X[1] == True:
            #     newX.append(flong)

            if self.include_X[1] == True:
                newX.append(fshort_bench)
            # print('predict() newX on forecast short_bench added:',newX)
            # # if self.include_X[3] == True:
            #     newX.append(fshort)

            if self.include_X[2] == True:
                newX.append(bench_mu)
            # print('predict() newX on forecast bench mu added :',newX)
            # Create Risk Model for OLS
            newX = pd.concat(newX, axis=1)
            # print('6) Forecast Data newX:', newX)
            mu += np.dot(newX, self.beta)  # add beta to alpha to get total return
            # print('7) predicted Mu:',mu)
        evar = self.Evar.forecast(horizon=n).residual_variance.dropna(axis=0, how='all').T.values  # V(e)

        xvar = np.dot(self.Xvar, np.power(self.beta, 2))
        # print('9) xvar:',xvar)
        Xvariance = xvar * len(evar)  # duplicate VAR(X) for forecast length
        # print('10) predicted variance = xvar*len(evar):',Xvariance)
        var = np.add(Xvariance, evar)

        return mu / 100.0, var / 100.0, self.alpha, self.beta, newX, self.risk_model.summary()


class Benchmark_Simple(Return_Model):

    def fit(self, y):
        y = y.mul(100).replace([np.inf, -np.inf], np.nan).dropna()

        self.adj = np.power((len(y) - 1) / len(y), 2)

        self.y_mean_fit = dummy_predictor(np.nanmean(y))
        self.y_var_fit = dummy_predictor(np.nanvar(y, ddof=1))

        return self.y_mean_fit, self.y_var_fit

    def predict(self, n=None, freq=None):
        if n is None: n = 1

        mu = self.y_mean_fit.forecast(horizon=n) * self.adj
        var = self.y_var_fit.forecast(horizon=n)

        return mu / 100.0, var / 10000.0


class Benchmark_ARX(Return_Model):

    def fit(self, y):
        vol = GARCH(p=1, o=0, q=1)
        dist = Normal()

        y = y.mul(100).replace([np.inf, -np.inf], np.nan).dropna()

        self.adj = np.power((len(y) - 1) / len(y), 2)

        self.yfit = ARX(
            y=y,
            volatility=vol,
            distribution=dist
        ).fit(disp='off')

        return self.yfit

    def predict(self, n=None, freq=None):
        if n is None: n = 1

        mu = self.yfit.forecast(horizon=n).mean.dropna(axis=0, how='all').T.values * self.adj
        var = self.yfit.forecast(horizon=n).residual_variance.dropna(axis=0, how='all').T.values

        return mu / 100.0, var / 10000.0


class Strategy_CAPM_RARX(Strategy_Return_Model):

    def fit(self, y, long_inv=None, short_inv=None, bench_returns=None):

        vol = GARCH(p=1, o=0, q=1)
        dist = Normal()

        y, bench_returns, long_inv, short_inv, longdata, shortdata, long_bench, short_bench, x_data = (
            self.setup_fit_data(y, long_inv, short_inv, bench_returns)
        )
        # print('x_data:',x_data.head(1))
        # print('head x_data:',x_data.head(3))
        self.adj = np.power((len(y) - 1) / len(y), 2)  # brilliant
        # print('adj factor:',self.adj)

        # self.bench_fit = ExponentialSmoothing(np.asarray(bench_returns), trend='add',damped=False).fit(use_boxcox=False)

        self.bench_fit = tsa.SARIMAX(endog=bench_returns, order=(0, 0, 1), enforce_stationarity=False).fit(disp=0)
        # print('CAPM_ARX() bench_fit MA', self.bench_fit.fittedvalues)
        if np.var(long_inv) > 0:
            self.long_fit = tsa.SARIMAX(
                endog=longdata.iloc[:, 0],
                exog=longdata.iloc[:, 1],
                order=(1, 0, 0),
                enforce_stationarity=False
            ).fit(disp=0)
        else:
            self.long_fit = dummy_predictor(long_inv[-1])
            # print('long dummy fit:',self.long_fit)

        if np.var(short_inv) > 0:
            self.short_fit = tsa.SARIMAX(
                endog=shortdata.iloc[:, 0],
                exog=shortdata.iloc[:, 1],
                order=(1, 0, 0),
                enforce_stationarity=False
            ).fit(disp=0)
        else:
            self.short_fit = dummy_predictor(short_inv[-1])
        #     print('fit() short dummy fit :',self.short_fit)
        # print(' prior to risk_model head of x_data',x_data.head(3))
        self.risk_model = sm.RLM(endog=y, exog=x_data,
                                 M=sm.robust.norms.HuberT()).fit()  # model of returns as a function of benchmark
        # print('self.risk_model:',self.risk_model)
        self.Xvar = np.var(x_data.iloc[:, 1:])  # Var(X) without constant!!
        self.alpha = self.risk_model.params[0]  # the constant + noise
        # print('Alpha:',self.alpha)
        self.beta = self.risk_model.params[1:]  # extract market exposure
        # print('beta:',self.beta)
        self.Evar = ZeroMean(
            y=self.risk_model.resid,
            volatility=vol,
            distribution=dist
        ).fit(disp='off')  # Var(e) GARCH
        # self.summary = self.risk_model.summary()

        self.bench_returns_1 = bench_returns[-1]
        # print('bench_returns_1:',self.bench_returns_1)

        return self.Evar, self.bench_fit, self.long_fit, self.short_fit

    def predict(self, n=None, bench_mu=None, bench_var=None):

        if n is None: n = 1

        mu = self.alpha

        if np.sum(self.include_X) > 0:

            if bench_mu is None: bench_mu = self.bench_fit.forecast(steps=n) * self.adj
            # print('bench_mu without adjustments self.bench_fit.forecast(steps=n) :',self.bench_fit.forecast(steps=n))
            # print('bench_mu is bench fit with adjustment self.bench_fit.forecast(steps=n)*self.adj :',bench_mu)
            bench_returns_1 = self.bench_returns_1

            if n > 1: bench_returns_1 = np.append(bench_returns_1, bench_mu[:(n - 1)] * 100.0)
            # print('1) bench_returns_1 n > 1:',bench_returns_1)

            flong = self.long_fit.get_forecast(exog=bench_returns_1, steps=n).predicted_mean.values
            # print('2) forecast long  self.long_fit.get_forecast(exog = bench_returns_1, steps=n).predicted_mean.values:', flong)
            fshort = self.short_fit.get_forecast(exog=bench_returns_1, steps=n).predicted_mean.values
            # print('3) Short forecast based on Market Index:',fshort)

            flong_bench = pd.Series((np.exp(flong) - 0.001) * bench_mu)
            # print('4) interaction long and bench pd.Series(-(np.exp(flong)-0.001)*bench_mu:',flong_bench.values)
            # flong_bench = pd.Series((np.exp(flong)-0.01)*np.sqrt(bench_var)) # TEST THIS ALTERNATIVE !!!!!!!
            fshort_bench = pd.Series(-(np.exp(fshort) - 0.001) * bench_mu)
            # print('fshort_bench pd.Series(-(np.exp(fshort)-0.001)*bench_mu:',fshort_bench)
            newX = []

            if self.include_X[0] == True:
                newX.append(flong_bench)

            # if self.include_X[1] == True:
            #     newX.append(flong)

            if self.include_X[1] == True:
                newX.append(fshort_bench)
            # print('predict() newX on forecast short_bench added:',newX)
            # if self.include_X[3] == True:
            #     newX.append(fshort)

            if self.include_X[2] == True:
                newX.append(bench_mu)
            # print('predict() newX on forecast bench mu added :',newX)
            # Create Risk Model for OLS
            newX = pd.concat(newX, axis=1)
            # print('6) Forecast Data newX:', newX)
            mu += np.dot(newX, self.beta)  # add beta to alpha to get total return
            # print('7) predicted Mu:',mu)
        evar = self.Evar.forecast(horizon=n).residual_variance.dropna(axis=0, how='all').T.values  # V(e)

        xvar = np.dot(self.Xvar, np.power(self.beta, 2))
        # print('9) xvar:',xvar)
        Xvariance = xvar * len(evar)  # duplicate VAR(X) for forecast length
        # print('10) predicted variance = xvar*len(evar):',Xvariance)
        var = np.add(Xvariance, evar)

        return mu / 100.0, var / 100.0, self.alpha, self.beta, newX, self.risk_model.summary()


# class Strategy_CAPM_BVOL(Strategy_Return_Model):

#     def fit(self, y, long_inv=None, short_inv=None, bench_returns=None):

#         vol=GARCH(p=1,o=1, q=1)
#         dist=Normal()

#         y, bench_returns, long_inv, short_inv, longdata, shortdata, long_bench, short_bench, x_data = (
#             self.setup_fit_data(y, long_inv, short_inv, bench_returns)
#         )
#         # print('x_data:',x_data.head(1))
#         # print('head x_data:',x_data.head(3))
#         self.adj = np.power( (len(y) - 1) / len(y), 2) #brilliant
#         # print('adj factor:',self.adj)

#         # self.bench_fit = ExponentialSmoothing(np.asarray(bench_returns), trend='add',damped=False).fit(use_boxcox=False)

#         self.bench_fit = tsa.SARIMAX(endog=bench_returns,order=(0, 0, 1),enforce_stationarity=False).fit(disp=0)
#         # print('CAPM_ARX() bench_fit MA', self.bench_fit.fittedvalues)
#         if np.var(long_inv) > 0:
#             self.long_fit = tsa.SARIMAX(
#                 endog=longdata.iloc[:,0],
#                 exog = longdata.iloc[:,1],
#                 order=(1, 0, 0),
#                 enforce_stationarity=False
#             ).fit(disp=0)
#         else:
#             self.long_fit = dummy_predictor(long_inv[-1])
#             # print('long dummy fit:',self.long_fit)

#         if np.var(short_inv) > 0:
#             self.short_fit = tsa.SARIMAX(
#                 endog=shortdata.iloc[:,0],
#                 exog = shortdata.iloc[:,1],
#                 order=(1, 0, 0),
#                 enforce_stationarity=False
#             ).fit(disp=0)
#         else:
#             self.short_fit = dummy_predictor(short_inv[-1])
#         #     print('fit() short dummy fit :',self.short_fit)
#         # print(' prior to risk_model head of x_data',x_data.head(3))
#         pred_var = bench_mu.std()
#         pred_var = pred_var[:(n-1)]*100.0
#         self.risk_model = sm.RLM(endog = y, exog = pred_var,M=sm.robust.norms.HuberT()).fit() # model of returns as a function of benchmark

#         # print('self.risk_model:',self.risk_model)
#         self.Xvar = np.var(x_data.iloc[:,1:]) #Var(X) without constant!!
#         self.alpha = self.risk_model.params[0] # the constant + noise
#         # print('Alpha:',self.alpha)
#         self.beta = self.risk_model.params[1:] # extract market exposure
#         # print('beta:',self.beta)
#         self.Evar = ZeroMean(
#             y = self.risk_model.resid,
#             volatility=vol,
#             distribution=dist
#         ).fit(disp='off') #Var(e) GARCH
#         # self.summary = self.risk_model.summary()

#         self.bench_returns_1 = bench_returns[-1]
#         # print('bench_returns_1:',self.bench_returns_1)

#         return self.Evar, self.bench_fit, self.long_fit, self.short_fit

#     def predict(self, n=None, bench_mu=None, bench_var=None):

#         if n is None: n = 1

#         mu = self.alpha

#         if np.sum(self.include_X)>0:

#             if bench_var is None: bench_mu = self.bench_fit.forecast(steps = n)
#             # print('bench_mu without adjustments self.bench_fit.forecast(steps=n) :',self.bench_fit.forecast(steps=n))
#             # print('bench_mu is bench fit with adjustment self.bench_fit.forecast(steps=n)*self.adj :',bench_mu)
#             bench_returns_1 = self.bench_returns_1

#             if n > 1: bench_returns_1 = np.append(bench_returns_1, bench_mu[:(n-1)]*100.0)
#             # print('1) bench_returns_1 n > 1:',bench_returns_1)

#             flong = self.long_fit.get_forecast(exog = bench_returns_1, steps=n).predicted_mean.values
#             # print('2) forecast long  self.long_fit.get_forecast(exog = bench_returns_1, steps=n).predicted_mean.values:', flong)
#             fshort = self.short_fit.get_forecast(exog = bench_returns_1, steps=n).predicted_mean.values
#             # print('3) Short forecast based on Market Index:',fshort)

#             # flong_bench = pd.Series((np.exp(flong)-0.001)*bench_mu)
#             # print('4) interaction long and bench pd.Series(-(np.exp(flong)-0.001)*bench_mu:',flong_bench.values)
#             flong_bench = pd.Series((np.exp(flong)-0.01)*np.sqrt(bench_var)) # TEST THIS ALTERNATIVE !!!!!!!
#             # fshort_bench = pd.Series(-(np.exp(fshort)-0.001)*bench_mu)
#             fshort_bench = pd.Series((np.exp(fshort)-0.01)*np.sqrt(bench_var)) # TEST THIS ALTERNATIVE !!!!!!!
#             # print('fshort_bench pd.Series(-(np.exp(fshort)-0.001)*bench_mu:',fshort_bench)
#             newX = []


#             if self.include_X[0] == True:
#                 newX.append(flong_bench)

#             # if self.include_X[1] == True:
#             #     newX.append(flong)

#             if self.include_X[1] == True:
#                 newX.append(fshort_bench)
#             # print('predict() newX on forecast short_bench added:',newX)
#             # if self.include_X[3] == True:
#             #     newX.append(fshort)

#             if self.include_X[2] == True:
#                 newX.append(bench_mu)
#             # print('predict() newX on forecast bench mu added :',newX)
#         # Create Risk Model for OLS
#             newX = pd.concat(newX,axis=1)
#             # print('6) Forecast Data newX:', newX)
#             mu += np.dot(newX,self.beta)# add beta to alpha to get total return
#             # print('7) predicted Mu:',mu)
#         evar = self.Evar.forecast(horizon = n).residual_variance.dropna(axis=0,how='all').T.values #V(e)

#         xvar = np.dot(self.Xvar,np.power(self.beta,2))
#         # print('9) xvar:',xvar)
#         Xvariance = xvar*len(evar) # duplicate VAR(X) for forecast length
#         # print('10) predicted variance = xvar*len(evar):',Xvariance)
#         var = np.add(Xvariance,evar)

#         return mu/100.0, var/100.0, self.alpha, self.beta, newX, self.risk_model.summary()


# class Strategy_MuVaRGarch(Strategy_Return_Model):

#     def fit(self, y, long_inv=None, short_inv=None, bench_returns=None):

#         vol=GARCH(p=1,o=1, q=1)
#         dist=SkewStudent()

#         y, bench_returns, long_inv, short_inv, longdata, shortdata, long_bench, short_bench, x_data = (
#             self.setup_fit_data(y, long_inv, short_inv, bench_returns)
#         )
#         # print('head x_data:',x_data.head(3))
#         self.adj = np.power( (len(y) - 1) / len(y), 2) #brilliant
#         # print('adj factor:',self.adj)

#         # self.bench_fit = ExponentialSmoothing(np.asarray(bench_returns), trend='add',damped=False).fit(use_boxcox=False)

#         self.bench_fit = tsa.SARIMAX(endog=bench_returns,order=(0, 0, 2),enforce_stationarity=True).fit(disp=0)


#         # print('longdata shape:',longdata.shape)
#         # print('longdata.head():',longdata.head(3))
#         # print('shortdata.shape:',shortdata.shape)
#         # print('shortdata.head():',shortdata.head(3))

#         if np.var(long_inv) > 0:
#             self.long_fit = tsa.SARIMAX(
#                 endog=longdata.iloc[:,0],
#                 exog = longdata.iloc[:,1],
#                 order=(1, 0, 0),
#                 enforce_stationarity=True
#             ).fit(disp=0)
#         else:
#             self.long_fit = dummy_predictor(long_inv[-1])
#             print('long dummy fit:',self.long_fit)

#         if np.var(short_inv) > 0:
#             self.short_fit = tsa.SARIMAX(
#                 endog=shortdata.iloc[:,0],
#                 exog = shortdata.iloc[:,1],
#                 order=(1, 0, 0),
#                 enforce_stationarity=True
#             ).fit(disp=0)
#         else:
#             self.short_fit = dummy_predictor(short_inv[-1])
#             # print('short dummy fit:',self.short_fit)

#         self.risk_model = y
#         self.alpha = 1
#         self.beta = 1

#         self.Xvar = np.var(x_data.iloc[:,1:]) #Var(X) without constant!!
#         # self.alpha = self.risk_model.params[0] # the constant + noise
#         # # print('Alpha:',self.alpha)
#         # self.beta = self.risk_model.params[1:] # extract market exposure
#         # print('beta:',self.beta)
#         self.Evar = arch_model(y = self.risk_model,volatility=vol,distribution=dist).fit(disp='off') #Var(e) GARCH

#         self.bench_returns_1 = bench_returns[-1]
#         # print('bench_returns_1:',self.bench_returns_1)


#  # self.Evar = gm_result

#         return self.Evar, self.bench_fit, self.long_fit, self.short_fit

#     def predict(self, n=None, bench_mu=None, bench_var=None):

#         if n is None: n = 1


#         prediction = self.Evar.forecast(horizon = n)
#             # print('7) predicted Mu:',mu)
#         var = prediction.variance.dropna(axis=0,how='all') #V(e)
#         mu = prediction.mean()
#         # print('11) Final total var - np.add(Xvariance,evar):',var)
#         return mu/100.0, var/100.0, self.alpha, self.beta, newX


def exposure_model_performance(DATA=None, O=0, plot_last=10, season=None, n=None, train_start_size=0.97):
    from sklearn.metrics import mean_absolute_error, mean_squared_error, median_absolute_error, \
        explained_variance_score, r2_score
    from math import sqrt
    # Setting up containers to hold values by strategy
    MU = []

    VAR = []
    mae = []
    mse = []
    Ty = []
    Tvol = []
    NMU = []
    NVOL = []
    SIG = []
    errs = []

    # set up index to count strategies completed.
    si = 0
    # Seelect a strategy
    for strat in DATA.index.get_level_values(0).unique():
        dataset = DATA[DATA.index.get_level_values(0) == strat].droplevel(level=0)
        # How many initial values to build first model iteration from in relative proportion to the entire dataset
        start_index = int(round(len(dataset) * train_start_size, 0))
        end_index = len(dataset)
        # call the class
        model = Strategy_CAPM_ARX()
        # assign strategy name to list for labeling
        str_name = [strat]
        str_name = pd.Series(str_name).repeat(n)
        # loops by building history starting at start_index and ends at end_index
        if len(dataset) > 17:
            # if a strategies history is more than 55 days of history try the following tasks
            print('strategy:{}'.format(str_name))

            for i in range(start_index, end_index):

                print('head of dataset for loop:',
                      dataset.head(4))  # y as history updates its length after each iteration
                # assign histiry to date of r to y
                try:
                    y = dataset.r[:i]

                    str_name_index = str_name[:i]
                    vol = y.std()
                    vol = pd.Series(vol, index=str_name)
                    # y.index = y.index # drop multilevel index only keep dates
                    datey = pd.Series(y.index[-1])
                    # datey = pd.Series(y1.index[:n]) # just take current value of date
                    X = dataset.iloc[:i, 1:]  # The rest of the dataframe
                    array_length = len(y)
                    # why do I substract 1 from index slice??????????????
                    true_y = y[-1]  # current date
                    # true_y = y[-1:]*100 # current y all history up to current iteration

                    true_y = pd.Series(true_y, index=datey)  # just current history of length
                    # print('X the input in model.fit():',X.head(4))
                    # yesterdays data and prior goes into fit to ake a prediction for the end of the day in .predict()
                    model.fit(y=y[:-1], long_inv=X.iloc[:-1, 2], short_inv=X.iloc[:-1, 3], bench_returns=X.iloc[:-1, 5])

                    # Only predict out the next observation next day value.
                    mu, var, alpha, beta, newx = model.predict(
                        n=1)  # predict the mu, make sure it truly predicts the volatility
                    # print(b)
                    # if i = = end_index:
                    # should return only 1 value!!
                    mu = mu.flatten()
                    var = var.flatten()
                    mu = pd.Series(mu, index=str_name)
                    print('12) mu after flatten pd.Series(mu,index=str_name) mu/100:', mu)
                    var = pd.Series(var, index=str_name)
                    sig = np.sqrt(var.div(100))
                    nmu = y[:-1].mean()  # how about Mu is the last value!!!!!
                    nvar = y[:-1].std()
                    # nmu = nmu.flatten()
                    # nvar = nvar.flatten()

                    nmu = pd.Series(nmu, index=str_name)
                    nvar = pd.Series(nvar, index=str_name)
                # Naive

                except Exception as e:
                    print(e)
                    errs.append((strat, e))
                    mu = pd.Series([np.nan], index=str_name)
                    var = pd.Series([np.nan], index=str_name)
                    sig = pd.Series([np.nan], index=str_name)
                    true_y = pd.Series([np.nan], index=str_name)
                    vol = pd.Series([np.nan], index=str_name)
                    nmu = pd.Series([np.nan], index=str_name)
                    nvar = pd.Series([np.nan], index=str_name)
                    continue
                # appending a bunch of nans if the loop fails on any date
                MU.append(mu)
                print('length of mu', len(MU))
                VAR.append(var)
                SIG.append(sig)
                Ty.append(true_y)
                Tvol.append(vol)
                NMU.append(nmu)  # Naive
                NVOL.append(nvar)



        else:
            for i in range(start_index, end_index):
                try:
                    print(i)
                    # y as history updates its length after each iteration
                    y = dataset.r[:i]
                    str_name_index = str_name[:i]
                    vol = y.std()
                    vol = pd.Series(vol, index=str_name)
                    datey = pd.Series(y.index[-1])
                    array_length = len(y)
                    true_y = y[array_length - 1]
                    true_y = pd.Series(true_y, index=datey)  # just current history of length
                    mu = y.shift(1)[-1]  # how about Mu is the last value!!!!!
                    var = y[:-2].std()
                    mu = mu.flatten()
                    # var = var.flatten()
                    mu = pd.Series(mu, index=str_name)
                    var = pd.Series(var, index=str_name)
                    sig = np.sqrt(var.div(100))
                    nmu = y[:-1].mean()  # how about Mu is the last value!!!!!
                    nvar = y[:-2].std()
                    nmu = pd.Series(nmu, index=str_name)
                    nvar = pd.Series(nvar, index=str_name)

                except Exception as e:
                    print(e)
                    errs.append((strat, e))
                    mu = pd.Series([np.nan], index=str_name)
                    var = pd.Series([np.nan], index=str_name)
                    sig = pd.Series([np.nan], index=str_name)
                    true_y = pd.Series([np.nan], index=str_name)
                    vol = pd.Series([np.nan], index=str_name)
                    nmu = pd.Series([np.nan], index=str_name)
                    nvar = pd.Series([np.nan], index=str_name)
                    continue
                # appending a bunch of nans if the loop fails on any date
                MU.append(mu)
                # print('length of mu',len(MU))
                VAR.append(var)
                SIG.append(sig)
                Ty.append(true_y)
                Tvol.append(vol)
                NMU.append(nmu)  # Naive
                NVOL.append(nvar)

        si += 1
        if si % 10 == 0:
            print('Completed strategies:', si)

    all_MU = pd.concat(MU, axis=0)
    # MU = MU.div(100)
    all_VAR = pd.concat(VAR, axis=0)
    all_Ty = pd.concat(Ty, axis=0)
    all_Tvol = pd.concat(Tvol, axis=0)
    all_NMU = pd.concat(NMU, axis=0)
    all_NVOL = pd.concat(NVOL, axis=0)
    SIGMA = pd.concat(SIG, axis=0)

    # two paths: first more inefficient way send meta data with strategy through loop
    # other way: only past osid strategy id, in the end to join data with strategy meta data frame. create unique with algo type data to second dataframe for merging with performance table.

    frame = {'Strategy': all_VAR.index.values, 'Date': all_Ty.index.values, 'Observation': all_Ty.values,
             'Mu': all_MU.values, 'Volatility': all_Tvol.values, 'Sigma': SIGMA.values, 'NaiveMu': all_NMU.values,
             'NaiveVol': all_NVOL.values}
    performance = pd.DataFrame(frame)
    performance['MSE_mu'] = performance.groupby(performance.index.get_level_values(0)).apply(
        lambda x: mean_squared_error(x.Observation, x.Mu))
    performance['MSE_vol'] = performance.groupby(performance.index.get_level_values(0)).apply(
        lambda x: mean_squared_error(x.Observation, x.Volatility))
    performance['MSE_nmu'] = performance.groupby(performance.index.get_level_values(0)).apply(
        lambda x: mean_squared_error(x.Observation, x.NaiveMu))
    performance['MSE_nvol'] = performance.groupby(performance.index.get_level_values(0)).apply(
        lambda x: mean_squared_error(x.Observation, x.NaiveVol))
    performance['MSSE_mu'] = performance['MSE_mu'] / performance['MSE_nmu']
    performance['MSSE_vol'] = performance['MSE_vol'] / performance['MSE_nvol']

    performance = performance.set_index(['Strategy', 'Date'])
    Base_Model = performance.groupby(performance.index.get_level_values(0))['MSSE_mu', 'MSSE_vol'].mean()
    for strat in performance.index.get_level_values(0).unique():
        performance.ix[strat, [0]][-plot_last:].plot(figsize=(11, 6), title='Ground Truth vs {}'.format(strat))
        performance.ix[strat, [1]][-plot_last:].plot()
        performance.ix[strat, [4]][-plot_last:].plot()

    #
    # , Base_Model
    return performance, Base_Model

# class MultipleTimeSeriesCV:
#     """Generates tuples of train_idx, test_idx pairs
#     Assumes the MultiIndex contains levels 'symbol' and 'date'
#     purges overlapping outcomes"""

#     def __init__(self,
#                  n_splits=3,
#                  train_period_length=126,
#                  test_period_length=21,
#                  lookahead=None,
#                  shuffle=False):
#         self.n_splits = n_splits
#         self.lookahead = lookahead
#         self.test_length = test_period_length
#         self.train_length = train_period_length
#         self.shuffle = shuffle

#     def split(self, X, y=None, groups=None):
#         unique_dates = X.index.get_level_values('date').unique()
#         days = sorted(unique_dates, reverse=True)

#         split_idx = []
#         for i in range(self.n_splits):
#             test_end_idx = i * self.test_length
#             test_start_idx = test_end_idx + self.test_length
#             train_end_idx = test_start_idx + + self.lookahead - 1
#             train_start_idx = train_end_idx + self.train_length + self.lookahead - 1
#             split_idx.append([train_start_idx, train_end_idx,
#                               test_start_idx, test_end_idx])

#         dates = X.reset_index()[['date']]
#         for train_start, train_end, test_start, test_end in split_idx:
#             print('train_start:',train_start)
#             print('train_end',train_end)
#             train_idx = dates[(dates.date > days[train_start])
#                               & (dates.date <= days[train_end])].index
#             print('train_idx',train_idx)
#             test_idx = dates[(dates.date > days[test_start])
#                              & (dates.date <= days[test_end])].index
#             if self.shuffle:
#                 np.random.shuffle(list(train_idx))
#             yield train_idx, test_idx

#     def get_n_splits(self, X, y, groups=None):
#         return self.n_splits


# def get_strategy_diagnostics(df, dt_range=None, filter_query=None, n=1, be=None,
#                               model=Strategy_CAPM_Simple(),
#                               loc='data/cache_strategy_expectations.pkl'):

#     from sklearn.metrics import mean_absolute_error, mean_squared_error,median_absolute_error,explained_variance_score,r2_score
#     from math import sqrt
#     if filter_query is not None:
#         df = df.query(filter_query).copy()

#     if dt_range is None:
#         dt_range = pd.DatetimeIndex(np.unique(df.index.get_level_values(0)))


#     SIG = []
#     errs = []

#     dt_mu = []
#     dt_var = []
#     dt_alpha = []
#     dt_beta = []
#     dt_newX = []
#     dt_mae = []
#     dt_mse = []
#     dt_ty = []
#     dt_tvol = []
#     dt_nmu = []
#     dt_nvol = []
#     dt_sig = []
#     dt_errs = []
#     for dt in dt_range:

#         # Find which portfolios were active as of the date
#         dt_port_1 = df.loc[dt].index.values

#         # Include only data we would have known at the time
#         df_dt = df[df.index.get_level_values(0)<dt].swaplevel().copy()

#         # Find portfolios that had some known data
#         dt_port_2 = np.unique(df_dt.index.get_level_values(0))

#         dt_port = dt_port_2[[True if x in dt_port_1 else False for x in dt_port_2]]

#         if be is not None:
#             if np.min(be['mu'].index.get_level_values(0)) <= dt:
#                 dt_mu_bench = be['mu'].loc[dt]
#                 dt_var_bench = be['var'].loc[dt]
#             else:
#                 dt_mu_bench = None
#                 dt_var_bench = None
#         else:
#             dt_mu_bench = None
#             dt_var_bench = None


#                     # nmu = y[:-1].mean() #how about Mu is the last value!!!!!
#                     # nvar  = y[:-1].std()


#         # Make predictions about mu and var for each portfolio
#         preds = []
#         acts = []
#         for port in dt_port:
#             df_port = df_dt.loc[port]
#             print('head of df_port',df_port.head(3))

#             marketindexosid = df_port['marketindexosid'][-1]

#             if dt_mu_bench is not None:
#                 if marketindexosid in dt_mu_bench.index.values:
#                     dt_mu_bench_port = dt_mu_bench.loc[marketindexosid]
#                     dt_var_bench_port = dt_var_bench.loc[marketindexosid]
#                 else:
#                     dt_mu_bench_port = None
#                     dt_var_bench_port = None
#             else:
#                 dt_mu_bench_port = None
#                 dt_var_bench_port = None

#             if df_port.shape[0]>=3:
#                 try:
#                     model.fit(df_port['r'], #ty
#                               df_port['long_inv'],
#                               df_port['short_inv'],
#                               df_port['r_bench']
#                               )
#                     pred = model.predict(n, dt_mu_bench_port, dt_var_bench_port)
#                     # act = df_port['r']

#                 except Exception as err:
#                     print('Expectation Error:', dt, port, err)
#                     pred = (np.nan, np.nan, np.nan, np.nan, np.nan)
#                     # act = (np.nan)
#             else:
#                 pred = (np.nan, np.nan, np.nan, np.nan, np.nan)
#                 # act = (np.nan)

#             preds.append(pred)
#             # acts.append(act)
#         mu = pd.Series([np.mean(x[0]) for x in preds], index=dt_port, name=dt)
#         mu.index.name = 'portfolioid'
#         var = pd.Series([np.mean(x[1]) for x in preds], index=dt_port, name=dt)
#         var.index.name = 'portfolioid'
#         alpha = pd.Series([np.mean(x[2]) for x in preds], index=dt_port, name=dt)
#         alpha.index.name = 'portfolioid'
#         beta = pd.Series([np.mean(x[3]) for x in preds], index=dt_port, name=dt)
#         beta.index.name = 'portfolioid'
#         newX = pd.Series([np.mean(x[4]) for x in preds], index=dt_port, name=dt)
#         newX.index.name = 'portfolioid'

#         var = var[~np.isnan(mu)]
#         mu = mu[~np.isnan(mu)]
#         mu = mu[~np.isnan(var)]
#         var = var[~np.isnan(var)]

#         dt_mu.append(mu)
#         dt_var.append(var)
#         dt_alpha.append(alpha)
#         dt_beta.append(beta)
#         dt_newX.append(newX)
#         dt_mae.append(mae)
#         dt_mse.append(mse)
#         dt_ty.append(ty)
#         dt_tvol.append(tvol)
#         dt_nmu.append(nmu)
#         dt_nvol.append(nvol)
#         dt_sig.append(sig)
#         dt_errs.append(errs)


#     mu = pd.concat(dt_mu, axis=1).stack().swaplevel().sort_index()
#     mu.index.rename(['date','portfolioid'], inplace=True)
#     var = pd.concat(dt_var, axis=1).stack().swaplevel().sort_index()
#     var.index.rename(['date','portfolioid'], inplace=True)
#     alpha = pd.concat(dt_alpha, axis=1).stack().swaplevel().sort_index()
#     alpha.index.rename(['date', 'portfolioid'], inplace=True)
#     beta = pd.concat(dt_beta, axis=1).stack().swaplevel().sort_index()
#     beta.index.rename(['date', 'portfolioid'], inplace=True)
#     newX = pd.concat(dt_newX, axis=1).stack().swaplevel().sort_index()
#     newX.index.rename(['date', 'portfolioid'], inplace=True)

#     result = {'mu': mu, 'var': var, 'alpha': alpha, 'beta': beta, 'newX': newX}

#     with gzip.open(loc, 'wb') as f:
#         pickle.dump(result, f)

#     return result


# def exposure_model_performance_2(DATA = None,O=0,plot_last = 10, season = 5, n = None,train_start_size = 0.95):
#     from sklearn.metrics import mean_absolute_error, mean_squared_error
#     # Setting up containers to hold values by strategy
#     MU = []

#     VAR = []
#     mae = []
#     mse = []
#     Ty = []
#     Tvol = []
#     NMU = []
#     NVOL = []
#     SIG = []
#     errs = []

# # set up index to count strategies completed.
#     si =0
# # Seelect a strategy
#     for strat in DATA.index.get_level_values(0).unique():
#         dataset = DATA[DATA.index.get_level_values(0) == strat].droplevel(level=0)
#         # How many initial values to build first model iteration from in relative proportion to the entire dataset
#         start_index = int(round(len(dataset)*train_start_size ,0))
#         end_index = len(dataset)
#         # call the class
#         model = StrategyExposureMuVarLoop() # initiation
#         # assign strategy name to list for labeling
#         str_name = [strat]
#         str_name = pd.Series(str_name).repeat(n)
#         # loops by building history starting at start_index and ends at end_index

#             # if a strategies history is more than 55 days of history try the following tasks
#         print('strategy:{}'.format(str_name))

#         for i in range(start_index,end_index):
#             # y as history updates its length after each iteration
#             # assign histiry to date of r to y
#             try:
#                 y = dataset.r[:i]

#                 str_name_index = str_name[:i]
#                 vol = y.std()
#                 vol = pd.Series(vol, index = str_name)
#                 # y.index = y.index # drop multilevel index only keep dates
#                 datey = pd.Series(y.index[-1])
#                 # datey = pd.Series(y1.index[:n]) # just take current value of date
#                 X = dataset.iloc[:i,1:] # The rest of the dataframe
#                 array_length = len(y)
#                 # why do I substract 1 from index slice??????????????
#                 true_y = y[-1]#current date
#                 # true_y = y[-1:]*100 # current y all history up to current iteration

#                 true_y = pd.Series(true_y, index = datey) # just current history of length
#                 if len(dataset) > 55:
#              # yesterdays data and prior goes into fit to ake a prediction for the end of the day in .predict()
#                     model.fit(y=y[:-1],X1=X.iloc[:-1,0], X2 = X.iloc[:-1,1], Z = X.iloc[:-1,3], o = 0,season_freq = season)

#             # Only predict out the next observation next day value.
#                     mu,var = model.predict(n = 1) # predict the mu, make sure it truly predicts the volatility
#                 else:
#                     mu = y.shift(1)[-1] #how about Mu is the last value!!!!!
#                     var  = y[:-2].std()
#                 # print(b)
#                 # if i = = end_index:
#                 # should return only 1 value!!
#                 mu = mu.flatten()
#                 var = var.flatten()
#                 mu = pd.Series(mu, index = str_name)
#                 print('mu:',mu)
#                 var = pd.Series(var, index = str_name)
#                 sig = np.sqrt(var.div(100))
#                 nmu = y[:-1].mean() #how about Mu is the last value!!!!!
#                 nvar  = y[:-1].std()
#                 # nmu = nmu.flatten()
#                 # nvar = nvar.flatten()

#                 nmu = pd.Series(nmu, index = str_name)
#                 nvar = pd.Series(nvar, index = str_name)
# #Naive
#             except Exception as e:
#                 print(e)
#                 errs.append((strat,e))
#                 mu = pd.Series([np.nan],index = str_name)
#                 var = pd.Series([np.nan],index = str_name)
#                 sig = pd.Series([np.nan],index = str_name)
#                 true_y = pd.Series([np.nan],index = str_name)
#                 vol = pd.Series([np.nan],index = str_name)
#                 nmu = pd.Series([np.nan],index = str_name)
#                 nvar = pd.Series([np.nan],index = str_name)
#                 continue
# # appending a bunch of nans if the loop fails on any date
#             MU.append(mu)
#             print('length of mu',len(MU))
#             VAR.append(var)
#             SIG.append(sig)
#             Ty.append(true_y)
#             Tvol.append(vol)
#             NMU.append(nmu) #Naive
#             NVOL.append(nvar)


#     si+=1
#     if si %10==0:
#         print('Completed strategies:',si)


#     all_MU = pd.concat(MU,axis=0)
#     # MU = MU.div(100)
#     all_VAR = pd.concat(VAR, axis=0)
#     all_Ty = pd.concat(Ty,axis=0)
#     all_Tvol = pd.concat(Tvol,axis=0)
#     all_NMU = pd.concat(NMU,axis=0)
#     all_NVOL = pd.concat(NVOL,axis=0)
#     SIGMA = pd.concat(SIG,axis=0)

# # two paths: first more inefficient way send meta data with strategy through loop
# # other way: only past osid strategy id, in the end to join data with strategy meta data frame. create unique with algo type data to second dataframe for merging with performance table.

#     frame = {'Strategy': all_VAR.index.values,'Date': all_Ty.index.values,'Observation':all_Ty.values,'Mu':all_MU.values,'Volatility':all_Tvol.values,'Sigma':SIGMA.values,'NaiveMu':all_NMU.values,'NaiveVol':all_NVOL.values}
#     performance = pd.DataFrame(frame)
#     performance['MSE_mu'] = performance.groupby(performance.index.get_level_values(0)).apply(lambda x: mean_squared_error(x.Observation,x.Mu))
#     performance['MSE_vol'] = performance.groupby(performance.index.get_level_values(0)).apply(lambda x: mean_squared_error(x.Observation,x.Volatility))
#     performance['MSE_nmu'] = performance.groupby(performance.index.get_level_values(0)).apply(lambda x: mean_squared_error(x.Observation,x.NaiveMu))
#     performance['MSE_nvol'] = performance.groupby(performance.index.get_level_values(0)).apply(lambda x: mean_squared_error(x.Observation,x.NaiveVol))
#     performance['MSSE_mu'] = performance['MSE_mu']/performance['MSE_nmu']
#     performance['MSSE_vol']= performance['MSE_vol']/performance['MSE_nvol']


#     performance =   performance.set_index(['Strategy','Date'])
#     Base_Model = performance.groupby(performance.index.get_level_values(0))['MSSE_mu','MSSE_vol'].mean()
#     for strat in performance.index.get_level_values(0).unique():
#         performance.ix[strat,[0,1]][-plot_last:].plot(figsize=(11,6), title = 'Ground Truth vs {}'.format(strat))
#         performance.ix[strat,[0,4]][-plot_last:].plot(figsize=(11,6), title = 'Ground Truth vs Naive {}'.format(strat))

#     return performance, Base_Model


# Testing for Predictability of the Time Series

# from arch.unitroot import VarianceRatio
#     vr = VarianceRatio(excess_market, 12)
#     print(vr.summary().as_text())
#