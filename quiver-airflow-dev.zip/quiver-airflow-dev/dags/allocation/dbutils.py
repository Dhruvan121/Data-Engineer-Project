import base64
import pandas as pd
import sqlalchemy as sa
from urllib import parse
import os
from allocation.helper import get_quiver_db_engine



def get_stratergy_settings(testId):

    quiverdb_engine = get_quiver_db_engine()

    conn = quiverdb_engine.connect()
    query = 'select * from ocm.get_allocationtestsettings({})'.format(testId)
    import json
    res = pd.read_sql_query(query, conn)
    jsonData = res['get_allocationtestsettings'].to_json()

    kellyModel = json.loads(jsonData)['0'][1]['settings']

    conn.close()

    retObject = dict()

    RiskFreeAsset = '0B3MO'

    retObject['risk_imp'] = kellyModel[0]['value']
    retObject['max_net'] = kellyModel[1]['value']/100
    retObject['max_gross'] = kellyModel[2]['value']/100
    retObject['drawdown_limit'] = (-1)*kellyModel[5]['value']/100
    retObject['max_pos'] = kellyModel[6]['value'] / 100
    retObject['allow_short'] = kellyModel[7]['value']
    retObject['robustness'] = kellyModel[8]['value']
    return retObject


def get_strategy_portfoliolist(testId):
    quiverdb_engine = get_quiver_db_engine()
    conn = quiverdb_engine.connect()
    query = 'select * from ocm.get_allocationstreams({})'.format(testId)
    print(query)
    return pd.read_sql_query(query, conn)
