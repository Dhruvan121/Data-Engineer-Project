import datetime
import pandas as pd

from allocation.helper import get_strategy_data, upload_df_to_s3, import_kelly_allocation_results, calc_eqfixedmodelweightages, update_allocationtestprogress, finish_allocationtest, calc_allocationmetricdata, cancel_allocationtest, read_s3_as_df, get_agg_data_bench, get_calc_weight_test_id
from allocation.helper import get_strategy_weights, get_risk_limit, get_agg_data, get_strategy_covariance, get_benchmark_expectations,get_strategy_expectations
from allocation.expectations import Benchmark_ARX
from allocation.dbutils import get_stratergy_settings, get_strategy_portfoliolist
from allocation.ptools  import optimize_port

bucket_name = "ocm-bullseye-dev"

def RunPreCalc():
    
    print("Starting RunPreCalc ******")

    print("Starting get_strategy_data ******")
    start_time = datetime.datetime.now()   
    sd = get_strategy_data()
    end_time = datetime.datetime.now()
    print("Total time taken to generate strategy data => ", str(end_time-start_time))

    pd_df= sd['df'].reset_index()
    pd_df['date'] = pd.Series(pd_df['date'].dt.to_pydatetime(), dtype=object)
    print("...Uploading stg_data to s3")
    upload_df_to_s3(pd_df, bucket_name, "allocation/output/ocm/csv/stg_data.csv")
    print("...uploaded stg_data to s3")
    
    pd_df = sd['df_bench'].reset_index()
    pd_df['date'] = pd.Series(pd_df['date'].dt.to_pydatetime(), dtype=object)
    print("...Uploading bench_data to s3")
    upload_df_to_s3(pd_df, bucket_name, "allocation/output/ocm/csv/bench_data.csv")
    print("...uploaded stg_data to s3")
     
    start_time = datetime.datetime.now()
    print("Starting get_agg_data ******")
    df_bench = get_agg_data_bench(sd['df_bench'], 'BM')
    df = get_agg_data(sd['df'], 'BM')
    end_time = datetime.datetime.now()
    print("Total time taken to calculate agg_data => ", str(end_time-start_time))

    print("Calculating Benchmark Expectation ******")
    start_time = datetime.datetime.now()
    be = get_benchmark_expectations(df_bench,  model=Benchmark_ARX(), n=1)
    end_time = datetime.datetime.now()
    print("Total time taken to calculate get_benchmark_expectations => ", str(end_time-start_time))

    print("Calculating Strategy Expectation ******")
    start_time = datetime.datetime.now()
    se = get_strategy_expectations(df, be=be)
    end_time = datetime.datetime.now()
    print("Total time taken to calculate get_strategy_expectations => ", str(end_time-start_time))

    pd_df = pd.DataFrame(se).reset_index()
    pd_df['date'] = pd.Series(pd_df['date'].dt.to_pydatetime(), dtype=object)
    # pd_df = pd_df[["date", "portfolioid", "mu", "var", "newX"]]  
    print("...Uploading se to s3") 
    upload_df_to_s3(pd_df, bucket_name, "allocation/output/ocm/csv/se.csv")
    print("...uploaded se to s3")

    print('Completed RunPreCalc *****')
    

def CalculateWeighs(testId):

    if testId is None:
        raise Exception(f"Error: Invalid test id -> {testId}") 

    try:
        print(f"Starting CalculateWeighs for testId => {testId} ******")
        is_cancelled=update_allocationtestprogress(testId, 5)
        if is_cancelled:
            print("Tasks was cancelled thus skipping rest of the steps.")
            return is_cancelled
        
        fileName = "allocationresult_" + str(testId)

        print("Starting get_strategy_portfoliolist ******")
        start_time = datetime.datetime.now()
        streamdata = get_strategy_portfoliolist(testId)
        arr = streamdata['streamid'].astype(str).values.tolist()
        arr = [int(a) for a in arr]
        print(f"stream ids to match {str(arr)}")
        typIdarr = streamdata['streamtypeid'].astype(str).values.tolist()
        end_time = datetime.datetime.now()
        print("Total time taken toget_strategy_portfoliolist => ", str(end_time-start_time))
        

        print("Fetching stg_data from S3 and calculating agg_data ******")
        start_time = datetime.datetime.now()
        dfStg = read_s3_as_df(bucket_name, "allocation/output/ocm/csv/stg_data.csv")
        dfStg.set_index(['date', 'portfolioid'], inplace=True)
        dfStg.sort_index(inplace=True)
        dfStg.index = dfStg.index.set_levels([pd.to_datetime(dfStg.index.levels[0]), dfStg.index.levels[1]])
        dfStg = dfStg.loc[dfStg.index.isin(arr, level=1)]
        print("*"*100)
        print("dfStg -> stg_data")
        print(dfStg)
        print("*"*100)
        if dfStg is None or dfStg.empty:
            print(f"no matching portfolioid for stg_data in given streamdata -> streamid \n", str(arr))
            raise Exception(f"no matching portfolioid for stg_data in given streamdata -> streamid \n {str(arr)}")
        df = get_agg_data(dfStg, 'BM')
        end_time = datetime.datetime.now()
        print("Total time taken create df from  stg_data => ", str(end_time-start_time))
        

        print("Fetching bench_data from S3 and calculating agg_data ******")
        start_time = datetime.datetime.now()
        dfStg = read_s3_as_df(bucket_name, "allocation/output/ocm/csv/bench_data.csv")
        dfStg.set_index(['date', 'marketindexosid'], inplace=True)
        dfStg.sort_index(inplace=True)
        dfStg.index = dfStg.index.set_levels([pd.to_datetime(dfStg.index.levels[0]), dfStg.index.levels[1]])
        df_bench = get_agg_data_bench(dfStg, 'BM')
        end_time = datetime.datetime.now()
        print("Total time taken create df_bench from bench_data => ", str(end_time-start_time))
        

        print("Fetching se from S3 and calculating get_strategy_covariance ******")
        start_time = datetime.datetime.now()
        dfSe = read_s3_as_df(bucket_name, "allocation/output/ocm/csv/se.csv")
        dfSe.set_index(['date', 'portfolioid'], inplace=True)
        dfSe.sort_index(inplace=True)
        dfSe.index = dfSe.index.set_levels([pd.to_datetime(dfSe.index.levels[0]), dfSe.index.levels[1]])    
        dfSe = dfSe.loc[dfSe.index.isin(arr, level=1)]
        print("*"*100)
        print("dfSe -> se")
        print(dfSe)
        print("*"*100)
        if dfSe is None or dfSe.empty:
            print(f"no matching portfolioid for se in given streamdata -> streamid \n {str(arr)}")
            raise Exception(f"no matching portfolioid for se in given streamdata -> streamid \n", str(arr))
        #mu_adj = shrink_mu_estimates(dfSe['mu'], df['r'])
        #mu_lin_adj = np.exp(mu_adj + .5 * dfSe['var']) - 1.0
        S = get_strategy_covariance(df['r'] - dfSe['mu'].reindex(df['r'].index).fillna(0), dfSe['var_lin'])
        S = get_strategy_covariance(df['r'], dfSe['var_lin'])
        print("*"*100) 
        print("S -> get_strategy_covariance allocation_app_starter ")
        print(S)
        print("*"*100)
        kellySettings = get_stratergy_settings(testId)
        end_time = datetime.datetime.now()
        print("Total time taken create S & kellySettings from se => ", str(end_time-start_time))
        
        
        print('***************Printing Allocation UI Settings *********** :')
        print(kellySettings)

        drawdown_limit = kellySettings.get('drawdown_limit')
        exp_hold = 12
        risk_limit = get_risk_limit(drawdown_limit, exp_hold)
        min_pos = 0.0
        max_pos = kellySettings.get('max_pos')
        max_gross = kellySettings.get('max_gross')
        max_net = kellySettings.get('max_net')
        risk_imp = kellySettings.get('risk_imp')
        robust = kellySettings.get('robustness')
        if kellySettings.get('allow_short') is True:
            min_pos = -1.0 * max_pos
        hurdle = df['rf'].droplevel(1).groupby(level=0).max()
        

        start_time = datetime.datetime.now()
        W = get_strategy_weights(dfSe['mu_lin'], S,
                                op=optimize_port(
                                    max_gross=max_gross,
                                    max_net=max_net,
                                    min_net=0.0,
                                    risk_imp=risk_imp,
                                    max_k_frac=.5,
                                    risk_limit=risk_limit,
                                    robust=robust,
                                    verbose=0
                                )
                                , max_pos=max_pos, min_pos=min_pos, min_abs_pos=.001
                                , hurdle=hurdle, tc_proportional=.004, exp_hold=exp_hold
                                )
        pdf = pd.DataFrame(W).reset_index()
        print("*"*100)
        print("pdf -> W")
        print(pdf)
        print("*"*100)
        pdf.columns = ['date', 'streamid', 'weightage']
        pdf['testid'] = testId
        pdf['testmodelid'] = 4
        pdf['streamtypeid'] = 220
        pdf['date'] = pd.Series(pdf['date'].dt.to_pydatetime(), dtype=object)
        end_time = datetime.datetime.now()
        print("Total time taken create W & pdf => ", str(end_time-start_time))
        
            
        print(f"...uploading results as [{fileName}].csv to s3")
        upload_df_to_s3(pdf, bucket_name, f"allocation/output/ocm/csv/{fileName}.csv")
        print(f"...uploaded {fileName}.csv to s3")
        

        # pdf=pdf.dtypes(str)
        # pdf["date"] = pdf["date"].dt.strftime("%Y-%m-%d")
        # print(pdf)
        # json_data = pdf.to_json(orient='records')
        # print(json_data)

        if pdf['date'].dtype != 'datetime64[ns]':
            pdf['date'] = pd.to_datetime(pdf['date'])
            pdf['date'] = pdf['date'].dt.strftime("%Y-%m-%d")
        print(pdf)
        json_data = pdf.to_json(orient='records')
        print(json_data)
        is_cancelled=update_allocationtestprogress(testId, 15)
        if is_cancelled:
            print("Tasks was cancelled hence skipping rest of the steps.")
            return is_cancelled
        # print(f"...uploading results as [{fileName}].json to s3")
        # upload_df_as_json_to_s3(pdf, bucket_name, f"allocation/output/ocm/csv/{fileName}.json")
        # print(f"...uploaded {fileName}.json to s3")
        
        import_kelly_allocation_results(testId, json_data)
        is_cancelled=update_allocationtestprogress(testId, 20)
        if is_cancelled:
            print("Tasks was cancelled hence skipping rest of the steps.")
            return is_cancelled
        
        calc_eqfixedmodelweightages(testId)
        is_cancelled=update_allocationtestprogress(testId, 30)
        if is_cancelled:
            print("Tasks was cancelled hence skipping rest of the steps.")
            return is_cancelled
        
        #Test models
        # 2=Equal weight , 3=fixed weight 4=kelly weight   
        # for testmodelid in _testmodels:
        #     calc_allocationmetricdata(testId,testmodelid)
        #     result = 50 if index == 1 else (70 if index == 2 else 90)
        #     is_cancelled=update_allocationtestprogress(testId, result)
        #     if is_cancelled:
        #         	cancel_allocationtest(testId)  
        
        #     print("Tasks was cancelled hence skipping rest of the steps.")
        #     return is_cancelled
        # index+=

        _testmodels = [2, 3, 4]
        index = 1
        for testmodelid in _testmodels:
            calc_allocationmetricdata(testId, testmodelid)
            result = 50 if index == 1 else (70 if index == 2 else 90)
            is_cancelled = update_allocationtestprogress(testId, result)
            if is_cancelled:
                cancel_allocationtest(testId)
                print("Tasks were canceled; hence, skipping the rest of the steps.")
                return is_cancelled  
        
            index += 1

        is_cancelled=update_allocationtestprogress(testId, 100)
        if is_cancelled:
                cancel_allocationtest(testId)
                print("Tasks were canceled; hence, skipping the rest of the steps.")
                return is_cancelled  
        finish_allocationtest(testId)       
        print('Completed CalculateWeighs *****')
    except Exception as fe:
        print("An exception occured in CalucaltWeighs -> ",str(fe))
        cancel_allocationtest(testId)
