import datetime
from datetime import timedelta

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python import PythonOperator
from airflow.utils.email import send_email

from helpers.args_helper import get_default_args
from helpers.timezone_helper import LA_TIMEZONE as local_tz
from allocation.app_starter import RunPreCalc
from arch.__future__ import reindexing

current_timestamp = str(datetime.datetime.today().strftime('%Y-%m-%d')) #'2023-01-11'#
today = datetime.datetime.now(local_tz)

# def send_allocation_success_email(context):
#     subject = "Airflow Precal DAG Succeeded"
#     body = "The RunPreCal DAG Succeeded."
#     send_email(to=['prathap.kolvi@oneilglobaladvisors.com'], subject=subject, html_content=body)

# def send_allocation_failure_email(context):
#     subject = "Airflow Precal DAG Failed"
#     body = "The RunPreCal DAG Failed. Please check http://ocm-airflow-prod.daicompanies.com/tree?dag_id=universe_builder_emr_job_CHINA_HK "
#     send_email(to=['prathap.kolvi@oneilglobaladvisors.com'], subject=subject, html_content=body)


override_args = {'retries': 0}
default_args = {**get_default_args(), **override_args}

dag = DAG('allocation_run_pre_calc', 
          description='Initiate and Run allocation app',  
          default_args=default_args,
          start_date=datetime.datetime(2023, 11, 23, tzinfo=local_tz), 
          is_paused_upon_creation=False,
        #   on_success_callback=send_allocation_success_email,
        #   on_failure_callback=send_allocation_failure_email,
          schedule_interval='0 19 * * 1-5',
          max_active_runs=1,
          catchup=False
          )

start_data_pipeline = DummyOperator(task_id="start_data_pipeline", dag=dag)

run_pre_calc = PythonOperator(task_id="allocation_run_pre_calc",python_callable=RunPreCalc, provide_context=True,dag= dag,on_success_callback=None, on_failure_callback=None)

end_data_pipeline = DummyOperator(task_id="end_data_pipeline", dag=dag, on_success_callback=None,on_failure_callback=None)

start_data_pipeline >>  run_pre_calc >>   end_data_pipeline

