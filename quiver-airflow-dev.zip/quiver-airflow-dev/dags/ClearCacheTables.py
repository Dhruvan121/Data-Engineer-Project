import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('ClearCacheTables', schedule_interval='*/5 * * * *',
          start_date=datetime(2022, 12, 7), tags=['postgresjob'],
          catchup=False)

def clear_tables_function():
    sql = f"select * from cache.clearcachetables();"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    df = pd.read_sql(sql, engine)
    return df.empty


clear_tables_task = PythonOperator(task_id='clear_tables_task',
                                   python_callable=clear_tables_function, provide_context=True,
                                   dag=dag)

clear_tables_task
