import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('DailyDataReload', schedule_interval='30 5 * * 2-6',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def daily_reload_function():
    sql = f"insert into monitor.datareloadstatus(reloadtypeid,reloadjsonconfig,isreloading,reloadstarttime) VALUES(7,null,true,now());"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    engine.execute(sql)


daily_reload_task = PythonOperator(task_id='daily_reload_task',
                                   python_callable=daily_reload_function, provide_context=True,
                                   dag=dag)

daily_reload_task
