import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('RefreshMaterializedView', schedule_interval='*/10 * * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def refresh_materialized_views_function():
    sql = f"select * From ocm.refresh_materializedviews();"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    engine.execute(sql)


refresh_materialized_views_task = PythonOperator(task_id='refresh_materialized_views_task',
                                                 python_callable=refresh_materialized_views_function,
                                                 provide_context=True,
                                                 dag=dag)

refresh_materialized_views_task
