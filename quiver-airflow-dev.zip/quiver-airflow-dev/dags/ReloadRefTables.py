import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('ReloadRefTables', schedule_interval='0 4 * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def reload_factsheet_function():
    sql = f"select * From oga.reload_fact_sheet_data();"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    df = pd.read_sql(sql, engine)
    return df.empty


def reload_ref_table_function():
    sql = f"select * From ref.reload_reftables(1);"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    df = pd.read_sql(sql, engine)
    return df.empty


reload_factsheet_tables_task = PythonOperator(task_id='reload_factsheet_tables_task',
                                              python_callable=reload_factsheet_function,
                                              provide_context=True,
                                              dag=dag)

reload_ref_tables_task = PythonOperator(task_id='reload_ref_tables_task',
                                        python_callable=reload_ref_table_function,
                                        provide_context=True,
                                        dag=dag)

reload_factsheet_tables_task >> reload_ref_tables_task
