import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('IntradayProcessViolations', schedule_interval='*/5 * * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def process_violations_function():
    sql = f"select * from ocm.process_violations(now()::date);"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    df = pd.read_sql(sql, engine)
    return df.empty


process_violations_task = PythonOperator(task_id='process_violations_task',
                                         python_callable=process_violations_function, provide_context=True,
                                         dag=dag)

process_violations_task
