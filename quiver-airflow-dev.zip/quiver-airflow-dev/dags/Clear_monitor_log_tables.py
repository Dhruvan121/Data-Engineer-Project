import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('ClearMonitorLogTables', schedule_interval='0 10 * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)

def clear_log_function():
    sql = f"DELETE FROM monitor.servicelog WHERE createddate <= (NOW() - INTERVAL '5 DAY')::DATE; DELETE FROM monitor.taskerrorhistory WHERE errordate  <= (NOW() - INTERVAL '5 DAY')::DATE; DELETE FROM monitor.userloginlog WHERE lastlogintime  <= (NOW() - INTERVAL '365 DAY')::DATE;"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    engine.execute(sql)


clear_log_tables_task = PythonOperator(task_id='clear_log_tables_task',
                                       python_callable=clear_log_function, provide_context=True,
                                       dag=dag)

clear_log_tables_task
