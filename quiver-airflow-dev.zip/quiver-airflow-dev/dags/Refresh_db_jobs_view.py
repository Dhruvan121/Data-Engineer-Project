import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('RefreshDbJobview', schedule_interval='*/5 * * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def refresh_db_job_function():
    sql = f"REFRESH MATERIALIZED VIEW CONCURRENTLY public.database_jobs; REFRESH MATERIALIZED VIEW CONCURRENTLY public.failed_jobs;"
    engine = create_engine(os.environ['AIRFLOW_CONN_POSTGRES_CLOUD'])
    engine.execute(sql)


refresh_db_job_view_task = PythonOperator(task_id='refresh_db_job_view_task',
                                          python_callable=refresh_db_job_function, provide_context=True,
                                          dag=dag)

refresh_db_job_view_task
