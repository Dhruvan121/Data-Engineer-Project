import datetime
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from allocation.app_starter import CalculateWeighs
from allocation.helper import get_calc_weight_test_id
from helpers.args_helper import get_default_args
from helpers.timezone_helper import LA_TIMEZONE as local_tz



def run_allocation_calculate_weights(**kwargs):
    testId = get_calc_weight_test_id()[0]
    print(f"test id fetched from quiver db => {testId}")

    if testId:        
        CalculateWeighs(testId)
    else:
        print("No testId provided, skipping allocation calculation")




override_args = {'retries': 0}
default_args = {**get_default_args(), **override_args}

dag = DAG(
    'allocation_calculate_weights',
    description='Initiate and Run allocation app',
    default_args=default_args,
    start_date=datetime.datetime(2023, 11, 24, tzinfo=local_tz), 
    is_paused_upon_creation=False,
    schedule_interval='*/5 * * * *',  # Adjust the schedule interval as needed
    max_active_runs=1,
    catchup=False
)

start_data_pipeline = DummyOperator(task_id="start_data_pipeline", dag=dag)

calculate_weights_task = PythonOperator(
    task_id="allocation_calculate_weights",
    python_callable=run_allocation_calculate_weights,
    provide_context=True,
    dag=dag,
)

end_data_pipeline = DummyOperator(task_id="end_data_pipeline", dag=dag)

start_data_pipeline >> calculate_weights_task >> end_data_pipeline
