import datetime
from datetime import timedelta
import pandas as pd
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python import PythonOperator
from airflow.utils.email import send_email
from helpers.utils import get_mssql_db_engine, get_redshift_connection
from helpers.args_helper import get_default_args
from helpers.timezone_helper import LA_TIMEZONE as local_tz
from allocation.helper import upload_df_to_s3 
import os


def read_tsql_save_to_s3(s3_bucket, s3_key):
    print("Starting read from tsql") 
    start_time = datetime.datetime.now() 
    sql_svr_connection = get_mssql_db_engine(db_name="TC")
    cursor = sql_svr_connection.cursor()
    sql_sensor_query = f"""
    SELECT
        T_Index AS T_Index,
        format(T_Index, 'yyyyMMdd')    as T_Date,
        T_Time               as T_Time,
        Prt                  AS PortfolioCode,
        t.T_TradeID       AS TradeID,
        T_Time               AS OrderDate,
        T_Action             AS OrderAction,
        T_Sec                AS Symbol,
        NULL                 AS LocalSymbol,
        Amount               AS Shares,
        Price                AS AvgCost,
        totalCommission      AS Commission,
        GrossMoney           AS TotalValue,
        totalFees            AS Fees,
        netMoney             AS NetTotalValue
    FROM 
        TC.dbo.tc_trade t 
    INNER JOIN 
    TC.dbo.tc_alcf a      
    on t.T_TradeID = a.T_TradeID 
    where 
    T_Status = 'DONE'     

    UNION
    
    SELECT
        T_Index AS T_Index,
        format(T_Index, 'yyyyMMdd')    as T_Date,
        T_Time               as T_Time,
        Prt                  AS PortfolioCode,
        t.T_TradeID       AS TradeID,
        T_Time               AS OrderDate,
        T_Action             AS OrderAction,
        T_Sec                AS Symbol,
        NULL                 AS LocalSymbol,
        Amount               AS Shares,
        Price                AS AvgCost,
        totalCommission      AS Commission,
        GrossMoney           AS TotalValue,
        totalFees            AS Fees,
        netMoney             AS NetTotalValue
    FROM 
        TCArchive.dbo.tc_trade t 
    INNER JOIN 
        TCArchive.dbo.tc_alcf a 
        on t.T_TradeID = a.T_TradeID
    where T_Status = 'DONE'
    """

    df = pd.read_sql(sql_sensor_query, sql_svr_connection)
    upload_df_to_s3(df, s3_bucket, s3_key)
    cursor.close()
    sql_svr_connection.close()
    end_time = datetime.datetime.now()
    print(f"total time taken to read from tsql= {(end_time-start_time)}")

def load_s3_to_redshift(s3_bucket, s3_key, table_name):
    print("starting load_s3_to_redshift")
    start_time= datetime.datetime.now() 
    conn = get_redshift_connection()

    copy_query = f"""
        truncate table {table_name};
        COPY {table_name}(t_index, trade_date, t_time, portfoliocode, 
        tradeid, orderdate, orderaction, symbol, localsymbol, shares, avgcost, 
        commission, totalvalue, fees,nettotalvalue) FROM 's3://{s3_bucket}/{s3_key}'
        credentials  'aws_access_key_id={os.environ.get('AWS_ACCESS_KEY')};aws_secret_access_key={os.environ.get('AWS_SECRET_KEY')}'
        CSV IGNOREHEADER 1 delimiter  ',' ; 
        update {table_name} set process_date = current_timestamp;
    """

    # Execute the COPY command
    with conn.cursor() as cursor:
        cursor.execute(copy_query)
        conn.commit()

    # Close the connection
    conn.close()

    end_time= datetime.datetime.now() 
    print(f"total time taken for load_s3_to_redshift = {(end_time-start_time)}")

current_timestamp = str(datetime.datetime.today().strftime('%Y-%m-%d'))
today = datetime.datetime.now(local_tz)

override_args = {'retries': 0}
default_args = {**get_default_args(), **override_args}

dag = DAG('load_eze_data', 
          description='Initiate EZE data load',  
          default_args=default_args,
          start_date=datetime.datetime(2022, 12, 31, tzinfo=local_tz), 
          schedule_interval="0 14 * * MON-FRI",
          max_active_runs=1, 
          catchup=False)

start_data_pipeline = DummyOperator(task_id="start_data_pipeline", dag=dag)

s3_bucket = "ocm-bullseye-dev"
s3_key="QuiverEZEData/output/eze/Quiver_EZE_data.csv"
redshit_table = 'factor_studies.quiver_raw_eze'
read_tsql_and_save = PythonOperator(
            task_id="read_tsql_save_to_s3", 
            python_callable=read_tsql_save_to_s3, 
            provide_context=True, 
            op_args=[s3_bucket, s3_key],
            dag= dag,
            on_success_callback=None, 
            on_failure_callback=None
        )

load_to_redshift = PythonOperator(
            task_id="load_s3_to_redshift", 
            python_callable=load_s3_to_redshift, 
            provide_context=True, 
            op_args=[s3_bucket, s3_key, redshit_table],
            dag= dag,
            on_success_callback=None, 
            on_failure_callback=None
        )


end_data_pipeline = DummyOperator(task_id="end_data_pipeline", dag=dag, on_success_callback=None,on_failure_callback=None)

start_data_pipeline >>  read_tsql_and_save  >>  load_to_redshift >>  end_data_pipeline

