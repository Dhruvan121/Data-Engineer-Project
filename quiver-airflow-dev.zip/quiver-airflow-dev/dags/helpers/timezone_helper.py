import pendulum

LA_TIMEZONE = pendulum.timezone("US/Pacific")
INDIA_TIMEZONE = pendulum.timezone("Asia/Kolkata")
CHINA_TIMEZONE = pendulum.timezone("Asia/Shanghai")


def get_la_timezone():
    return LA_TIMEZONE


def get_la_datetime(dt):
    return dt.astimezone(LA_TIMEZONE)


def get_india_timezone():
    return INDIA_TIMEZONE


def get_india_datetime(dt):
    return dt.astimezone(INDIA_TIMEZONE)

def get_china_timezone():
    return CHINA_TIMEZONE

def get_china_datetime(dt):
    return dt.astimezone(CHINA_TIMEZONE)
