import os
from sqlalchemy import text
import pymssql
import pandas as pd
import helpers.sql_text_helper as sqlhelper
import io
from datetime import datetime
import numpy as np
import boto3


def get_current_uploadBatchIds(quiver_engine):
    try:
       
        with quiver_engine.connect() as connection:
            
            upload_batch_ids = []
            sql = """select p.uploadbatchid From ref.prtfbatchfreq p 
                            inner join ref.prtfbatchfreqweekday w on w.uploadbatchid = p.uploadbatchid 
                            where now()::time between p.starttime and p.endtime and 
                            w.dayofweek = EXTRACT(DOW FROM now()) and w.isupload = true;"""


            results = connection.execute(text(sql).execution_options(autocommit=True))
            rows = results.fetchall()

            for row in rows:
                upload_batch_ids.append(row["uploadbatchid"])
            return upload_batch_ids
    except Exception as err:
         raise Exception('get_current_uploadBatchIds').with_traceback(err.__traceback__)


def load_to_main_table(tbl_name,quiver_engine):
    try:
        with quiver_engine.connect() as connection: 
            sql = sqlhelper.sql_dict["load_" + tbl_name]   
            connection.execute(text(sql).execution_options(autocommit=True) )
    except Exception as err:
        raise Exception('truncate_postgres_tbl').with_traceback(err.__traceback__)

def create_temp_table(schema,tbl_name,quiver_engine):
    try:
        with quiver_engine.connect() as connection: 
            temp_create_sql = """  DROP TABLE IF EXISTS """  + schema + "." + tbl_name +  "_new;"  + """  CREATE TABLE """  + schema + "." + tbl_name +  "_new ( like """  + schema + "." + tbl_name +  " including all); """      
            connection.execute(text(temp_create_sql).execution_options(autocommit=True) )
    except Exception as err:
        raise Exception('truncate_postgres_tbl').with_traceback(err.__traceback__)

def truncate_postgres_tbl(schema,tbl_name,quiver_engine):
    try:
        print('truncate table: ' + schema + "." + tbl_name)
        with quiver_engine.connect() as connection:       
            connection.execute(text(""" TRUNCATE TABLE """ + schema + "." + tbl_name + ";").execution_options(autocommit=True) )
    except Exception as err:
        raise Exception('truncate_postgres_tbl').with_traceback(err.__traceback__)

def import_df_postgres(schema, tbl_name, df, quiver_engine):
    try:
        print('Starting import')       

        bucket_name = get_bucket_name()
        file_location = get_export_file_location()
        file_name = file_location + tbl_name + '.csv' 
        
        with quiver_engine.connect() as connection:  

            save_data_file_s3(schema, tbl_name, df, bucket_name, file_name, connection)

            query_string = "select aws_s3.table_import_from_s3('" + schema + "." + tbl_name + "','','( FORMAT csv,HEADER true)',aws_commons.create_s3_uri('"+ bucket_name + "','" + file_name + "','us-east-1'));"
            print(query_string)
            connection.execute(text(query_string).execution_options(autocommit=True) )

    except Exception as err:
        raise Exception('import_df_postgres') from err

def get_bucket_name():
    return os.environ.get('OGA_S3_Bucket')

def get_export_file_location():
    file_location = os.environ.get('ENV') + "/"+ os.environ.get('EXPORT_FOLDER')  +"/"
    return file_location

def save_data_file_s3(schema, tbl_name, df, bucket_name, file_name, connection):

    df.columns = [x.lower() for x in df.columns]  
    
    int_columns_query =   """ SELECT LOWER(column_name) as column_name, data_type  
                                     FROM information_schema.columns 
                                     WHERE table_name = '""" + tbl_name +  """' 
                                     AND table_schema = '""" + schema +  """' 
                                     AND data_type in ( 'integer' , 'bigint', 'bit', 'smallint');"""

    result = connection.execute(text(int_columns_query).execution_options(autocommit=True) )
    cols = result.fetchall()          

    for column in cols:
        print('------')
        if column.column_name in df.columns:
            print(column.column_name)
            df[column.column_name] = df[column.column_name].replace([np.nan, np.inf, -np.inf], 0).astype(int)

    # Save the DataFrame as a CSV file to memory buffer
    csv_buffer = pd.io.common.StringIO()
    df.to_csv(csv_buffer, index=False)

    s3 = boto3.resource('s3', aws_access_key_id=os.environ.get('AWS_ACCESS_KEY'), aws_secret_access_key=os.environ.get('AWS_SECRET_KEY'))
          
    s3.Object(bucket_name, file_name).put(Body=csv_buffer.getvalue().encode())
    
def import_table_from_DB(schema,tbl_name,query_key,dest_engine,source_engine, temp_reload = False):
    try:   
        sql = sqlhelper.sql_dict[query_key]
        df = pd.read_sql(sql, source_engine)

        if temp_reload is False:
            truncate_postgres_tbl(schema,tbl_name,dest_engine)
            import_df_postgres(schema, tbl_name,df,dest_engine)
        else:
            create_temp_table(schema, tbl_name, dest_engine)  
            import_df_postgres(schema,tbl_name + "_new",df,dest_engine) 
            load_to_main_table(tbl_name,dest_engine) 
        

    except Exception as err:
        raise Exception('import_table_from_DB').with_traceback(err.__traceback__)   
   
def import_table_from_DB_Date(schema,tbl_name,query_key,dest_engine,source_engine, date):
    try:   
        sql = sqlhelper.generate_query_date(query_key,date)
        df = pd.read_sql(sql, source_engine)

        bucket_name = get_bucket_name() 
        file_location = get_export_file_location()
        file_name = file_location+ tbl_name + '.csv' 

        with dest_engine.connect() as connection:
            save_data_file_s3(schema, tbl_name, df, bucket_name, file_name, connection)
        

    except Exception as err:
        raise Exception('import_table_from_DB_Date').with_traceback(err.__traceback__)   
    

def empty_s3_folder(bucket_name, folder_name):
    s3 = boto3.resource('s3', aws_access_key_id=os.environ.get('AWS_ACCESS_KEY'), aws_secret_access_key=os.environ.get('AWS_SECRET_KEY'))
    bucket = s3.Bucket(bucket_name)
    for obj in bucket.objects.filter(Prefix=folder_name):
        if obj.key.endswith('.csv'):
            s3.Object(bucket.name, obj.key).delete()    

