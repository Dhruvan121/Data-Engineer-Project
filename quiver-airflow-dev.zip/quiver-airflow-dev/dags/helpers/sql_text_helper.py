

sql_dict = {

"inactiversm" : """ 
                SELECT [OSID],[Symbol],[Indcd],[Coname],[Price0],[Volum0],[High0],[Low0],[Price],[Volum],[High],[Low],[Captl]
				,[Epsrnk],[Rlst],[Dgrt],[Grprnk],[PrErn],[Avol],[Shrt],NULLIF(case when osid in( 31642,38447,30580,30658) then '' else [AccDis] end,'') AccDis
				,[FiftyD],[TwoHun],[YrHi],[YrLo],[DJI]
				,[DJT],[DJU],[SP500F],[SP100F],[SP600F],[MIDCAP],[RU1THF],[RU2THF],[RU25TF],[RUMCTF],[RUVATF],[RUGRTF]
				,[RUMCVF],[RUMCGF],[EXCHCD],[BIGCBY],[BIGCSL],[BIGCFB],[BIGCUF],[NSMIBY],[NSMISL],[PSEF],[SplitFactor],[SplitFactor1]
				,[PriceDate],[FiscalMonthEnd],[Captl2],NULLIF([Float1],'') Float1,NULLIF([PctOfIndex],'') PctOfIndex,NULLIF([Smrl],'') Smrl
                ,NULLIF([Smrn],'') Smrn,NULLIF([EstEps],'') EstEps
				,NULLIF([PrevVolum0],'') PrevVolum0,NULLIF([Nasdaq100F],'') Nasdaq100F,NULLIF([PctOfSP500],'') PctOfSP500
				,NULLIF([PctOfNsd100],'') PctOfNsd100,NULL,NULLIF([Cusip],'') Cusip,[NewIssueDate],[EffectiveDate],[NewIssuePrice],[IPOFlag],[ArticleFlag],[CEOFlag],[ResearchFlag]
				,[CountryCode],[Currency]
				  FROM wondb.[dbo].[InactiveRsm]
              """,

"instrument" : """ SELECT [MSID],[InstrumentTypeID],[InstrumentID],NULLIF([Symbol],'') Symbol,NULLIF([Name],'') Name,NULLIF([Description],'') Description
						,NULLIF([Status],'') Status
						,[TradingDateEarliest],[TradingDateLatest],[HasComponents],[HasOptions],[IsCanadian],[IsScreenable]
						,[IsGraphable],NULLIF([Sedol],'') Sedol,NULLIF([Cusip],'') Cusip,NULLIF([ISIN],'') ISIN,[CountryCode],[GicsSubIndustryCode],[IndustryGroupCode]
						,NULLIF([Story],'') Story,NULLIF([ThomsonSymbol],'') ThomsonSymbol,NULLIF([BloombergSymbol],'') BloombergSymbol
						,NULLIF([LocalSymbol],'') LocalSymbol,[MXID],[ModifyDate]
						  FROM [Panaray].[ref].[Instrument] where msid not in (2777284,2785642,2797457,2818185,2877879,2993097) and  [IndustryGroupCode] IS NOT NULL"""             , 


"countryregion": """ SELECT [CountryCode],[CountryName],[Region]
				 FROM panaray.[ref].[countryregion] """     ,                     


"instrumentType" :  """ SELECT InstrumentTypeID,
       InstrumentCode,
       Name,
       CSGroupID FROM panaray.ref.InstrumentType """     ,           


"instrument_master" : """ SELECT InstrumentID, Symbol, InstrumentTypeID, InstrumentType,
				 CASE WHEN SUBSTRING(Name, 0,2) = '' THEN ' ' ELSE NULLIF(Name,' ') END
				, FFOInd, CountryCode, DefCurrency, CurrencySymbol, ExchangeID, NULLIF(ExchangeCode,''), ExchangeName,
				 ScrollDt, FiscalMonthEnd, AvgDailyVol, DailyPvStart, DailyPvEnd, WeeklyPvStart, WeeklyPvEnd, MonthlyPvStart, MonthlyPvEnd, FCqEstCnt, FCaEstCnt, Intraday01PvStart,
				 Intraday01PvEnd, Intraday05PvStart, Intraday05PvEnd, Intraday10PvStart, Intraday10PvEnd, Intraday15PvStart, Intraday15PvEnd, Intraday30PvStart, Intraday30PvEnd, Intraday60PvStart,
				 Intraday60PvEnd, IPODate, [Open], [Close], ThmExchCode, CountryCodeISO, ZoneID, NULLIF(Sym2,''), RLST, NULLIF(replace(replace(ACCDIS,CHAR(13),''),CHAR(0),''),'') 
				  , AnnualRpt, SemiAnnualRpt, QuarterRpt, PvUpdated,
				 IndVol, PriceDate, Earnrptdate, FSIIndicator, ACCDISint FROM wondb.dbo.APPX_InstrumentMaster; """   ,    

"currencies" : """ SELECT a.osid, a.symbol, REPLACE(a.coname, 'US Dollar To ', '') as coname, c.CurrencyCode, c.CurrencySymbol, s.price0
				  FROM wondb.dbo.APPX_CurrencyList a
				  INNER JOIN wondb.RayMobile.Currency c ON '1' + c.CurrencyCode = a.symbol
				  LEFT JOIN wondb.dbo.secmaster s on s.osid = a.osid
				  ORDER BY symbol;  """  ,   



"OneilSector" : """ SELECT OneilSectorCode,OneilSectorName,OneilSectorSymbol,SeqNo FROM Panaray.ref.OneilSector; """ ,                             


"OneilMajorIndustry": """ SELECT OneilMajorIndustryCode,OneilMajorIndustryName,OneilSectorCode,OneilMajorIndustrySymbol,SeqNo FROM Panaray.ref.OneilMajorIndustry; """,

"OneilIndustryGroup" : """ SELECT OneilIndustryGroupCode,OneilIndustryGroupName,OneilMajorIndustryCode,OneilIndustryGroupSymbol,SeqNo FROM Panaray.ref.OneilIndustryGroup; """,

"hhsfint" : """ SELECT * FROM wondb.dbo.hhsfint WHERE countrycode <> 1 UNION
				 SELECT * FROM wondb.dbo.ahhsfint WHERE countrycode <> 1 UNION
				 SELECT * FROM wondb.dbo.FutureHoliday UNION
				 SELECT 1 AS Ctrycode ,dHoliday,0 AS holiday , NULL AS htdc FROM wondb.dbo.Holidays; """ ,


"InstrumentTypeMapping" : """ SELECT InstrumentTypeID,BrowserInstrTypeID FROM panaray.ref.InstrumentTypeMapping  """   ,   


"BrowserInstrumentType" : """ SELECT BrowserInstrTypeID,BrowserInstrTypeName FROM panaray.ref.BrowserInstrumentType """,

"Country" : """ SELECT CountryCode,CountryName,RegionCode,SeqNo FROM 	panaray.ref.Country """,

"region" : """ SELECT RegionCode,RegionName FROM 	panaray.ref.Region """,


"splits" : """SELECT * FROM
				(SELECT * FROM wondb.dbo.hsfsplits
				UNION
				SELECT * FROM wondb.dbo.AHsfSplits) a
				ORDER BY a.Date DESC  """,


"exchange" : """ SELECT * FROM wondb.dbo.Exchange """       , 


"exchangelist" : """ SELECT PKExchangeKey,ExchangeName,ExchangeID,WONExchangeID,ExchangeSourceCode,ExchangeISOCode,TimeZone,OperatingCountry
				,ExchangeCity,ExchnageWEBAddress,ExchangeStatus,ColumnLockStatus,RowStatus,ModificationDate,ParentExchange
				,BloombergExchangeCode,OptionCode,UTCOffset,UTCDayLightOffset,MarketOpenTime,MarketCloseTime,BreakStartTime,BreakEndTime
				,BreakTrade,isMonday,isTuesday,isWednesday,isThursday,isFriday,isSaturday,isSunday,isDaylight,HoursWebsite
				  FROM wondb.dbo.ExchangeList where WONExchangeID > 0;  """,


"acwi_list" : """ DECLARE @OwnerID INT
	            SET @OwnerID = 22942157  
                
                DECLARE @MaxDate Date
	            Set @MaxDate = ( SELECT max(MonthEndDate) FROM WONDW.SponsorshipDW.dbo.HoldingsMonthly WHERE OwnerID = @OwnerID AND CarryForward <> 1)

                SELECT 'U8572141' as accoutnumber,2757 as portfolioid,
				 RIGHT(ISNULL(cux.CurrencyWONSymbol,'1USD'),3) AS BrokerCurrencycode
				,REPLACE(CASE
									WHEN ins.Symbol LIKE '%.NL' AND ins.LocalSymbol LIKE '%a' THEN 
										SUBSTRING(ins.LocalSymbol, 1, LEN(ins.LocalSymbol)-1)
									ELSE ins.LocalSymbol
								END, '.T', '')  AS BrokerLocalSymbol
				,ins.LocalSymbol AS WONLocalSymbol
				,ins.InstrumentID AS OSID
				,ins.Symbol
				FROM Panaray.ref.Instrument AS ins
				INNER JOIN (SELECT
						hm.MonthEndDate
						,hm.ReportDate
						,se.OSID
						,se.SecurityName
						,se.CUSIP
						,se.ISIN
						,se.Sedol
						,se.TickerSymbol
						,se.SecurityClass
						,co.CorpOSID
						,co.CorpWONSymbol
					FROM WONDW.SponsorshipDW.dbo.HoldingsMonthly AS hm
					INNER JOIN WONDW.SponsorshipDW.dbo.[Security] AS se 
						ON se.PKSecurityKey = hm.SecurityKey
					INNER JOIN WONDW.wpg.dbo.Corporation AS co 
						ON se.OSID = co.CorpOSID
					WHERE 
						hm.ReportDate = @MaxDate 
						AND hm.MonthEndDate = @MaxDate 
						AND hm.OwnerID =@OwnerID 
						AND (se.SecurityClass <> 'FUN' OR se.SecurityClass IS NULL)
						AND (co.CorpStatus = 'A' OR co.CorpStatus IS NULL)
						AND hm.SharesHeld <> 0
						AND hm.CarryForward <> 1) AS acwi
					ON acwi.OSID = ins.InstrumentID
				INNER JOIN wondb.dbo.Secmaster AS sm
					ON sm.OSID = ins.InstrumentID
				LEFT JOIN wondb.dbo.TechnicalItemData AS ti
					ON ti.OSID = sm.OSID
					AND ti.PrimeExchText = 'Yes'
				LEFT JOIN wondb.dbo.CurrencyXref AS cux
					ON cux.CurrencyOSID = ISNULL(sm.Currency, 3000001)
				WHERE 
					ins.InstrumentTypeID = 1
					ORDER BY BrokerLocalSymbol;
                
                """         ,

	"load_browserinstrumenttype" : """INSERT INTO ref.browserinstrumenttype
								SELECT * FROM ref.BrowserInstrumentType_new
								ON CONFLICT(browserinstrtypeid) DO UPDATE SET browserinstrtypename = excluded.browserinstrtypename;
								DROP TABLE IF EXISTS  ref.BrowserInstrumentType_new;

								INSERT INTO ref.browserinstrumenttype(browserinstrtypeid,browserinstrtypename)
								VALUES (200,'Discretionary'),
									(210,'Algorithmic - Virtual'), 	
									(220,'Algorithmic - Live'),
									(230,'Cash')
								ON CONFLICT(browserinstrtypeid) DO UPDATE SET browserinstrtypename = excluded.browserinstrtypename;	
									
									"""		,


	"portfolio" : """SELECT PortfolioID,PortfolioCode,PortfolioGUID,OwnedBy,PrimaryContactID ,OwnerContactID ,OwnerAddressID,OwnerPhoneID ,BillingContactID ,BillingAddressID ,BillingPhoneID ,
						BankContactID,BankAddressID ,BankPhoneID,	ProcessingGroupID,ReconciliationCloseDate,NULLIF(ShortName,''),NULLIF(PortfolioStatus,''),NULLIF(TaxNumber,''),NULLIF(TaxStatus,''),NULLIF(PortfolioTypeCode,''),
						NULLIF(InvestmentGoal,''),InitialValue,IsPositionOnly,
						IsExcludedFromGroupRules,NULLIF(DocumentLink,''),NULLIF(URL,''),IsIncomplete	FROM APXFirm.AdvApp.vPortfolio""",

	"contact" : """ SELECT [ContactID],[ContactCode],NULLIF([LastName],''),NULLIF([FirstName],''),NULLIF([MiddleName],''),NULLIF([Company],''),NULLIF([Title],''),NULLIF([Email],''),NULLIF([Email2],''),
					 NULLIF([Email3],''),[OwnedBy] FROM APXFirm.[AdvApp].[vContact] """	,

	"contactemails" : """ SELECT ContactBaseID,Email1 FROM APXFirm.APX.vContactEmails WHERE Email1 != '' """	,				 										         

	"vCurrency" : """ SELECT CurrencyCode,ISOCode,CurrencyName,NULLIF(SecTypeNameSuffix,''),NULLIF(CurrencySymbol,''),CurrencyPrecision,
					 SequenceNo,IsGlobalCurrency,IsMoxySystemCurrency FROM apxfirm.advapp.vCurrency """	,		
    "interestedparties" : """ SELECT PortfolioBaseID,ContactID FROM APXFirm.APX.InterestedParty """	,		
    "portfoliobasecustom" : """ SELECT [PortfolioBaseID],[PortfolioBaseTypeCode],[PortfolioBaseCode],[ClassID],[PortfolioType],[LMVLimit],[Company],[PortfolioSubType],[Brokerage]
					  ,[DailyReporting],[Methodology],[Style],[Geography],NULLIF(OriginAccount,''),NULLIF(AnalyzedReporting,''),NULLIF(PortfolioNotes,''),
					  NULLIF(AccountAbbreviation,''),NULLIF(Management,''),NULLIF(ManagementStyle,''),NULLIF(DeactivatedDate,''),leaderboard,NULLIF(strategy,''),NULLIF(DefaultCurrency,''), 
					  NULLIF(Manager,'')
					  FROM [APXFirm].[AdvApp].[vPortfolioBaseCustom] """	,		
    "taxlotcurrent" : """ SELECT PortfolioID,SecurityID,LotTransactionID,IsPledge,CustodianID,SecTypeCode,IsShortPosition,LotNumber,Quantity
      ,OriginalCostSystemCurrency,OriginalCostLocalCurrency,OriginalCostPortfolioCurrency,OriginalCostDate,OriginalFace,HeldLongDate
      ,IPCounter,NULLIF(BrokerRepSymbol,''),StrategyID,PortfolioCode,Symbol,IsZeroMV FROM APXFirm.AdvApp.vPortfolioTaxLotCurrent """	,		
    
	"lmvhistory" : """  SELECT po.PortfolioID,CONVERT(DATE, ae.AuditEventTime) as date,ae.AuditEventTime,au.LMVLimit
						FROM APXFirm.AdvApp.vPortfolio AS po
						LEFT JOIN APXFirm.dbo.AdvPortfolioBaseExt_Audit AS au ON au.PortfolioBaseID = po.PortfolioID
						LEFT JOIN APXFirm.dbo.AdvAuditEvent AS ae  ON ae.AuditEventID = au.AuditEventIDIn 		
    					UNION
                        SELECT  x.PortfolioBaseID,CONVERT(DATE, ae.AuditEventTime) as date,ae.AuditEventTime,x.LMVLimit
						FROM APXFirm.dbo.AdvPortfolioBaseExt AS x
						LEFT JOIN APXFirm.dbo.AdvAuditEvent AS ae ON ae.AuditEventID = x.AuditEventID """	,		
    "vOGA_CapitalAccountDetail" : """ SELECT ContactID,ContactCode,FirstName,NULLIF(ContactStatus,''),CapitalID,PortfolioCode,CapitalAccount,
										FundCode,Tranche,ReportHeading1,ReportHeading2,ReportHeading3,PortfolioStatus,StartDate,
										NULLIF(CloseDate,''),PortfolioSubType,PortfolioType,InitialValue,ClassName,ManagementFee,NULLIF(IncentiveFee,''),
										Subscriptions,NULLIF(Redemptions,''),NetContributions 
										FROM APXFirm.dbo.vOGA_CapitalAccountDetail """	,			
    "OGA_Fund" : """ SELECT FundID,FundCode,PortfolioBaseID,Feeder,ParentFundID FROM APXFirm.dbo.OGA_Fund """	,		
    "vPortfolioComposite" : """ SELECT  PortfolioCompositeID,PortfolioCompositeCode,OwnedBy,NULLIF(Purpose,'') FROM APXFirm.AdvApp.vPortfolioComposite; """	,		
    "vPortfolioCompositeMember" : """ SELECT PortfolioCompositeID,PortfolioCompositeCode,MemberID,MemberCode,EntryDate,ExitDate,NULLIF(Comments,'') FROM APXFirm.AdvApp.vPortfolioCompositeMember; """	,		
    "vPortfolioBase" : """ SELECT PortfolioBaseID,PortfolioBaseTypeCode,PortfolioBaseCode,OwnedBy,NULLIF(ReportHeading1,''),
						NULLIF(ReportHeading2,''),NULLIF(ReportHeading3,''),StartDate,CloseDate,BankAddressID,BankContactID,
						BankPhoneID,DecisionMakerID,DecisionMakerAddressID,DecisionMakerPhoneID,BillingAddressID,
						BillingContactID,BillingPhoneID,OwnerAddressID,OwnerContactID,OwnerPhoneID,
						PrimaryContactID,CashBuffer,CashBufferPercent 
						FROM APXFirm.advapp.vPortfolioBase; """	,	
    "gips_firm_asset" : """ SELECT MonthDate,FirmAUM,CountAccounts
						FROM [APXFirm].[Reporting].[vFirmAUM]
						ORDER BY MonthDate DESC; """	,	
    "portfpm" : """ SELECT PortfolioID,Indcd,ContactID
						FROM APXFirm.oga.vIndustry_Assignment_SSRS
						WHERE PortfolioID <> 0
						ORDER BY PortfolioID, Indcd, ContactID; """	,
    "ecmcontact" : """  SELECT HubContactID,NULLIF([LastName],''),NULLIF([FirstName],''),NULLIF([MiddleInitial],''),NULLIF([Honorific],''),NULLIF([Suffix],'') 
    					FROM ECMDB.dbo.ECMContact """	,   
    "AdvTransactionCode" : """  SELECT [TransactionCode],[TranCodeLabel],[EffectOnQuantity],[AuditEventID],
    								   [AuditTypeCode],[AuditTimestamp],[IsAllowedInTransaction]  FROM ApxFirm.[dbo].[AdvTransactionCode]; """	,	
    "pmlist" : """  SELECT osid,datetime FROM clientdata.dbo.pmList_history; """	,	
    "smidlist" : """ SELECT osid,snapshot_date FROM clientdata.dbo.smidlist_history;  """	,	
    # "" : """  """	,	
    # "" : """  """	,	
    # "" : """  """	,		
}

def generate_query_date(key, date):
    queries = {
         "vportfoliotransaction" : """ 
			SELECT TransactionCode,TranCodeLabel,PortfolioID,PortfolioTransactionID,TradeDate,SequenceNo,NULLIF(Comment,''''),SecTypeCode1,
             SecurityID1,SettleDate,OriginalCostDate,Quantity,ClosingMethodCode,SecTypeCode2,SecurityID2,NumeratorCurrencyCode,DenominatorCurrencyCode,
             TradeDateFX,SettleDateFX,OriginalFX,MarkToMarket,TradeAmount,OriginalCost,WithholdingTax,ExchangeID,ExchangeFee,Commission,
             ImpliedCommission,OtherFees,MiscFees,FeePeriodDate,CommissionPurposeID,IsPledge,CustodianID,IsDestPledge,DestCustodianID,OriginalFace,YieldOnCost,
             DurationOnCost,TransUserDef1ID,TransUserDef2ID,TransUserDef3ID,TransUserDef4ID,TransUserDef5ID,TransUserDef6ID,TransUserDef7ID,TransUserDef8ID,
             TransUserDef9ID,TranID,IPCounter,SourceID,PostDate,LotNumber,ReclaimAmount,StrategyID,RecordDate,DivTradeDate,PerfContributionOrWithdrawal,
             VersusDate,BrokerFirmID,BrokerRepSecurityID,TradeBlotterLineID,OmnibusID,ApplyToShortPosition,EstDividendState,AllocationID,IsRecallable,ContributedCapital,
             CommittedCapital,CostAdjustmentTypeCode,SettledByDate,FlowTimingCode,AdjustedCost
             FROM ApxFirm.AdvApp.vPortfolioTransaction WHERE TradeDate >=  '"""	 + date + "';",
             
        "vSecuritySplit": """ SELECT SecuritySplitID,SecurityID,ExDate,ShareIn,ShareOut
                			FROM ApxFirm.AdvApp.vSecuritySplit  WHERE ExDate >= '""" + date + "';" ,
		"vFXRate" : """ SELECT NumeratorCurrencyCode,DenominatorCurrencyCode,TriangulateCurrencyCode,PriceDate,
					 SpotRate,Bid30DayRate,Bid60DayRate,Bid90DayRate,Bid180DayRate,Bid360DayRate,Bid720DayRate,
					 ShowInverted,AsOfDate,ThruDate,FxTypeID
					 FxTypeID FROM apxFirm.AdvApp.vFXRate WHERE SpotRate IS NOT NULL AND SpotRate <> 1 
                     AND DenominatorCurrencyCode IN ('us','in','cn','hk') AND PriceDate = CAST(GETDATE() AS DATE)  """, 
                                
        "vSecurityPrice": """SELECT SecurityID,CurrencyCode,PriceDate,ClosePrice,ValuationFactor,PaydownFactor,PriceTypeID FROM apxfirm.AdvApp.vSecurityPrice
					 WHERE pricedate = CAST(GETDATE() AS DATE)"""
                          
	}
    return queries[key]
