import os
from datetime import datetime
from typing import Optional
from sqlalchemy import create_engine
from airflow import DAG
from airflow.operators.python import ShortCircuitOperator
from helpers.timezone_helper import LA_TIMEZONE as local_tz


def holiday_check_short_circuit_operator(dag: DAG, country_code: int = 1, trade_date: Optional[datetime] = None, time_zone=local_tz):
    # today = trade_date if trade_date else datetime.now()
    if trade_date is None:
        today = datetime.now(time_zone)
        today_string = today.strftime("%Y%m%d")
    else:
        today_string = trade_date.strftime("%Y%m%d")
        
    def holiday_func(**kwargs):
        import pandas as pd
        sql = f"select tradedate from public.ts_holidays where countrycode={kwargs.get('country_code')} and tradedate={today_string}"
        engine = create_engine(os.environ['AIRFLOW_CONN_FACTOR_SERVER'])
        df = pd.read_sql(sql, engine)
        return df.empty

    holiday_op = ShortCircuitOperator(task_id='holiday_task', python_callable=holiday_func, dag=dag,
                                      op_kwargs={'country_code': country_code, 'trade_date': trade_date})
    return holiday_op

def holiday_check_short_circuit_operator_taskflow(country_code: int = 1, trade_date: Optional[datetime] = None, time_zone=local_tz):
    today = datetime.now(time_zone)
    today_string = today.strftime("%Y%m%d")

    def holiday_func(**kwargs):
        import pandas as pd
        sql = f"select tradedate from public.ts_holidays where countrycode={kwargs.get('country_code')} and tradedate={today_string}"
        engine = create_engine(os.environ['AIRFLOW_CONN_FACTOR_SERVER'])
        df = pd.read_sql(sql, engine)
        return df.empty

    holiday_op = ShortCircuitOperator(task_id='holiday_task', python_callable=holiday_func,
                                      op_kwargs={'country_code': country_code, 'trade_date': trade_date})
    return holiday_op
