import os
from typing import Any
import pymssql
import psycopg2
from urllib.parse import urlparse
import boto3
from io import StringIO, BytesIO
from kubernetes.client import models as k8s

from airflow.models.variable import Variable

def parse_bool(bool_str):
    return str(bool_str).lower() in ['true', '1', 'yes', 'y']

default_memory = "24Gi"
default_cpu = "14"
limit_memory="28Gi"
limit_cpu="15"
tolerations = [{'key': 'compute', 'operator': 'Equal', 'value': 'true', 'effect': 'NoExecute'}]
node_selectors = {"role": "compute"}


def get_additional_pod_options(memory=default_memory, cpu=default_cpu, limit_memory=limit_memory, limit_cpu=limit_cpu, add_env_vars: dict = None) -> dict:
    """This builds up the common parameters needed for the KubernetesPodOperator.  Handles the two scenarios for running locally (in_cluster=False) and
    running it in dev/prod (in_cluster = True).  For most part, you don't need to do anything here.

    """
    in_cluster = parse_bool(os.environ.get('OCM_K8_POD_IN_CLUSTER', 'False'))
    namespace = os.environ.get('OCM_K8_POD_NAMESPACE')
    cluster_context = None
    config_file = None

    if not in_cluster:
        cluster_context = os.environ.get('OCM_K8_POD_CLUSTER_CONTEXT')
        # config_file = '/usr/local/airflow/include/.kube/config'

    running_remote = in_cluster or cluster_context != "docker-desktop"

    ns = node_selectors if running_remote else None
    t = tolerations if running_remote else None
    resources=dict(
        request_cpu=cpu,
        limit_cpu=limit_cpu,
        request_memory=memory,
        limit_memory=limit_memory
    )
    env_vars = None
    env_from = None
    if not running_remote:
        env_vars = {**dict(os.environ)}

    # if running_remote:
    #     default_secrets = 'airflow-config-envs'
    #     # this is the airflow secrets we create so this container will have same environment variables as main image
    #     env_from = [k8s.V1EnvFromSource(secret_ref=k8s.V1SecretEnvSource(name=default_secrets))]

    if add_env_vars:
        env_vars = env_vars if env_vars else {}
        env_vars = {**env_vars, **add_env_vars}

    # This annotation should prevent cluster scaler from evicting pods to rebalance.
    # This shouldn't happen often, but this is good way to make sure it doesn't happen for airflow workflows
    annotations = {
        'karpenter.sh/do-not-evict': "true",
        'cluster-autoscaler.kubernetes.io/safe-to-evict': "false"
    }

    return dict(
        namespace=namespace,
        cluster_context=cluster_context,
        config_file=config_file,
        in_cluster=in_cluster,
        is_delete_operator_pod=parse_bool(os.environ.get('OCM_K8_IS_DELETE_OPERATOR', in_cluster)),
        get_logs=True,
        resources=resources if running_remote else None,
        node_selectors=ns,
        tolerations=t,
        env_vars=env_vars,
        env_from=env_from,
        annotations=annotations
    )


def get_redshift_connection():
    airflow_conn = os.environ.get('AIRFLOW_CONN_FACTOR_SERVER')
        
    if airflow_conn:
        parsed_url = urlparse(airflow_conn)
        dbname = parsed_url.path[1:]  # Extracting the database name from the URL
        user = parsed_url.username
        password = parsed_url.password
        host = parsed_url.hostname
        port = parsed_url.port

        return psycopg2.connect(
            dbname=dbname,
            user=user,
            password=password,
            host=host,
            port=port
        )

def get_mssql_engine(server, username, password, db):
    return pymssql.connect(server, username, password, db)


def get_mssql_db_engine(db_name):
    AIRFLOW_CONN_MS_TS_DEV_SERVER=os.environ['AIRFLOW_CONN_MS_TS_DEV_SERVER']                            
    AIRFLOW_CONN_MS_TS_DEV_USER= os.environ['AIRFLOW_CONN_MS_TS_DEV_USER']
    AIRFLOW_CONN_MS_TS_DEV_PASSWORD=os.environ['AIRFLOW_CONN_MS_TS_DEV_PASSWORD']
    return get_mssql_engine(AIRFLOW_CONN_MS_TS_DEV_SERVER, AIRFLOW_CONN_MS_TS_DEV_USER,AIRFLOW_CONN_MS_TS_DEV_PASSWORD, db_name)


def get_s3_client():
    AWS_ACCESS_KEY=os.environ['AWS_ACCESS_KEY']
    AWS_SECRET_KEY=os.environ["AWS_SECRET_KEY"]
    return boto3.client('s3',  aws_access_key_id=AWS_ACCESS_KEY, aws_secret_access_key=AWS_SECRET_KEY)

def upload_df_to_s3(df, bucket_name, file_name):
    s3 = get_s3_client()
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)
    s3.upload_fileobj(BytesIO(csv_buffer.getvalue().encode()), bucket_name, file_name)
  
def read_s3_bucket(bucket_name, folder, file_format=None):
    s3 = get_s3_client()
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=folder)
    objects = response.get('Contents', [])
    if file_format is not None:
        robjs = []
        for obj in objects:
            print(obj)
            file_key = obj['Key']
            if file_key.lower().endswith(file_format):
                robjs.append(obj)
        return robjs
    else:
        return objects

def archive_s3_file(s3_bucket, file_key, archive_key):
    s3 = get_s3_client()
    print(f"copyng {file_key} to {archive_key}")
    s3.copy_object(Bucket=s3_bucket, CopySource={'Bucket':s3_bucket, 'Key':file_key}, Key=archive_key)
    print(f"deleting {file_key}")
    s3.delete_object(Bucket=s3_bucket, Key=file_key)