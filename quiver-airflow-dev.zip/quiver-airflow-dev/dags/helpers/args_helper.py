from os import environ
from datetime import timedelta,date

# from ocm_airflow.utils import parse_bool, is_local_env
# from ocm_airflow.slack_helper import send_slack_alert

# OCM_EMAIL_ON_RETRY = parse_bool(environ.get('OCM_EMAIL_ON_RETRY', 'False'))
# OCM_EMAIL_ON_FAILURE = parse_bool(environ.get('OCM_EMAIL_ON_FAILURE', 'False'))
# OCM_EMAIL_LIST_CSV = environ.get('OCM_EMAIL_LIST_CSV', '').split(',')


def get_default_args():
    return {
        'owner': 'QUIVER',
        'depends_on_past': False,
        # 'email': OCM_EMAIL_LIST_CSV,
        # 'email_on_retry': OCM_EMAIL_ON_RETRY,
        # 'email_on_failure': OCM_EMAIL_ON_FAILURE,
        'retries': 0,
        'retry_delay': timedelta(minutes=5),
        # 'on_failure_callback': send_slack_alert

    }



def get_current_date():
    return date.today()