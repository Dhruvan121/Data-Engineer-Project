import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('TradeExceptionReport', schedule_interval='0 17 * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def run_trade_exception_report_function():
    sql = f"insert into monitor.datareloadstatus(reloadtypeid,reloadjsonconfig,isreloading,reloadstarttime) VALUES(15,null,true,now());"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    engine.execute(sql)


run_trade_exception_report_task = PythonOperator(task_id='run_trade_exception_report_task',
                                                 python_callable=run_trade_exception_report_function,
                                                 provide_context=True,
                                                 dag=dag)

run_trade_exception_report_task
