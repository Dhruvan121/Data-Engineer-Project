import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('ClearNasdaqQuotes', schedule_interval='35 21 * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def clear_nasdaqquotes_function():
    sql = f"Delete FROM ocm.nasdaqquotes;"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    engine.execute(sql)


clear_nasdaqquotes_table_task = PythonOperator(task_id='clear_nasdaqquotes_table_task',
                                               python_callable=clear_nasdaqquotes_function, provide_context=True,
                                               dag=dag)

clear_nasdaqquotes_table_task
