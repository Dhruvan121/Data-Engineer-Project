import datetime
import os

from datetime import timedelta
import pandas as pd
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python import PythonOperator
from airflow.utils.email import send_email
from helpers.utils import read_s3_bucket, archive_s3_file, get_mssql_db_engine, get_redshift_connection
from helpers.args_helper import get_default_args
from helpers.timezone_helper import LA_TIMEZONE as local_tz



def check_s3_files(s3_bucket, s3_key, file_format=".csv"):
    objects = read_s3_bucket(s3_bucket, s3_key, file_format)
    if objects:
      print("OBJECT PRESENT")
      return True
    else:
        print("No LEI file found in <s3 location>")
        raise Exception(f"No LEI file found in <s3 location > {s3_key}")
    
def prepare_backup_table(table_name, backup_table):
    print("starting prepare_backup_table")
    start_time= datetime.datetime.now() 
    conn = get_redshift_connection()

    bkp_query = f"""
    drop table if exists {backup_table};
    create table {backup_table} as select * from {table_name};
    """

    # Execute the COPY command
    with conn.cursor() as cursor:
        cursor.execute(bkp_query)
        conn.commit()

    # Close the connection
    conn.close()

    end_time= datetime.datetime.now() 
    print(f"total time taken for prepare_backup_table = {(end_time-start_time)}")

def get_source_file_key(s3_bucket, s3_key, file_format):
    obj = read_s3_bucket(s3_bucket, s3_key, file_format)[0]
    return  obj['Key']

def load_s3_to_redshift(s3_bucket, s3_key, file_format,  table_name):
    print("starting load_s3_to_redshift")
    start_time= datetime.datetime.now() 
    conn = get_redshift_connection()

    file_key = get_source_file_key(s3_bucket, s3_key, file_format)
    copy_query = f"""
    truncate table {table_name};
    COPY {table_name}(lei, isin) FROM 's3://{s3_bucket}/{file_key}'
    credentials  'aws_access_key_id={os.environ.get('AWS_ACCESS_KEY')};aws_secret_access_key={os.environ.get('AWS_SECRET_KEY')}'
    FORMAT CSV
    DELIMITER ',' 
    IGNOREHEADER 1;
    update {table_name} set create_ts = current_timestamp ;
    """

    with conn.cursor() as cursor:
        cursor.execute(copy_query)
        conn.commit()
    conn.close()

    end_time= datetime.datetime.now() 
    print(f"total time taken for load_s3_to_redshift = {(end_time-start_time)}")


def roll_back_table(table_name, backup_table):    
    conn = get_redshift_connection()

    roll_back_query = f"""
    truncate table {table_name};
    insert into {table_name} select * from {backup_table} ;
    """
 
    with conn.cursor() as cursor:
        cursor.execute(roll_back_query)
        conn.commit()

    # Close the connection
    conn.close()
    
    
def validate_records(table_name, backup_table, valid_record_counts=7000000):
    print("starting validate_records")
    start_time= datetime.datetime.now() 
    conn = get_redshift_connection()

    valid_query = f"""
    select count(*) from {table_name};    
    """

    record_count = 0
    with conn.cursor() as cursor:
        cursor.execute(valid_query)
        record_count = cursor.fetchone()[0]
    print(f"total records loaded into {table_name} => {record_count}")
    
    conn.close()

    if record_count < valid_record_counts:
        print(f"total records [{record_count}] are less than {valid_record_counts} hence rolling back")
        roll_back_table(table_name, backup_table)
        raise Exception(f"total records [{record_count}] are less than {valid_record_counts} thus rolling back")

    end_time= datetime.datetime.now() 
    print(f"total time taken for validate_records = {(end_time-start_time)}")


def archive_source_file(s3_bucket, s3_key, archive_folder, file_format=".csv"):
    objects = read_s3_bucket(s3_bucket, s3_key, file_format)
    for obj in objects:
      file_key = obj['Key']
      print(f"archiving {file_key}")      
      file_name = os.path.basename(file_key)
      archive_key = f"{archive_folder}{file_name}"
      archive_s3_file(s3_bucket, file_key, archive_key)


#####
# 
# Main script as below
#    


current_timestamp = str(datetime.datetime.today().strftime('%Y-%m-%d'))
today = datetime.datetime.now(local_tz)

override_args = {'retries': 0}
default_args = {**get_default_args(), **override_args}

dag = DAG('load_isin_lei_redshift', 
          description='Initiate ISIN LEI REDSHIFT data load',  
          default_args=default_args,
          start_date=datetime.datetime(2022, 12, 31, tzinfo=local_tz), 
          schedule_interval="0 14 * * MON-FRI",
          max_active_runs=1, 
          catchup=False)

start_data_pipeline = DummyOperator(task_id="start_data_pipeline", dag=dag)

s3_bucket = 'ocm-bullseye-dev'
s3_key = 'lei_isin/input/'
archive_folder = 'lei_isin/archive/'
file_format=".csv"
redshit_table = 'landing.lei_isin'
backup_table = 'landing.lei_isin_backup'

new_files_available = PythonOperator(
            task_id="check_s3_files", 
            python_callable=check_s3_files, 
            provide_context=True, 
            op_args=[s3_bucket, s3_key, file_format],
            dag= dag,
            on_success_callback=None, 
            on_failure_callback=None
        )

prepare_backup = PythonOperator(
            task_id="prepare_backup_table", 
            python_callable=prepare_backup_table, 
            provide_context=True, 
            op_args=[redshit_table, backup_table],
            dag= dag,
            on_success_callback=None, 
            on_failure_callback=None
        )

load_to_redshift = PythonOperator(
            task_id="load_s3_to_redshift", 
            python_callable=load_s3_to_redshift, 
            provide_context=True, 
            op_args=[s3_bucket, s3_key, file_format, redshit_table],
            dag= dag,
            on_success_callback=None, 
            on_failure_callback=None
        )

validate_loaded_records = PythonOperator(
            task_id="validate_records", 
            python_callable=validate_records, 
            provide_context=True, 
            op_args=[redshit_table, backup_table, 7000000],
            dag= dag,
            on_success_callback=None, 
            on_failure_callback=None
        )

archive_source = PythonOperator(
            task_id="archive_source_file", 
            python_callable=archive_source_file, 
            provide_context=True, 
            op_args=[s3_bucket, s3_key, archive_folder, file_format],
            dag= dag,
            on_success_callback=None, 
            on_failure_callback=None
        )

end_data_pipeline = DummyOperator(task_id="end_data_pipeline", dag=dag, on_success_callback=None,on_failure_callback=None)

start_data_pipeline >> new_files_available >>  prepare_backup >> load_to_redshift 
load_to_redshift >> validate_loaded_records >>  archive_source >> end_data_pipeline

