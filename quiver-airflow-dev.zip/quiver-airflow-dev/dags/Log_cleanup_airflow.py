from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta
from helpers.args_helper import get_default_args


override_args = {'start_date': datetime(2023, 1, 1)}
default_args = {**get_default_args(), **override_args}

dag = DAG(
    'log_cleanup_airflow',
    default_args=default_args,
    description='A DAG to clean Airflow logs older than 7 days',
    schedule_interval=timedelta(days=1),  # Set the schedule interval as needed
    catchup=False,  # Set this to False if you don't want to backfill historical runs
)

# Define a dummy task
start_task = DummyOperator(
    task_id='start_task',
    dag=dag,
)

# Define a task to clean logs older than 7 days
clean_logs_task = BashOperator(
    task_id='clean_logs',
    bash_command='find /opt/airflow/logs -type f -mtime +7 -exec rm {} \;',
    dag=dag,
)
# task dependencies
start_task >> clean_logs_task

