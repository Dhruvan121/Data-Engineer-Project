import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('MonitorEventDescriptionData', schedule_interval='0 9 * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def monitor_event_description_function():
    sql = f"select * from monitor.check_eventdescriptiondata();"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    df = pd.read_sql(sql, engine)
    return df.empty


monitor_event_description_data_task = PythonOperator(task_id='monitor_event_description_data_task',
                                                     python_callable=monitor_event_description_function,
                                                     provide_context=True,
                                                     dag=dag)

monitor_event_description_data_task
