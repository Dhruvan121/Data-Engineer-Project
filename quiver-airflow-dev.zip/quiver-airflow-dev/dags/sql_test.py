import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from airflow.operators.docker_operator  import DockerOperator
from airflow.operators.dummy_operator import DummyOperator
from helpers.holiday_check_operator import holiday_check_short_circuit_operator
from helpers.timezone_helper import LA_TIMEZONE as local_tz
from datetime import datetime, timedelta
from sqlalchemy import create_engine
import pandas as pd
import os
from airflow import settings
from airflow.models import Connection
import base64
import subprocess
import boto3
from airflow import DAG
# from airflow.contrib.hooks.aws_hook import AwsHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash import BashOperator
import pymssql


today = datetime.now(local_tz)
dag = DAG('Sql_Test', 
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


# def sql_test():
#        sql = f"select * from panaray.ref.instrument;"
#        engine = pymssql.connect(os.environ.get('AIRFLOW_CONN_WONDB_SERVER'), os.environ.get('AIRFLOW_CONN_SQL_USER'),  os.environ.get('AIRFLOW_CONN_SQL_PASS'), 'wondb')
#        df = pd.read_sql(sql, engine)
#        print('''count''')
#        print(df.count)
#        return df.empty


# t2 = PythonOperator( task_id = 'sql_test_task',python_callable=sql_test, provide_context=True, dag=dag)


def update_credentials():
    """Retrieves ECR access token and updates Airflow docker_ecr connection"""
    # aws_hook = AwsHook("aws_credentials")
    # credentials = aws_hook.get_credentials()

    ecr = boto3.client(
        'ecr',
        region_name='us-east-1',
        aws_access_key_id=os.environ.get('AWS_ACCESS_KEY'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_KEY')
    )
    response = ecr.get_authorization_token()

    username, password = base64.b64decode(
        response['authorizationData'][0]['authorizationToken']
    ).decode('utf-8').split(':')

    registry_url = response['authorizationData'][0]['proxyEndpoint']

    conn = Connection(
        conn_id="docker_ecr",
        conn_type="docker",
        host=registry_url,
        login=username,
        password=password,
    )

    session = settings.Session()
    session.query(Connection).filter(Connection.conn_id == "docker_ecr").delete()
    session.add(conn)
    session.commit()

t2 = PythonOperator( task_id="update_credentials", python_callable=update_credentials , provide_context=True, dag=dag  )    

t3 = DockerOperator(
    task_id='batch_ecr_task',
    image='254815068103.dkr.ecr.us-east-1.amazonaws.com/quiver/ocmbatchdev-daily:latest',    
    auto_remove=True,
    execution_timeout=timedelta(minutes=120),
    network_mode="bridge",
    docker_conn_id = 'docker_ecr',
    api_version='auto',
    docker_url = 'unix://var/run/docker.sock',
    dag=dag)


# t2 = BashOperator(
#     task_id='javajar',
#     bash_command='java -jar /opt/airflow/OcmBatch_cloud-1.0.jar',
#     dag=dag
# ) 


t1 = DummyOperator(task_id="start")

t1 >> t2 >>  t3 

