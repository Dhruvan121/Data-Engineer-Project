import os
from airflow import DAG
from helpers.holiday_check_operator import holiday_check_short_circuit_operator
from airflow.models.variable import Variable
from airflow.operators.python import PythonOperator
from helpers.args_helper import get_default_args,get_current_date
from helpers.timezone_helper import LA_TIMEZONE as local_tz
from helpers.base_helper import *
from datetime import datetime, timedelta
from sqlalchemy import create_engine, text
import pymssql



today = datetime.now(local_tz)

default_args = get_default_args()

def import_external_data(quiver_engine,wondb_engine,advent_engine, hub_engine, clientdata_engine):
  try:
    import_wondb_tables(quiver_engine, wondb_engine)    
    import_advent_tables(quiver_engine,advent_engine)    # loads entire table from advent
    update_vcurrency_currencysymbol(quiver_engine)
    import_hub_tables(quiver_engine,hub_engine)   # loads past 7 days of data for larger tables    
    import_advent_historical_tables(quiver_engine,advent_engine)    
    
  except Exception as e:
        print("Error import_external_data:",e)
        raise Exception("update_vcurrency_currencysymbol")


  
def uploadhistoricaladventdata_db(q_engine):
    try:
        with q_engine.connect() as connection:
          sql_event_query = """select * From public.uploadhistoricaladventdata_cloud('{}');""".format(get_export_file_location())

          connection.execute(text(sql_event_query).execution_options(autocommit=True))

    except Exception as err:
      print("Error uploadhistoricaladventdata_db:",err)
  

def import_advent_historical_tables(quiver_engine,advent_engine):
  date = (datetime.now() - timedelta(days=7)).strftime('%m/%d/%Y')
  import_table_from_DB_Date('public','vportfoliotransaction','vportfoliotransaction',quiver_engine,advent_engine,date) 
  import_table_from_DB_Date('public','vsecuritysplit','vSecuritySplit',quiver_engine,advent_engine,date) 
  import_table_from_DB_Date('public','vfxrate','vFXRate',quiver_engine,advent_engine,date)
  import_table_from_DB_Date('public','vsecurityprice','vSecurityPrice',quiver_engine,advent_engine,date) 

  uploadhistoricaladventdata_db(quiver_engine)

def import_hub_tables(quiver_engine,hub_engine):
       import_table_from_DB('public','ecmcontact','ecmcontact',quiver_engine,hub_engine)



def update_vcurrency_currencysymbol(quiver_engine):
    try:
     with quiver_engine.connect() as connection:
          sql_event_query = """update vCurrency
                                set currencysymbol = null;

                                update vCurrency c
                                set currencysymbol = r.currencysymbol
                                from ref.currencysymbol r
                                where r.isocode = c.isocode;

                                update vCurrency c
                                set currencysymbol = c.isocode
                                where c.currencysymbol is null;"""

          connection.execute(text(sql_event_query).execution_options(autocommit=True))

    except Exception as e:
      print("Error update_vcurrency_currencysymbol:", e)
      raise Exception("update_vcurrency_currencysymbol")




def import_advent_tables(quiver_engine,advent_engine):
    import_table_from_DB('public','portfolio','portfolio',quiver_engine,advent_engine)  
    import_table_from_DB('public','contact','contact',quiver_engine,advent_engine)  
    import_table_from_DB('public','contactemails','contactemails',quiver_engine,advent_engine)  
    import_table_from_DB('public','vCurrency','vCurrency',quiver_engine,advent_engine)  
    import_table_from_DB('public','interestedparties','interestedparties',quiver_engine,advent_engine)  
    import_table_from_DB('public','portfoliobasecustom','portfoliobasecustom',quiver_engine,advent_engine)  
    import_table_from_DB('public','portfoliotaxlotcurrent','taxlotcurrent',quiver_engine,advent_engine)  
    import_table_from_DB('public','lmvhistory','lmvhistory',quiver_engine,advent_engine)  
    import_table_from_DB('ocm','vOGA_CapitalAccountDetail','vOGA_CapitalAccountDetail',quiver_engine,advent_engine)  
    import_table_from_DB('ocm','oga_fund','OGA_Fund',quiver_engine,advent_engine)  
    import_table_from_DB('public','vPortfolioComposite','vPortfolioComposite',quiver_engine,advent_engine)  
    import_table_from_DB('public','vPortfolioCompositeMember','vPortfolioCompositeMember',quiver_engine,advent_engine)  
    import_table_from_DB('public','vportfoliobase','vPortfolioBase',quiver_engine,advent_engine)  
    import_table_from_DB('oga','gips_firm_asset','gips_firm_asset',quiver_engine,advent_engine)  
    import_table_from_DB('public','portfpm','portfpm',quiver_engine,advent_engine) 
    import_table_from_DB('public','advtransactioncode','AdvTransactionCode',quiver_engine,advent_engine) 


def import_wondb_tables(quiver_engine, wondb_engine):
    import_table_from_DB('won','appx_instrumentmaster','instrument_master',quiver_engine,wondb_engine)
    import_table_from_DB('won','instrument','instrument',quiver_engine,wondb_engine)
    import_table_from_DB('ref','instrumenttype','instrumentType',quiver_engine,wondb_engine)
    import_table_from_DB('won','inactiversm','inactiversm',quiver_engine,wondb_engine)  
    import_table_from_DB('ref','countryregion','countryregion',quiver_engine,wondb_engine)
    import_table_from_DB('ref','currencies','currencies',quiver_engine,wondb_engine)
    import_table_from_DB('ref','oneilsector','OneilSector',quiver_engine,wondb_engine)
    import_table_from_DB('ref','oneilmajorindustry','OneilMajorIndustry',quiver_engine,wondb_engine)
    import_table_from_DB('won','hhsfint','hhsfint',quiver_engine,wondb_engine)
    import_table_from_DB('ref','instrumenttypemapping','InstrumentTypeMapping',quiver_engine,wondb_engine)
    import_table_from_DB('ref','browserinstrumenttype','BrowserInstrumentType',quiver_engine,wondb_engine,True)
    import_table_from_DB('ref','country','Country',quiver_engine,wondb_engine)
    import_table_from_DB('ref','region','region',quiver_engine,wondb_engine)
    import_table_from_DB('won','hsfsplits','splits',quiver_engine,wondb_engine)
    import_table_from_DB('won','exchange','exchange',quiver_engine,wondb_engine)
    import_table_from_DB('won','exchangelist','exchangelist',quiver_engine,wondb_engine)



def run_ocmbatch_daily():

  print('Starting daily job')
  date = get_current_date()
  print ('Date: ' + str(date))
  is_domestic = False

  quiver_engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'] )
  wondb_engine = pymssql.connect(os.environ.get('AIRFLOW_CONN_WONDB_SERVER'), os.environ.get('AIRFLOW_CONN_SQL_USER'), os.environ.get('AIRFLOW_CONN_SQL_PASS'), 'wondb')
  advent_engine = pymssql.connect(os.environ.get('AIRFLOW_CONN_ADVENT_SERVER'), os.environ.get('AIRFLOW_CONN_SQL_USER'), os.environ.get('AIRFLOW_CONN_SQL_PASS'), 'ApxFirm')
  hub_engine = pymssql.connect(os.environ.get('AIRFLOW_CONN_HUB_SERVER'), os.environ.get('AIRFLOW_CONN_SQL_USER'), os.environ.get('AIRFLOW_CONN_SQL_PASS'), 'ecmdb')
  clientdata_engine = pymssql.connect(os.environ.get('AIRFLOW_CONN_CLIENTDATA_SERVER'), os.environ.get('AIRFLOW_CONN_SQL_USER'), os.environ.get('AIRFLOW_CONN_SQL_PASS'), 'clientdata')

  upload_batch_ids = get_current_uploadBatchIds(quiver_engine)

  if upload_batch_ids.count == 0: 
    return

  if  1 or 3 in  upload_batch_ids:
    is_domestic = True

  print("is domestic: " + str(is_domestic))

  import_external_data(quiver_engine,wondb_engine,advent_engine, hub_engine,clientdata_engine)  


daily_task = PythonOperator( task_id = 'sql_test_task',python_callable=run_ocmbatch_daily, provide_context=True, dag=dag)


daily_task
  