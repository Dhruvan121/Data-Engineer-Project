import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('RefreshGroupingItemInfoTable', schedule_interval='0 12 * * *',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def insert_group_item_changes_function():
    sql = f"SELECT * FROM ref.update_groupiteminfo();"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    df = pd.read_sql(sql, engine)
    return df.empty


insert_group_item_changes_task = PythonOperator(task_id='insert_group_item_changes_task',
                                                python_callable=insert_group_item_changes_function,
                                                provide_context=True,
                                                dag=dag)

insert_group_item_changes_task
