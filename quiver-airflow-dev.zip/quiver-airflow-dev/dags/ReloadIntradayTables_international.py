import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from sqlalchemy import create_engine
import pandas as pd

dag = DAG('ReloadIntradaytablesInternational', schedule_interval='45 13 * * 1-5',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)


def reload_intraday_function():
    sql = f"select * From public.reload_intradaydata(-1);"
    engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
    df = pd.read_sql(sql, engine)
    return df.empty


reload_intraday_tables_task = PythonOperator(task_id='reload_intraday_tables_task',
                                             python_callable=reload_intraday_function,
                                             provide_context=True,
                                             dag=dag)

reload_intraday_tables_task
