import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from helpers.holiday_check_operator import holiday_check_short_circuit_operator
from helpers.timezone_helper import LA_TIMEZONE as local_tz
from datetime import datetime, timedelta
from sqlalchemy import create_engine
import pandas as pd

today = datetime.now(local_tz)
dag = DAG('BackupIntradayData', schedule_interval='05 23 * * 1-5',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)

holiday_task = holiday_check_short_circuit_operator(dag,country_code=1, trade_date=today)

def backup_intraday_function():
       sql = f"select * from archive.backup_intraday();"
       engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
       df = pd.read_sql(sql, engine)
       return df.empty


backup_intraday_Data_task = PythonOperator( task_id = 'backup_intraday_Data_task',python_callable=backup_intraday_function, provide_context=True, dag=dag)

holiday_task >> backup_intraday_Data_task
