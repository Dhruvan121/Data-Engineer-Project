import os
from airflow import DAG
from datetime import datetime, timedelta, date
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.python import PythonOperator
from helpers.holiday_check_operator import holiday_check_short_circuit_operator
from helpers.timezone_helper import LA_TIMEZONE as local_tz
from datetime import datetime, timedelta
from sqlalchemy import create_engine
import pandas as pd
import time

today = datetime.now(local_tz)
dag = DAG('Intraday_Calc_Benchmark', schedule_interval='30 14 * * 1-5',
          start_date=datetime(2022, 12, 12), tags=['postgresjob'],
          catchup=False)

holiday_task = holiday_check_short_circuit_operator(dag, country_code=1, trade_date=today)


def calculate_intraday_metrics_function():
    end_time = datetime.now(local_tz) + timedelta(minutes=390)
    dt_string_end = end_time.strftime("%d/%m/%Y %H:%M")
    while True:
        time.sleep(120)
        current_time = datetime.now(local_tz)
        dt_string_curr = current_time.strftime("%d/%m/%Y %H:%M")

        sql = f"select * from public.calc_intraday_benchmark_metrics();"
        engine = create_engine(os.environ['AIRFLOW_CONN_QUIVER_CLOUD'])
        engine.execute(sql)
        print(dt_string_curr)
        if dt_string_curr == dt_string_end:
            break


calculate_intraday_metrics_task = PythonOperator(task_id='calculate_intraday_metrics_task',
                                                 python_callable=calculate_intraday_metrics_function,
                                                 provide_context=True, dag=dag)

holiday_task >> calculate_intraday_metrics_task
