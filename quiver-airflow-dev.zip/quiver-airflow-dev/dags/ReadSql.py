from datetime import datetime,timedelta
from airflow import DAG
from airflow.operators.postgres_operator import PostgresOperator
from airflow.hooks.postgres_hook import PostgresHook
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.mssql_hook import MsSqlHook
import pandas as pd
import psycopg2


#Define dag funtion
def extract_data():
    try:
        hook = MsSqlHook(mssql_conn_id='DBDev1')
        sql = """SELECT TOP 10 * FROM Secmaster;
                """

        df_inst_data = hook.get_pandas_df(sql)
        #context['ti'].xcom_push(key='ext_ins_data', value =df_inst_data)
        #return df_inst_data
        print(df_inst_data)

    except Exception as e:
        print('Data extract error: ' + str(e))



default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    # 'start_date': airflow.utils.dates.
    'start_date': datetime(2022, 12, 8),
    # 'email': ['email@mail.com'],
    # 'email_on_failure': False,
    # 'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
        'Read_Sql_Data',
        schedule_interval=None,
        tags=['read_sql_data'],
        default_args=default_args,
        max_active_runs=1,
        catchup=False
    )


# extract data from source table
task_extract_data = PythonOperator(
    task_id='extract_data',
    python_callable=extract_data,
    #do_xcom_push=True,
    #provide_context =True,
    dag=dag)



task_extract_data



